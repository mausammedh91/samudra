<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/tabbox1.css">

    <title>Previous Year Paper of Indian Maritime University</title>
    <meta name="description" content="Preview and download previous year paper and syllabus of IMU of all the semester." />
    <meta name="keywords"
        content="marine engineering, previous year paper, semester 1, semester 2, semester3, semester 4, semester 5, semester 6, semester 7, semester 8, Indian Maritime University, Btech Marine Engineering, paper, year, previous, previous year, year paper, previous year paper, indian, of indian, engineering, marine, marine engineering, view, syllabus, 2021, home, paper marine, paper marine engineering" />

</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.php"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/previous_year/previous_year_paper.php" style="cursor: default;">Previous Year Paper</a>
                </li>
                <li><a href="/previous_year/IMU/qestion_IMU.php" style="cursor: default;">Marine Engineering Paper</a>
                </li>

            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-5">
                <div class="col-lg-6 col-md-8 mx-auto">
                    <h1 class="fw-light" style="font-family: cursive; font-weight: bolder; font-size: 45px ;">Marine
                        Engineering</h1>

                    </p>
                    <p class="lead text-muted" style=" color: black; font-size: 25px;">All the study material is
                        provided as per the syllabus of</p>
                    <p class="lead text-muted" style=" color: black; font-size: 25px;"><strong>"INDIAN MARITME
                            UNNIVERSITY"</strong>.</p>
                </div>
                <!-- details start -->
                <div class="conta">
                    <details class="conta1">
                        <summary class="conta2" style="background: rgba(88, 88, 88, 0.719);">4 Year BTech Marine
                            Engineering
                        </summary>
                        <div class="contatext">
                            <!-- table start  -->
                            <div class="tabbox1">
                                <div class="tabboxr">
                                    <div class="tabcell">
                                        <p><a href="/previous_year/IMU/Marine_syllabus/marine_btech_syllabus.php"
                                                class="hear"> View & Download Syllabus</a></p>
                                    </div>
                                </div>
                                <div class="tabboxr tabboxh">
                                    <div class="tabcell">
                                        <p>Year\Sem</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>1</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>2</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>3</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>4</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>5</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>6</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>7</p>
                                    </div>
                                    <div class="tabcell">
                                        <p>8</p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2014</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2015</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="/previous_year/IMU/Sem4/2015/2015paper.php" class="hear">View</a>
                                        </p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2016</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="/previous_year/IMU/Sem4/2016/2016paper.php" class="hear">View</a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2017</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="/previous_year/IMU/Sem4/2017/2017paper.php" class="hear">View</a>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2018</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2019</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2020</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                                <div class="tabboxr">
                                    <div class="tabcell tabboxh">
                                        <p>2021</p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                    <div class="tabcell">
                                        <p><a href="#" class="hear"></a></p>
                                    </div>
                                </div>
                            </div>
                            <!-- table end  -->
                        </div>
                    </details>
                </div>
                <!-- details end  -->
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.php"); ?>
        <!-- Footer End -->


        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>

        <!-- Option 2: Separate Popper and Bootstrap JS -->
        <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>

</html>