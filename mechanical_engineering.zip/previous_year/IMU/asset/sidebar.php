<div class="col-md-4">

        <div class="p-4" style="text-align: left;">
                <h4 class="fst-italic">Jump to</h4>
                <ol class="list-unstyled mb-0">
                        <li><a href="/marine_engineering/marine_mcq.php" class="dfg">Marine Engineering
                                        MCQ</a>
                        </li>
                        <li><a href="/mechanical_engineering/mechanical_eng.php" class="dfg">Mechanical
                                        Engineering MCQ</a></li>
                </ol>
                <h4 class="fst-italic">Marine Eng. 2015 SEM 4</h4>
                <ol class="list-unstyled mb-0">
                        <li><a href="/previous_year/IMU/Sem4/2015/electrical_machine2.php" class="dfg">Electrical
                                        Machines II</a>
                        </li>
                        <li><a href="/previous_year/IMU/Sem4/2015/fluid_mechanics1.php" class="dfg">Fluid
                                        Mechanics I</a></li>
                        <li><a href="/previous_year/IMU/Sem4/2015/marine_boiler_steam_eng.php" class="dfg">Marine Boiler
                                        Steam Engineering</a></li>
                        <li><a href="/previous_year/IMU/Sem4/2015/marine_heat_eng&AC.php" class="dfg">Marine
                                        Heat Engines & AC</a></li>
                        <li><a href="/previous_year/IMU/Sem4/2015/mechanics_of_machine_ii.php" class="dfg">Mechanics of
                                        Machines-II</a></li>
                        <li><a href="/previous_year/IMU/Sem4/2015/practical_marine_automation.php" class="dfg">Practical
                                        Marine Automation</a></li>
                        <li><a href="/previous_year/IMU/Sem4/2015/ship_structure&construction.php" class="dfg">Ship
                                        Structure and Construction</a></li>
                </ol>
                <h4 class="fst-italic">Marine Eng. 2016 SEM 4</h4>
                                <ol class="list-unstyled mb-0">
                                    <li><a href="/previous_year/IMU/Sem4/2016/electrical_machine2.php"
                                            class="dfg">Electrical Machines II</a>
                                    </li>
                                    <li><a href="/previous_year/IMU/Sem4/2016/fluid_mechanics1.php" class="dfg">Fluid
                                            Mechanics I</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2016/marine_boiler_steam_eng.php"
                                            class="dfg">Marine Boiler Steam Engineering</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2016/marine_heat_eng&AC.php"
                                            class="dfg">Marine Heat Engines & AC</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2016/mechanics_of_machine_ii.php"
                                            class="dfg">Mechanics of Machines-II</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2016/practical_marine_automation.php"
                                            class="dfg">Practical Marine Automation</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2016/ship_structure&construction.php"
                                            class="dfg">Ship Structure and Construction</a></li>
                                </ol>
            <h4 class="fst-italic">Marine Eng. 2017 SEM 4</h4>
                                <ol class="list-unstyled mb-0">
                                    <li><a href="/previous_year/IMU/Sem4/2017/electrical_machine2.php"
                                            class="dfg">Electrical Machines II</a>
                                    </li>
                                    <li><a href="/previous_year/IMU/Sem4/2017/fluid_mechanics1.php" class="dfg">Fluid
                                            Mechanics I</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2017/marine_boiler_steam_eng.php"
                                            class="dfg">Marine Boiler Steam Engineering</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2017/marine_heat_eng&AC.php"
                                            class="dfg">Marine Heat Engines & AC (Set 1)</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2017/marine_heat_eng&AC2.php"
                                            class="dfg">Marine Heat Engines & AC (Set 2)</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2017/mechanics_of_machine_ii.php"
                                            class="dfg">Mechanics of Machines-II</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2017/practical_marine_automation.php"
                                            class="dfg">Practical Marine Automation</a></li>
                                    <li><a href="/previous_year/IMU/Sem4/2017/ship_structure&construction.php"
                                            class="dfg">Ship Structure and Construction</a></li>
                                </ol>
        </div>
</div>