<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <script src="/JS/js1.js"></script>

    <title>Marine Boiler Steam Engineering 2017 | Previous Year Paper of Indian Maritime University</title>
    <meta name="description"
        content="Preview and download previous year paper of IMU (Marine Boiler Steam Engineering 2017)" />
    <meta name="keywords"
        content="2017, marine, boiler, engineering, steam, marine boiler, boiler steam, steam engineering, marine boiler steam, boiler steam engineering, marine boiler steam engineering, paper, previous, year, previous year, year paper, previous year paper, sem, sem 4, heat, boilers, services, mechanics, engines, set, tube, engineering marine, marine engineering, marine heat, heat engines, engines ac, ac set, steam engineering marine, marine heat engines, heat engines ac, engines ac set, boiler steam engineering marine, marine heat engines ac, heat engines ac set, marine boiler steam engineering marine, marine heat engines ac set" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.php"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/previous_year/previous_year_paper.php" style="cursor: default;">Previous Year Paper</a>
                </li>
                <li><a href="/previous_year/IMU/qestion_IMU.php" style="cursor: default;">Marine Engineering Paper</a>
                </li>
                <li><a href="/previous_year/IMU/Sem4/2017/2017paper.php" style="cursor: default;">SEM 4: 2017</a>
                </li>
                <li><a href="/previous_year/IMU/Sem4/2017/marine_boiler_steam_eng.php" style="cursor: default;">Marine
                        Boiler Steam Engineering</a>
                </li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Marine Boiler Steam Engineering (2017)</h1>
                                <hr>
                                <p>
                                <div class="ratio ratio-1x1">
                                    <iframe style="border: solid black 2px;"
                                        src="https://drive.google.com/file/d/1U8qoB61846DwVuDt9SAz3Mtc-rvHWic0/preview"
                                        width="640" height="480"></iframe>

                                </div>
                                </p>
                                <h4>Click here: <a
                                        href="https://drive.google.com/uc?export=download&id=1U8qoB61846DwVuDt9SAz3Mtc-rvHWic0"
                                        class="dfg">Download PDF</a></h4>

                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/previous_year/IMU/asset/"; include($IPATH."sidebar.php"); ?>

                    </div><!-- /.row -->
                </main>

            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->


        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>

        <!-- Option 2: Separate Popper and Bootstrap JS -->
        <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>

</html>