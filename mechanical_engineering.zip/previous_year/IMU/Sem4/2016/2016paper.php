<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">

    <title>Marine Engineering 4th sem 2016 Paper</title>
    <meta name="description" content="Preview and download fourth semester 2016 marine engineering paper of IMU" />
    <meta name="keywords"
        content="marine engineering, 2016, previous year paper, Electrical Machines II, Fluid Mechanics I, Marine Boiler Steam Engineering, Marine Heat Engines & AC, Mechanics of Machines-II, Practical Marine Automation, Ship Structure and Construction" />

</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.php"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/previous_year/previous_year_paper.php" style="cursor: default;">Previous Year Paper</a>
                </li>
                <li><a href="/previous_year/IMU/qestion_IMU.php" style="cursor: default;">Marine Engineering Paper</a>
                </li>
                <li><a href="/previous_year/IMU/Sem4/2016/2016paper.php" style="cursor: default;">SEM 4: 2016</a>
                </li>

            </ul>
        </div>
        <!-- path end -->

        <!-- slider start -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-5">
                <div class="col-lg-6 col-md-8 mx-auto">
                    <h1 class="fw-light" style="font-family: cursive; font-weight: bolder; font-size: 45px ;">Previous
                        Year
                        Paper 2016</h1>
                    <p class="lead text-muted" style=" color: black; font-size: 25px;"></p>
                    <p>

                    </p>
                </div>
            </div>
        </section>


        <!-- slider end -->
        <!-- marketing start  -->
        <div class="album py-5 bg-light">
            <div class="container">

                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/previous_year/IMU/Sem4/2016/2016img/Electrical Machines-II.jpg"
                                alt="Electrical Machines II" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Electrical Machines II</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/Sem4/2016/electrical_machine2.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/previous_year/IMU/Sem4/2016/2016img/Fluids Mechanics-I.jpg"
                                alt="Fluid Mechanics I" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Fluid Mechanics I</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/Sem4/2016/fluid_mechanics1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/previous_year/IMU/Sem4/2016/2016img/Marine Boiler Steam Engineering.jpg"
                                alt="Marine Boiler Steam Engineering" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Marine Boiler Steam Engineering</strong>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/Sem4/2016/marine_boiler_steam_eng.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/previous_year/IMU/Sem4/2016/2016img/Marine Heat Engine and Air Conditioning.jpg"
                                alt="Marine Heat Engines & AC" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Marine Heat Engines & AC</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/Sem4/2016/marine_heat_eng&AC.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/previous_year/IMU/Sem4/2016/2016img/Semester-Mechanics of Machines-II.jpg"
                                alt="Mechanics of Machines-II" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Mechanics of Machines-II</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/Sem4/2016/mechanics_of_machine_ii.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/previous_year/IMU/Sem4/2016/2016img/Practical Marine Automation.jpg"
                                alt="Practical Marine Automation" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Practical Marine Automation</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/Sem4/2016/practical_marine_automation.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/previous_year/IMU/Sem4/2016/2016img/Ship Structure and Ship Construction.jpg"
                                alt="Ship Structure and Construction" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Ship Structure and Construction</strong>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/Sem4/2016/ship_structure&construction.php"
                                                style="text-decoration: none; color: black;">Know
                                                More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <!-- marketing end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.php"); ?>
        <!-- Footer End -->


        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>

        <!-- Option 2: Separate Popper and Bootstrap JS -->
        <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>

</html>