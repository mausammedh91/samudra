<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/tabbox1.css">


    <title>Previous Year Question Paper | samudramanthan.co.in</title>
    <meta name="description" content="Get Previous Year Paper of B. Tech Marine Engineering, B.Tech Mechanical Engineering" />
    <meta name="keywords" content="paper, previous, year, previous year, samudramanthan.co.in, year paper, previous year paper, engineering, mechanical, mechanical engineering, services, more.., know more..
" />
</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.php"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/previous_year/previous_year_paper.php" style="cursor: default;">Previous Year Paper</a>
                </li>

            </ul>
        </div>
        <!-- path end -->

        <!-- slider start -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-5">
                <div class="col-lg-6 col-md-8 mx-auto">
                    <h1 class="fw-light" style="font-family: cursive; font-weight: bolder; font-size: 45px ;">Previous
                        Year
                        Paper</h1>
                </div>
            </div>
        </section>


        <!-- slider end -->

        <!-- marketing start  -->
        <div class="album py-5 bg-light">
            <div class="container">

                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/CSS/Indian_Maritime_University_(IMU).gif" alt="Indian Maritime University"
                                width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>Indian Maritime University</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/previous_year/IMU/qestion_IMU.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col">
                    <div class="card shadow-sm">
                        <img src="/CSS/Mech1.jpg" alt="" width="100%" height="225">

                        <div class="card-body">
                            <p class="card-text lead text-muted"> <strong>Mechanical Engineering</strong></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                            href="/Services/Mechanical.html"
                                            style="text-decoration: none; color: black;">Know More...</a></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->

                </div>
            </div>
        </div>
        <!-- marketing end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.php"); ?>
        <!-- Footer End -->


        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>

        <!-- Option 2: Separate Popper and Bootstrap JS -->
        <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>

</html>