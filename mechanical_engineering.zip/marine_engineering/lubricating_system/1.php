<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/lubricating_system/javascript/1.js"></script>

    <title>Lubricating System & Maintenance (Set1)</title>
    <meta name="description"
        content="Heat exchangers are most commonly found in a small auxiliary..., One advantage of vacuum feed type cylinder lubricators over the liquid..., Which of the following devices controls the discharge flow..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, system, lubricating, main, maintenance, systems, lubricating systems, maintenance multiple, maintenance multiple choice, maintenance multiple choice questions, services, oil, submit, lube, pressure, engine, diesel, filter, fuel, water, pump, temperature, cooling, viscosity, engineering, marine, cylinder, flow, valve, operation, lubrication, bearing, high, mechanical, heat, air, control, engines, sump, stern, duplex, strainer, large, low-speed, propulsion, drop, sea, maneuvering, result, resist, exchangers, small, auxiliary, type, lubricators, required, devices, discharge, rate, positive, relief, pumps, operated, hour, cooler, greater, installed, line, tank, prevent, oils, tbn, point, filters, slowly, decrease, higher, efficiently, filtered, dirty, remove, heated, reduce, determine, failure, ensure, sludge, temperatures, piston, rings, instrumentation, ship, lube oil, diesel engine, the oil, oil system, of the, than the, fuel oil, engine lube, a diesel, the filter, the pressure, marine engineering, in a, which of, the following, oil pump, the cooling, cooling water, oil pressure, pressure is, large low-speed, main propulsion, propulsion diesel, pressure drop, at sea, services marine, heat exchangers, of oil, may be, following devices, rate of, a pressure, pressure relief, the engine, each hour, oil cooler, oil temperature, temperature is, is less, less than, water pressure, pressure the, is greater, greater than, in the, the main, diesel engines, from the, the stern, stern bearing, a large, tbn value, oil filters, drop across, across the, the same, of a, low-speed main, sea than, than while, while maneuvering, is too, too low, the systems, a dirty, oil strainer, heated to, to reduce, reduce viscosity, determine the, the need, need for, failure lube, of lube, piston rings, rings all, all of, the above, above submit, changes in, lube oil system, diesel engine lube, engine lube oil, a diesel engine, which of the, of the following, than the cooling, the cooling water, main propulsion diesel, the pressure drop, services marine engineering, the following devices, lube oil pump, is less than, less than the, the oil pressure, oil pressure is, cooling water pressure, water pressure the, pressure the oil, is greater than, greater than the, the stern bearing, in a diesel, a large low-speed, propulsion diesel engine, lube oil filters, pressure drop across, drop across the, across the filter, large low-speed main, low-speed main propulsion, at sea than, sea than while, than while maneuvering, is too low, than the systems, lube oil strainer, heated to reduce, to reduce viscosity, determine the need, the need for, failure lube oil, of lube oil, piston rings all, rings all of, all of the, of the above, the above submit, diesel engine lube oil, which of the following, than the cooling water, of the following devices, is less than the, less than the cooling, the oil pressure is, the cooling water pressure, cooling water pressure the, water pressure the oil, is greater than the, in a diesel engine, main propulsion diesel engine, the pressure drop across, pressure drop across the, drop across the filter, large low-speed main propulsion, low-speed main propulsion diesel, at sea than while, sea than while maneuvering, heated to reduce viscosity, a diesel engine lube, engine lube oil system, determine the need for, piston rings all of, rings all of the, all of the above, of the above submit, which of the following devices, is less than the cooling, less than the cooling water, than the cooling water pressure, the cooling water pressure the, cooling water pressure the oil, the pressure drop across the, pressure drop across the filter, large low-speed main propulsion diesel, at sea than while maneuvering, a diesel engine lube oil, diesel engine lube oil system, piston rings all of the, rings all of the above, all of the above submit" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/lubricating_system/1.php" style="cursor: default;">LUBRICATING
                        SYSTEMS: <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Lubricating System & Maintenance (Set1)</h1>
                                <hr>
                                <p>
                                <h4>Multiple Choice Questions</h4>
                                <hr>
                                <!-- Question 1 -->
                                <div class="ques">
                                    <p class="qn">1. Heat exchangers are most commonly found in a small auxiliary
                                        diesel engine ____________.
                                    </p>
                                    <hr>

                                    <div id='block-1' class="qo">
                                        <label for='ox1' class="ll">
                                            <input type='radio' name='option' id='ox1' class="on" />
                                            <em>fuel oil system</em></label>
                                        <span id='rx1'></span>
                                    </div>


                                    <div id='block-2' class="qo">
                                        <label for='ox2' class="ll">
                                            <input type='radio' name='option' id='ox2' class="on" />
                                            <em>governing system
                                            </em></label>
                                        <span id='rx2'></span>
                                    </div>


                                    <div id='block-3' class="qo">
                                        <label for='ox3' class="ll">
                                            <input type='radio' name='option' id='ox3' class="on" />
                                            <em>air starting system</em></label>
                                        <span id='rx3'></span>
                                    </div>


                                    <div id='block-4' class="qo">
                                        <label for='ox4' class="ll">
                                            <input type='radio' name='option' id='ox4' class="on" />
                                            <em>lube oil system</em></label>
                                        <span id='rx4'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 2 -->
                                <div class="ques">
                                    <p class="qn">2. One advantage of vacuum feed type cylinder lubricators over the
                                        liquid sight glass type is ______________.
                                    </p>
                                    <hr>

                                    <div id='block-5' class="qo">
                                        <label for='ox5' class="ll">
                                            <input type='radio' name='option' id='ox5' class="on" />
                                            <em>there are fewer moving parts
                                            </em></label>
                                        <span id='rx5'></span>
                                    </div>


                                    <div id='block-6' class="qo">
                                        <label for='ox6' class="ll">
                                            <input type='radio' name='option' id='ox6' class="on" />
                                            <em>adjustment is not required
                                            </em></label>
                                        <span id='rx6'></span>
                                    </div>


                                    <div id='block-7' class="qo">
                                        <label for='ox7' class="ll">
                                            <input type='radio' name='option' id='ox7' class="on" />
                                            <em>better metering accuracy
                                            </em></label>
                                        <span id='rx7'></span>
                                    </div>


                                    <div id='block-8' class="qo">
                                        <label for='ox8' class="ll">
                                            <input type='radio' name='option' id='ox8' class="on" />
                                            <em>a lower grade of oil may be used
                                            </em></label>
                                        <span id='rx8'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 3 -->
                                <div class="ques">
                                    <p class="qn">3. Which of the following devices controls the discharge flow rate of
                                        an
                                        attached, positive displacement, rotary gear, diesel engine, lube oil
                                        pump?
                                    </p>
                                    <hr>

                                    <div id='block-9' class="qo">
                                        <label for='ox9' class="ll">
                                            <input type='radio' name='option' id='ox9' class="on" />
                                            <em>A pressure regulating valve</em></label>
                                        <span id='rx9'></span>
                                    </div>


                                    <div id='block-10' class="qo">
                                        <label for='ox10' class="ll">
                                            <input type='radio' name='option' id='ox10' class="on" />
                                            <em>A pressure relief valve
                                            </em></label>
                                        <span id='rx10'></span>
                                    </div>


                                    <div id='block-11' class="qo">
                                        <label for='ox11' class="ll">
                                            <input type='radio' name='option' id='ox11' class="on" />
                                            <em>The engine speed
                                            </em></label>
                                        <span id='rx11'></span>
                                    </div>


                                    <div id='block-12' class="qo">
                                        <label for='ox12' class="ll">
                                            <input type='radio' name='option' id='ox12' class="on" />
                                            <em>An orifice</em></label>
                                        <span id='rx12'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 4 -->
                                <div class="ques">
                                    <p class="qn">4. Mechanical lubricators for diesel engine cylinders are usually
                                        small
                                        reciprocating pumps which are _____________.
                                    </p>
                                    <hr>

                                    <div id='block-13' class="qo">
                                        <label for='ox13' class="ll">
                                            <input type='radio' name='option' id='ox13' class="on" />
                                            <em>operated manually once each hour
                                            </em></label>
                                        <span id='rx13'></span>
                                    </div>


                                    <div id='block-14' class="qo">
                                        <label for='ox14' class="ll">
                                            <input type='radio' name='option' id='ox14' class="on" />
                                            <em>operated until the engine has started
                                            </em></label>
                                        <span id='rx14'></span>
                                    </div>


                                    <div id='block-15' class="qo">
                                        <label for='ox15' class="ll">
                                            <input type='radio' name='option' id='ox15' class="on" />
                                            <em>placed into operation only at maximum load
                                            </em></label>
                                        <span id='rx15'></span>
                                    </div>


                                    <div id='block-16' class="qo">
                                        <label for='ox16' class="ll">
                                            <input type='radio' name='option' id='ox16' class="on" />
                                            <em>adjustable to meet lubrication requirements</em></label>
                                        <span id='rx16'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 5 -->
                                <div class="ques">
                                    <p class="qn">5. Which of the following statements is true concerning an oil cooler?
                                    </p>
                                    <hr>

                                    <div id='block-17' class="qo">
                                        <label for='ox17' class="ll">
                                            <input type='radio' name='option' id='ox17' class="on" />
                                            <em>The oil temperature is less than the cooling water temperature.
                                            </em></label>
                                        <span id='rx17'></span>
                                    </div>


                                    <div id='block-18' class="qo">
                                        <label for='ox18' class="ll">
                                            <input type='radio' name='option' id='ox18' class="on" />
                                            <em>The oil pressure is less than the cooling water pressure.</em></label>
                                        <span id='rx18'></span>
                                    </div>


                                    <div id='block-19' class="qo">
                                        <label for='ox19' class="ll">
                                            <input type='radio' name='option' id='ox19' class="on" />
                                            <em>The oil pressure is greater than the cooling water
                                                pressure.</em></label>
                                        <span id='rx19'></span>
                                    </div>


                                    <div id='block-20' class="qo">
                                        <label for='ox20' class="ll">
                                            <input type='radio' name='option' id='ox20' class="on" />
                                            <em>The oil flow control valve is always installed in the oil input line
                                            </em></label>
                                        <span id='rx20'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 6 -->
                                <div class="ques">
                                    <p class="qn">6. Lubrication for the main reduction gears used with diesel engines
                                        is
                                        usually supplied by _____________.
                                    </p>
                                    <hr>

                                    <div id='block-21' class="qo">
                                        <label for='ox21' class="ll">
                                            <input type='radio' name='option' id='ox21' class="on" />
                                            <em>oil from the main engine sump
                                            </em></label>
                                        <span id='rx21'></span>
                                    </div>


                                    <div id='block-22' class="qo">
                                        <label for='ox22' class="ll">
                                            <input type='radio' name='option' id='ox22' class="on" />
                                            <em>an independent lube oil system
                                            </em></label>
                                        <span id='rx22'></span>
                                    </div>


                                    <div id='block-23' class="qo">
                                        <label for='ox23' class="ll">
                                            <input type='radio' name='option' id='ox23' class="on" />
                                            <em>the stern bearing head tank</em></label>
                                        <span id='rx23'></span>
                                    </div>


                                    <div id='block-24' class="qo">
                                        <label for='ox24' class="ll">
                                            <input type='radio' name='option' id='ox24' class="on" />
                                            <em>the stern bearing sump tank
                                            </em></label>
                                        <span id='rx24'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 7 -->
                                <div class="ques">
                                    <p class="qn">7. Which of the following devices is normally provided to prevent oil
                                        starvation in a diesel engine lubrication system utilizing the "full
                                        flow" principle?
                                    </p>
                                    <hr>

                                    <div id='block-25' class="qo">
                                        <label for='ox25' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox25'
                                                class="on" />
                                            <em>Duplex strainer</em></label>
                                        <span id='rx25'></span>
                                    </div>


                                    <div id='block-26' class="qo">
                                        <label for='ox26' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox26'
                                                class="on" />
                                            <em>Three-way valve
                                            </em></label>
                                        <span id='rx26'></span>
                                    </div>


                                    <div id='block-27' class="qo">
                                        <label for='ox27' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                                class="on" />
                                            <em>Pressure relief bypass line around the filter</em></label>
                                        <span id='rx27'></span>
                                    </div>


                                    <div id='block-28' class="qo">
                                        <label for='ox28' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                                class="on" />
                                            <em>Mechanical straining filter
                                            </em></label>
                                        <span id='rx28'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 8 -->
                                <div class="ques">
                                    <p class="qn">8. A large, low-speed, crosshead, main propulsion diesel engine using
                                        residual fuel oils must have a cylinder oil having a ____________.
                                    </p>
                                    <hr>

                                    <div id='block-29' class="qo">
                                        <label for='ox29' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox29'
                                                class="on" />
                                            <em> low TBN value
                                            </em></label>
                                        <span id='rx29'></span>
                                    </div>


                                    <div id='block-30' class="qo">
                                        <label for='ox30' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox30'
                                                class="on" />
                                            <em>high alkaline reserve
                                            </em></label>
                                        <span id='rx30'></span>
                                    </div>


                                    <div id='block-31' class="qo">
                                        <label for='ox31' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                                class="on" />
                                            <em>low fclearance point
                                            </em></label>
                                        <span id='rx31'></span>
                                    </div>


                                    <div id='block-32' class="qo">
                                        <label for='ox32' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                                class="on" />
                                            <em>high pour point
                                            </em></label>
                                        <span id='rx32'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 9 -->
                                <div class="ques">
                                    <p class="qn">9. Many lube oil filters have pressure gauges installed on both the
                                        inlet
                                        and outlet in order to indicate the pressure drop across the filter. In
                                        normal operation, the pressure drop will _____________.
                                    </p>
                                    <hr>

                                    <div id='block-33' class="qo">
                                        <label for='ox33' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox33'
                                                class="on" />
                                            <em>slowly increase
                                            </em></label>
                                        <span id='rx33'></span>
                                    </div>


                                    <div id='block-34' class="qo">
                                        <label for='ox34' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox34'
                                                class="on" />
                                            <em>slowly decrease</em></label>
                                        <span id='rx34'></span>
                                    </div>


                                    <div id='block-35' class="qo">
                                        <label for='ox35' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                                class="on" />
                                            <em>remain the same
                                            </em></label>
                                        <span id='rx35'></span>
                                    </div>


                                    <div id='block-36' class="qo">
                                        <label for='ox36' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                                class="on" />
                                            <em>have no effect on filter operation
                                            </em></label>
                                        <span id='rx36'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 10 -->
                                <div class="ques">
                                    <p class="qn">10. The rate of cylinder lubricating oil metered to each cylinder of a
                                        large, low-speed, main propulsion diesel engine is
                                        ______________.
                                    </p>
                                    <hr>

                                    <div id='block-37' class="qo">
                                        <label for='ox37' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox37'
                                                class="on" />
                                            <em>the same, whether at sea, or during maneuvering</em></label>
                                        <span id='rx37'></span>
                                    </div>


                                    <div id='block-38' class="qo">
                                        <label for='ox38' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox38'
                                                class="on" />
                                            <em>adjusted during each hour of operation while at constant RPM
                                            </em></label>
                                        <span id='rx38'></span>
                                    </div>


                                    <div id='block-39' class="qo">
                                        <label for='ox39' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                                class="on" />
                                            <em>higher at sea than while maneuvering</em></label>
                                        <span id='rx39'></span>
                                    </div>


                                    <div id='block-40' class="qo">
                                        <label for='ox40' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                                class="on" />
                                            <em>lower at sea than while maneuvering</em></label>
                                        <span id='rx40'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 11 -->
                                <div class="ques">
                                    <p class="qn">11. Lube oil cannot be efficiently filtered if its ____________.
                                    </p>
                                    <hr>

                                    <div id='block-41' class="qo">
                                        <label for='ox41' class="ll">
                                            <input type='radio' name='option' id='ox41' class="on" />
                                            <em>viscosity is too low</em></label>
                                        <span id='rx41'></span>
                                    </div>


                                    <div id='block-42' class="qo">
                                        <label for='ox42' class="ll">
                                            <input type='radio' name='option' id='ox42' class="on" />
                                            <em>temperature is too low</em></label>
                                        <span id='rx42'></span>
                                    </div>


                                    <div id='block-43' class="qo">
                                        <label for='ox43' class="ll">
                                            <input type='radio' name='option' id='ox43' class="on" />
                                            <em>pump discharge pressure is higher than the system's pressure
                                            </em></label>
                                        <span id='rx43'></span>
                                    </div>


                                    <div id='block-44' class="qo">
                                        <label for='ox44' class="ll">
                                            <input type='radio' name='option' id='ox44' class="on" />
                                            <em>pump capacity is greater than the system's needs</em></label>
                                        <span id='rx44'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 12 -->
                                <div class="ques">
                                    <p class="qn">12. A dirty lube oil strainer can result in _____________.
                                    </p>
                                    <hr>

                                    <div id='block-45' class="qo">
                                        <label for='ox45' class="ll">
                                            <input type='radio' name='option' id='ox45' class="on" />
                                            <em>crankcase dilution</em></label>
                                        <span id='rx45'></span>
                                    </div>


                                    <div id='block-46' class="qo">
                                        <label for='ox46' class="ll">
                                            <input type='radio' name='option' id='ox46' class="on" />
                                            <em>low lube oil temperature</em></label>
                                        <span id='rx46'></span>
                                    </div>


                                    <div id='block-47' class="qo">
                                        <label for='ox47' class="ll">
                                            <input type='radio' name='option' id='ox47' class="on" />
                                            <em>excessive oil consumption</em></label>
                                        <span id='rx47'></span>
                                    </div>


                                    <div id='block-48' class="qo">
                                        <label for='ox48' class="ll">
                                            <input type='radio' name='option' id='ox48' class="on" />
                                            <em>low bearing oil pressure</em></label>
                                        <span id='rx48'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 13 -->
                                <div class="ques">
                                    <p class="qn">13. Lube oil filters remove contaminants more efficiently if the oil
                                        being
                                        filtered is _____________.
                                    </p>
                                    <hr>

                                    <div id='block-49' class="qo">
                                        <label for='ox49' class="ll">
                                            <input type='radio' name='option' id='ox49' class="on" />
                                            <em>under high pressure
                                            </em></label>
                                        <span id='rx49'></span>
                                    </div>


                                    <div id='block-50' class="qo">
                                        <label for='ox50' class="ll">
                                            <input type='radio' name='option' id='ox50' class="on" />
                                            <em>under low pressure</em></label>
                                        <span id='rx50'></span>
                                    </div>


                                    <div id='block-51' class="qo">
                                        <label for='ox51' class="ll">
                                            <input type='radio' name='option' id='ox51' class="on" />
                                            <em>heated to reduce viscosity </em></label>
                                        <span id='rx51'></span>
                                    </div>


                                    <div id='block-52' class="qo">
                                        <label for='ox52' class="ll">
                                            <input type='radio' name='option' id='ox52' class="on" />
                                            <em>heated to reduce viscosity </em></label>
                                        <span id='rx52'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 14 -->
                                <div class="ques">
                                    <p class="qn">14. The pressure differential across a diesel engine lube oil system
                                        duplex filter should be checked to _________.
                                    </p>
                                    <hr>

                                    <div id='block-53' class="qo">
                                        <label for='ox53' class="ll">
                                            <input type='radio' name='option' id='ox53' class="on" />
                                            <em>determine the need for filter changing
                                            </em></label>
                                        <span id='rx53'></span>
                                    </div>


                                    <div id='block-54' class="qo">
                                        <label for='ox54' class="ll">
                                            <input type='radio' name='option' id='ox54' class="on" />
                                            <em>measure any change in oil viscosity
                                            </em></label>
                                        <span id='rx54'></span>
                                    </div>


                                    <div id='block-55' class="qo">
                                        <label for='ox55' class="ll">
                                            <input type='radio' name='option' id='ox55' class="on" />
                                            <em>prevent damage to the filter
                                            </em></label>
                                        <span id='rx55'></span>
                                    </div>


                                    <div id='block-56' class="qo">
                                        <label for='ox56' class="ll">
                                            <input type='radio' name='option' id='ox56' class="on" />
                                            <em>determine the need for batch filtration
                                            </em></label>
                                        <span id='rx56'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 15 -->
                                <div class="ques">
                                    <p class="qn">15. Lube oil in the fresh water cooling system of a diesel engine may
                                        result from a _____________.
                                    </p>
                                    <hr>

                                    <div id='block-57' class="qo">
                                        <label for='ox57' class="ll">
                                            <input type='radio' name='option' id='ox57' class="on" />
                                            <em>camshaft seizure
                                            </em></label>
                                        <span id='rx57'></span>
                                    </div>


                                    <div id='block-58' class="qo">
                                        <label for='ox58' class="ll">
                                            <input type='radio' name='option' id='ox58' class="on" />
                                            <em>lube oil pump failure
                                            </em></label>
                                        <span id='rx58'></span>
                                    </div>


                                    <div id='block-59' class="qo">
                                        <label for='ox59' class="ll">
                                            <input type='radio' name='option' id='ox59' class="on" />
                                            <em>lube oil cooler failure</em></label>
                                        <span id='rx59'></span>
                                    </div>


                                    <div id='block-60' class="qo">
                                        <label for='ox60' class="ll">
                                            <input type='radio' name='option' id='ox60' class="on" />
                                            <em>lube oil sump overflow</em></label>
                                        <span id='rx60'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 16 -->
                                <div class="ques">
                                    <p class="qn">16. Most large, low-speed, main propulsion diesel engines use duplex
                                        lube oil strainer to _____________.
                                    </p>
                                    <hr>

                                    <div id='block-61' class="qo">
                                        <label for='ox61' class="ll">
                                            <input type='radio' name='option' id='ox61' class="on" />
                                            <em>decrease the time required between cleanings
                                            </em></label>
                                        <span id='rx61'></span>
                                    </div>


                                    <div id='block-62' class="qo">
                                        <label for='ox62' class="ll">
                                            <input type='radio' name='option' id='ox62' class="on" />
                                            <em>remove water contamination
                                            </em></label>
                                        <span id='rx62'></span>
                                    </div>


                                    <div id='block-63' class="qo">
                                        <label for='ox63' class="ll">
                                            <input type='radio' name='option' id='ox63' class="on" />
                                            <em>ensure a positive flow of oil at all times
                                            </em></label>
                                        <span id='rx63'></span>
                                    </div>


                                    <div id='block-64' class="qo">
                                        <label for='ox64' class="ll">
                                            <input type='radio' name='option' id='ox64' class="on" />
                                            <em>ensure that all lube oil has been treated twice</em></label>
                                        <span id='rx64'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 17 -->
                                <div class="ques">
                                    <p class="qn">17. Which harmful consequence may be the result of lube oil sludge
                                        accumulation?
                                    </p>
                                    <hr>

                                    <div id='block-65' class="qo">
                                        <label for='ox65' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox65'
                                                class="on" />
                                            <em>Clogged oil pump suction screens.
                                            </em></label>
                                        <span id='rx65'></span>
                                    </div>


                                    <div id='block-66' class="qo">
                                        <label for='ox66' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox66'
                                                class="on" />
                                            <em>Increased oil operating temperatures.
                                            </em></label>
                                        <span id='rx66'></span>
                                    </div>


                                    <div id='block-67' class="qo">
                                        <label for='ox67' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                                class="on" />
                                            <em>Sticking piston rings.
                                            </em></label>
                                        <span id='rx67'></span>
                                    </div>


                                    <div id='block-68' class="qo">
                                        <label for='ox68' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                                class="on" />
                                            <em>All of the above
                                            </em></label>
                                        <span id='rx68'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 18 -->
                                <div class="ques">
                                    <p class="qn">18. The TBN value of diesel engine lube oil refers to its ability to
                                        _____________.
                                        <hr>

                                    <div id='block-69' class="qo">
                                        <label for='ox69' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox69'
                                                class="on" />
                                            <em>resist changes in viscosity with changes in temperature
                                            </em></label>
                                        <span id='rx69'></span>
                                    </div>


                                    <div id='block-70' class="qo">
                                        <label for='ox70' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox70'
                                                class="on" />
                                            <em>resist emulsification
                                            </em></label>
                                        <span id='rx70'></span>
                                    </div>


                                    <div id='block-71' class="qo">
                                        <label for='ox71' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                                class="on" />
                                            <em>neutralize acids
                                            </em></label>
                                        <span id='rx71'></span>
                                    </div>


                                    <div id='block-72' class="qo">
                                        <label for='ox72' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                                class="on" />
                                            <em>resist oxidation at high temperatures</em></label>
                                        <span id='rx72'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 19 -->
                                <div class="ques">
                                    <p class="qn">19. A dirty fuel oil filter is can be detected by ________. <br> I.
                                        fuel oil
                                        analysis<br> II. observing the pressure drop across the filter
                                    </p>
                                    <hr>

                                    <div id='block-73' class="qo">
                                        <label for='ox73' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox73'
                                                class="on" />
                                            <em>I only</em></label>
                                        <span id='rx73'></span>
                                    </div>


                                    <div id='block-74' class="qo">
                                        <label for='ox74' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox74'
                                                class="on" />
                                            <em>II only
                                            </em></label>
                                        <span id='rx74'></span>
                                    </div>


                                    <div id='block-75' class="qo">
                                        <label for='ox75' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                                class="on" />
                                            <em>either I or II
                                            </em></label>
                                        <span id='rx75'></span>
                                    </div>


                                    <div id='block-76' class="qo">
                                        <label for='ox76' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                                class="on" />
                                            <em>neither I nor II </em></label>
                                        <span id='rx76'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 20 -->
                                <div class="ques">
                                    <p class="qn">20. Sludge formation in a diesel engine lube oil system is caused by
                                        ____________.
                                    </p>
                                    <hr>

                                    <div id='block-77' class="qo">
                                        <label for='ox77' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox77'
                                                class="on" />
                                            <em>carbonization of oils from the combustion chambers
                                            </em></label>
                                        <span id='rx77'></span>
                                    </div>


                                    <div id='block-78' class="qo">
                                        <label for='ox78' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox78'
                                                class="on" />
                                            <em>emulsions of lube oil and water
                                            </em></label>
                                        <span id='rx78'></span>
                                    </div>


                                    <div id='block-79' class="qo">
                                        <label for='ox79' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                                class="on" />
                                            <em>coagulation of unburned fuel below the piston rings</em></label>
                                        <span id='rx79'></span>
                                    </div>


                                    <div id='block-80' class="qo">
                                        <label for='ox80' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                                class="on" />
                                            <em>All of the above.
                                            </em></label>
                                        <span id='rx80'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                    </div>
                                </div>
                                <hr>



                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/lubricating_system/asset/"; include($IPATH."lub_sidebar.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item active" aria-current="page"><a class="page-link"
                                href="/marine_engineering/lubricating_system/1.php">1</a></li>
                        <li class="page-item"><a class="page-link"
                                href="/marine_engineering/lubricating_system/2.php">2</a></li>
                        <li class="page-item"><a class="page-link"
                                href="/marine_engineering/lubricating_system/3.php">3</a></li>
                        <li class="page-item "><a class="page-link"
                                href="/marine_engineering/lubricating_system/4.php">4</a></li>
                        <li class="page-item "><a class="page-link"
                                href="/marine_engineering/lubricating_system/5.php">5</a></li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>