<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/scavenging_turbocharging/javascript/2.js"></script>

    <title>Scavenging,Turbocharging & Aircooling (Set 2)</title>
    <meta name="description"
        content="The small clearances existing between each of the blower..., Which of the following conditions may contribute to..., Which of the following conditions can cause below normal air..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, air, scavenging, aircooling, cooling, turbocharging, scavengingturbocharging aircooling, aircooling multiple, scavengingturbocharging aircooling multiple, aircooling multiple choice, scavengingturbocharging aircooling multiple choice, aircooling multiple choice questions, scavengingturbocharging aircooling multiple choice questions, services, submit, engine, diesel, pressure, exhaust, cylinder, intake, blower, turbocharger, system, manifold, power, stroke, oil, fuel, part, systems, engineering, marine, conditions, leaking, water, flow, increases, mechanical, combustion, high, turbocharged, four-strokecycle, aspiration, speed, constant, charge, control, increased, lobes, roots-type, provide, normal, prevent, leakage, lubrication, consumption, valves, describes, effect, temperatures, failure, overload, cylinders, overspeed, terms, gases, natural, injection, temperature, loop, crossflow, engines, opening, volume, early, forcing, gas, reduce, effective, decrease, average, scavenge, auxiliary, supercharging, previously, naturally, aspirated, efficiency, brake, instrumentation, heat, ship, of the, diesel engine, which of, the following, of a, the cylinder, the turbocharger, in the, part of, following conditions, the intake, intake manifold, will be, the engine, the exhaust, marine engineering, to the, on the, all of, the above, above submit, a turbocharged, the air, a four-strokecycle, four-strokecycle diesel, a diesel, with the, air charge, services marine, lobes and, roots-type blower, can cause, pressure in, turbocharged diesel, water in, air intake, best describes, describes the, manifold pressure, pressure will, be high, exhaust temperatures, temperatures will, engine to, used to, exhaust gases, from the, natural aspiration, scavenging air, for a, of air, last part, intake stroke, stroke only, only early, early part, forcing the, mean effective, effective pressure, pressure decrease, conditions is, by the, power the, a previously, previously naturally, naturally aspirated, mechanical efficiency, the turbocharging, which of the, of the following, part of the, the following conditions, all of the, of the above, the above submit, a four-strokecycle diesel, four-strokecycle diesel engine, a diesel engine, services marine engineering, of the turbocharger, pressure in the, a turbocharged diesel, turbocharged diesel engine, water in the, best describes the, intake manifold pressure, manifold pressure will, pressure will be, will be high, exhaust temperatures will, temperatures will be, the engine to, last part of, of the intake, the intake stroke, stroke only early, only early part, early part of, mean effective pressure, following conditions is, a previously naturally, previously naturally aspirated, which of the following, of the following conditions, all of the above, of the above submit, a four-strokecycle diesel engine, a turbocharged diesel engine, intake manifold pressure will, manifold pressure will be, exhaust temperatures will be, last part of the, part of the intake, of the intake stroke, stroke only early part, only early part of, early part of the, the following conditions is, a previously naturally aspirated, which of the following conditions, all of the above submit, intake manifold pressure will be, part of the intake stroke, stroke only early part of, only early part of the, of the following conditions is" />
    <style>
        .dfg {
        text-decoration: none;
        color: brown;
        font-family: sans-serif;
        }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/scavenging_turbocharging/2.php"
                        style="cursor: default;">SCAVENGING,TURBOCHARGING & AIRCOOLING:
                        <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Scavenging,Turbocharging & Aircooling (Set 2)</h1>
                                <hr>
                                <p>
                                <h4>Multiple Choice Questions</h4>
                                <hr>
                                <!-- Question 1 -->
                                <div class="ques">
                                    <p class="qn">1. The small clearances existing between each of the blower lobes,
                                        and between the lobes and casing of a Roots-type blower, must be
                                        maintained to ______________.
                                    </p>
                                    <hr>

                                    <div id='block-1' class="qo">
                                        <label for='ox1' class="ll">
                                            <input type='radio' name='option' id='ox1' class="on" />
                                            <em>provide for normal timing
                                            </em></label>
                                        <span id='rx1'></span>
                                    </div>


                                    <div id='block-2' class="qo">
                                        <label for='ox2' class="ll">
                                            <input type='radio' name='option' id='ox2' class="on" />
                                            <em>prevent blower oil leakage
                                            </em></label>
                                        <span id='rx2'></span>
                                    </div>


                                    <div id='block-3' class="qo">
                                        <label for='ox3' class="ll">
                                            <input type='radio' name='option' id='ox3' class="on" />
                                            <em>provide adequate blower lubrication</em></label>
                                        <span id='rx3'></span>
                                    </div>


                                    <div id='block-4' class="qo">
                                        <label for='ox4' class="ll">
                                            <input type='radio' name='option' id='ox4' class="on" />
                                            <em>prevent abnormal air leakage</em></label>
                                        <span id='rx4'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 2 -->
                                <div class="ques">
                                    <p class="qn">2. Which of the following conditions may contribute to the formation
                                        of
                                        deposits on the blades of the turbocharger turbine?
                                    </p>
                                    <hr>

                                    <div id='block-5' class="qo">
                                        <label for='ox5' class="ll">
                                            <input type='radio' name='option' id='ox5' class="on" />
                                            <em>Poor combustion
                                            </em></label>
                                        <span id='rx5'></span>
                                    </div>


                                    <div id='block-6' class="qo">
                                        <label for='ox6' class="ll">
                                            <input type='radio' name='option' id='ox6' class="on" />
                                            <em>High cylinder oil consumption
                                            </em></label>
                                        <span id='rx6'></span>
                                    </div>


                                    <div id='block-7' class="qo">
                                        <label for='ox7' class="ll">
                                            <input type='radio' name='option' id='ox7' class="on" />
                                            <em>Leaking exhaust valves
                                            </em></label>
                                        <span id='rx7'></span>
                                    </div>


                                    <div id='block-8' class="qo">
                                        <label for='ox8' class="ll">
                                            <input type='radio' name='option' id='ox8' class="on" />
                                            <em>All of the above.
                                            </em></label>
                                        <span id='rx8'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 3 -->
                                <div class="ques">
                                    <p class="qn">3. Which of the following conditions can cause below normal air
                                        pressure in the intake manifold of a turbocharged diesel engine?
                                    </p>
                                    <hr>

                                    <div id='block-9' class="qo">
                                        <label for='ox9' class="ll">
                                            <input type='radio' name='option' id='ox9' class="on" />
                                            <em>Excessive piston blow-by to the manifold. </em></label>
                                        <span id='rx9'></span>
                                    </div>


                                    <div id='block-10' class="qo">
                                        <label for='ox10' class="ll">
                                            <input type='radio' name='option' id='ox10' class="on" />
                                            <em>Insufficient cooling water flow.
                                            </em></label>
                                        <span id='rx10'></span>
                                    </div>


                                    <div id='block-11' class="qo">
                                        <label for='ox11' class="ll">
                                            <input type='radio' name='option' id='ox11' class="on" />
                                            <em>Accumulated water in the air boxes.
                                            </em></label>
                                        <span id='rx11'></span>
                                    </div>


                                    <div id='block-12' class="qo">
                                        <label for='ox12' class="ll">
                                            <input type='radio' name='option' id='ox12' class="on" />
                                            <em>Clogged air intake filters.</em></label>
                                        <span id='rx12'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 4 -->
                                <div class="ques">
                                    <p class="qn">4. If the turbocharger of a four-stroke/cycle diesel engine fails to
                                        operate, which of the following statements best describes the
                                        probable effect?
                                    </p>
                                    <hr>

                                    <div id='block-13' class="qo">
                                        <label for='ox13' class="ll">
                                            <input type='radio' name='option' id='ox13' class="on" />
                                            <em>Intake manifold pressure will be high.
                                            </em></label>
                                        <span id='rx13'></span>
                                    </div>


                                    <div id='block-14' class="qo">
                                        <label for='ox14' class="ll">
                                            <input type='radio' name='option' id='ox14' class="on" />
                                            <em>Intake manifold pressure will be unaffected.
                                            </em></label>
                                        <span id='rx14'></span>
                                    </div>


                                    <div id='block-15' class="qo">
                                        <label for='ox15' class="ll">
                                            <input type='radio' name='option' id='ox15' class="on" />
                                            <em>Exhaust temperatures will be high.
                                            </em></label>
                                        <span id='rx15'></span>
                                    </div>


                                    <div id='block-16' class="qo">
                                        <label for='ox16' class="ll">
                                            <input type='radio' name='option' id='ox16' class="on" />
                                            <em>Exhaust temperatures will be low.
                                            </em></label>
                                        <span id='rx16'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 5 -->
                                <div class="ques">
                                    <p class="qn">5. A sudden power loss from a turbocharged and aftercooled diesel
                                        engine is an indication of a/an ______________.
                                    </p>
                                    <hr>

                                    <div id='block-17' class="qo">
                                        <label for='ox17' class="ll">
                                            <input type='radio' name='option' id='ox17' class="on" />
                                            <em>turbocharger malfunction or failure</em></label>
                                        <span id='rx17'></span>
                                    </div>


                                    <div id='block-18' class="qo">
                                        <label for='ox18' class="ll">
                                            <input type='radio' name='option' id='ox18' class="on" />
                                            <em>crankcase exhauster overload</em></label>
                                        <span id='rx18'></span>
                                    </div>


                                    <div id='block-19' class="qo">
                                        <label for='ox19' class="ll">
                                            <input type='radio' name='option' id='ox19' class="on" />
                                            <em>overload on the intercooler</em></label>
                                        <span id='rx19'></span>
                                    </div>


                                    <div id='block-20' class="qo">
                                        <label for='ox20' class="ll">
                                            <input type='radio' name='option' id='ox20' class="on" />
                                            <em>obstruction in the engine cylinders
                                            </em></label>
                                        <span id='rx20'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 6 -->
                                <div class="ques">
                                    <p class="qn">6. Leaking oil seals on a diesel engine turbocharger can cause
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-21' class="qo">
                                        <label for='ox21' class="ll">
                                            <input type='radio' name='option' id='ox21' class="on" />
                                            <em>the engine to run after the fuel has been secured
                                            </em></label>
                                        <span id='rx21'></span>
                                    </div>


                                    <div id='block-22' class="qo">
                                        <label for='ox22' class="ll">
                                            <input type='radio' name='option' id='ox22' class="on" />
                                            <em>the engine to overspeed
                                            </em></label>
                                        <span id='rx22'></span>
                                    </div>


                                    <div id='block-23' class="qo">
                                        <label for='ox23' class="ll">
                                            <input type='radio' name='option' id='ox23' class="on" />
                                            <em>a fire
                                            </em></label>
                                        <span id='rx23'></span>
                                    </div>


                                    <div id='block-24' class="qo">
                                        <label for='ox24' class="ll">
                                            <input type='radio' name='option' id='ox24' class="on" />
                                            <em>all of the above
                                            </em></label>
                                        <span id='rx24'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 7 -->
                                <div class="ques">
                                    <p class="qn">7. Which of the following terms best describes the Roots-type blower
                                        used to supercharge a diesel engine?
                                    </p>
                                    <hr>

                                    <div id='block-25' class="qo">
                                        <label for='ox25' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox25'
                                                class="on" />
                                            <em>Rotary vane</em></label>
                                        <span id='rx25'></span>
                                    </div>


                                    <div id='block-26' class="qo">
                                        <label for='ox26' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox26'
                                                class="on" />
                                            <em>Positive displacement
                                            </em></label>
                                        <span id='rx26'></span>
                                    </div>


                                    <div id='block-27' class="qo">
                                        <label for='ox27' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                                class="on" />
                                            <em>Axial flow</em></label>
                                        <span id='rx27'></span>
                                    </div>


                                    <div id='block-28' class="qo">
                                        <label for='ox28' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                                class="on" />
                                            <em>centrifugal
                                            </em></label>
                                        <span id='rx28'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 8 -->
                                <div class="ques">
                                    <p class="qn">8. Exhaust gases are generally removed from the cylinders of a
                                        two-stroke/cycle diesel engine by
                                        ______________
                                    </p>
                                    <hr>

                                    <div id='block-29' class="qo">
                                        <label for='ox29' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox29'
                                                class="on" />
                                            <em>natural aspiration
                                            </em></label>
                                        <span id='rx29'></span>
                                    </div>


                                    <div id='block-30' class="qo">
                                        <label for='ox30' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox30'
                                                class="on" />
                                            <em>natural aspiration
                                            </em></label>
                                        <span id='rx30'></span>
                                    </div>


                                    <div id='block-31' class="qo">
                                        <label for='ox31' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                                class="on" />
                                            <em>air cells
                                            </em></label>
                                        <span id='rx31'></span>
                                    </div>


                                    <div id='block-32' class="qo">
                                        <label for='ox32' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                                class="on" />
                                            <em>scavenging air
                                            </em></label>
                                        <span id='rx32'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 9 -->
                                <div class="ques">
                                    <p class="qn">9. The speed of the turbocharger for a four-stroke/cycle diesel engine
                                        driving a generator at constant speed depends on the
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-33' class="qo">
                                        <label for='ox33' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox33'
                                                class="on" />
                                            <em>engine speed
                                            </em></label>
                                        <span id='rx33'></span>
                                    </div>


                                    <div id='block-34' class="qo">
                                        <label for='ox34' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox34'
                                                class="on" />
                                            <em>kilowatt load
                                            </em></label>
                                        <span id='rx34'></span>
                                    </div>


                                    <div id='block-35' class="qo">
                                        <label for='ox35' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                                class="on" />
                                            <em>fuel injection pressure
                                            </em></label>
                                        <span id='rx35'></span>
                                    </div>


                                    <div id='block-36' class="qo">
                                        <label for='ox36' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                                class="on" />
                                            <em>air intake manifold temperature
                                            </em></label>
                                        <span id='rx36'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 10 -->
                                <div class="ques">
                                    <p class="qn">10. The principal difference between loop scavenging and crossflow
                                        scavenging, as used in single acting diesel engines, is the
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-37' class="qo">
                                        <label for='ox37' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox37'
                                                class="on" />
                                            <em>direction of air flow within the cylinder
                                            </em></label>
                                        <span id='rx37'></span>
                                    </div>


                                    <div id='block-38' class="qo">
                                        <label for='ox38' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox38'
                                                class="on" />
                                            <em>sequence of port opening
                                            </em></label>
                                        <span id='rx38'></span>
                                    </div>


                                    <div id='block-39' class="qo">
                                        <label for='ox39' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                                class="on" />
                                            <em>method of opening exhaust ports
                                            </em></label>
                                        <span id='rx39'></span>
                                    </div>


                                    <div id='block-40' class="qo">
                                        <label for='ox40' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                                class="on" />
                                            <em>volume of air admitted to the cylinder
                                            </em></label>
                                        <span id='rx40'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 11 -->
                                <div class="ques">
                                    <p class="qn">11. Scavenging in a four-stroke/cycle diesel engine occurs during the
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-41' class="qo">
                                        <label for='ox41' class="ll">
                                            <input type='radio' name='option' id='ox41' class="on" />
                                            <em>last part of the exhaust stroke, and the first part of the intake stroke
                                            </em></label>
                                        <span id='rx41'></span>
                                    </div>


                                    <div id='block-42' class="qo">
                                        <label for='ox42' class="ll">
                                            <input type='radio' name='option' id='ox42' class="on" />
                                            <em>last part of the intake stroke only</em></label>
                                        <span id='rx42'></span>
                                    </div>


                                    <div id='block-43' class="qo">
                                        <label for='ox43' class="ll">
                                            <input type='radio' name='option' id='ox43' class="on" />
                                            <em>early part of the injection stroke only</em></label>
                                        <span id='rx43'></span>
                                    </div>


                                    <div id='block-44' class="qo">
                                        <label for='ox44' class="ll">
                                            <input type='radio' name='option' id='ox44' class="on" />
                                            <em>early part of the power stroke</em></label>
                                        <span id='rx44'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 12 -->
                                <div class="ques">
                                    <p class="qn">12. The term "diesel engine scavenging" means ____________.
                                    </p>
                                    <hr>

                                    <div id='block-45' class="qo">
                                        <label for='ox45' class="ll">
                                            <input type='radio' name='option' id='ox45' class="on" />
                                            <em>delivering more air into the cylinder than it would normally receive
                                                during an ordinary charging process
                                            </em></label>
                                        <span id='rx45'></span>
                                    </div>


                                    <div id='block-46' class="qo">
                                        <label for='ox46' class="ll">
                                            <input type='radio' name='option' id='ox46' class="on" />
                                            <em>forcing the products of combustion out of the cylinder with the fresh
                                                air charge
                                            </em></label>
                                        <span id='rx46'></span>
                                    </div>


                                    <div id='block-47' class="qo">
                                        <label for='ox47' class="ll">
                                            <input type='radio' name='option' id='ox47' class="on" />
                                            <em>collecting the air charge at the air cleaner
                                            </em></label>
                                        <span id='rx47'></span>
                                    </div>


                                    <div id='block-48' class="qo">
                                        <label for='ox48' class="ll">
                                            <input type='radio' name='option' id='ox48' class="on" />
                                            <em>combustion and expansion of hot gas
                                            </em></label>
                                        <span id='rx48'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 13 -->
                                <div class="ques">
                                    <p class="qn">13. Cooling the intake air supplied to a diesel engine will
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-49' class="qo">
                                        <label for='ox49' class="ll">
                                            <input type='radio' name='option' id='ox49' class="on" />
                                            <em>reduce mean effective pressure
                                            </em></label>
                                        <span id='rx49'></span>
                                    </div>


                                    <div id='block-50' class="qo">
                                        <label for='ox50' class="ll">
                                            <input type='radio' name='option' id='ox50' class="on" />
                                            <em>decrease average compression pressure
                                            </em></label>
                                        <span id='rx50'></span>
                                    </div>


                                    <div id='block-51' class="qo">
                                        <label for='ox51' class="ll">
                                            <input type='radio' name='option' id='ox51' class="on" />
                                            <em>decrease air charge density</em></label>
                                        <span id='rx51'></span>
                                    </div>


                                    <div id='block-52' class="qo">
                                        <label for='ox52' class="ll">
                                            <input type='radio' name='option' id='ox52' class="on" />
                                            <em>increase power output
                                            </em></label>
                                        <span id='rx52'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 14 -->
                                <div class="ques">
                                    <p class="qn">14. Which of the following conditions is indicated by the presence of
                                        water in the scavenging air receiver?
                                    </p>
                                    <hr>

                                    <div id='block-53' class="qo">
                                        <label for='ox53' class="ll">
                                            <input type='radio' name='option' id='ox53' class="on" />
                                            <em>Leaking cylinder head gaskets
                                            </em></label>
                                        <span id='rx53'></span>
                                    </div>


                                    <div id='block-54' class="qo">
                                        <label for='ox54' class="ll">
                                            <input type='radio' name='option' id='ox54' class="on" />
                                            <em>Leaking aftercooler
                                            </em></label>
                                        <span id='rx54'></span>
                                    </div>


                                    <div id='block-55' class="qo">
                                        <label for='ox55' class="ll">
                                            <input type='radio' name='option' id='ox55' class="on" />
                                            <em>Excessively low scavenge air temperature
                                            </em></label>
                                        <span id='rx55'></span>
                                    </div>


                                    <div id='block-56' class="qo">
                                        <label for='ox56' class="ll">
                                            <input type='radio' name='option' id='ox56' class="on" />
                                            <em>Auxiliary blower failure
                                            </em></label>
                                        <span id='rx56'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 15 -->
                                <div class="ques">
                                    <p class="qn">15. Forcing the exhaust gases from the cylinder of an operating diesel
                                        engine with the aid of a blower is known as ________.
                                    </p>
                                    <hr>

                                    <div id='block-57' class="qo">
                                        <label for='ox57' class="ll">
                                            <input type='radio' name='option' id='ox57' class="on" />
                                            <em>scavenging
                                            </em></label>
                                        <span id='rx57'></span>
                                    </div>


                                    <div id='block-58' class="qo">
                                        <label for='ox58' class="ll">
                                            <input type='radio' name='option' id='ox58' class="on" />
                                            <em>forced draft
                                            </em></label>
                                        <span id='rx58'></span>
                                    </div>


                                    <div id='block-59' class="qo">
                                        <label for='ox59' class="ll">
                                            <input type='radio' name='option' id='ox59' class="on" />
                                            <em>turbocharging</em></label>
                                        <span id='rx59'></span>
                                    </div>


                                    <div id='block-60' class="qo">
                                        <label for='ox60' class="ll">
                                            <input type='radio' name='option' id='ox60' class="on" />
                                            <em>aspiration</em></label>
                                        <span id='rx60'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 16 -->
                                <div class="ques">
                                    <p class="qn">16. "Loop," "uniflow," "crossflow," and "return-flow" are terms used
                                        to
                                        describe various types of _____________.
                                    </p>
                                    <hr>

                                    <div id='block-61' class="qo">
                                        <label for='ox61' class="ll">
                                            <input type='radio' name='option' id='ox61' class="on" />
                                            <em>control air circuits
                                            </em></label>
                                        <span id='rx61'></span>
                                    </div>


                                    <div id='block-62' class="qo">
                                        <label for='ox62' class="ll">
                                            <input type='radio' name='option' id='ox62' class="on" />
                                            <em>supercharging
                                            </em></label>
                                        <span id='rx62'></span>
                                    </div>


                                    <div id='block-63' class="qo">
                                        <label for='ox63' class="ll">
                                            <input type='radio' name='option' id='ox63' class="on" />
                                            <em>turbochargers
                                            </em></label>
                                        <span id='rx63'></span>
                                    </div>


                                    <div id='block-64' class="qo">
                                        <label for='ox64' class="ll">
                                            <input type='radio' name='option' id='ox64' class="on" />
                                            <em>scavenging
                                            </em></label>
                                        <span id='rx64'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 17 -->
                                <div class="ques">
                                    <p class="qn">17. The exhaust system for a turbocharged diesel engine functions to
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-65' class="qo">
                                        <label for='ox65' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox65'
                                                class="on" />
                                            <em>power the aftercoolers</em></label>
                                        <span id='rx65'></span>
                                    </div>


                                    <div id='block-66' class="qo">
                                        <label for='ox66' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox66'
                                                class="on" />
                                            <em>power the turbocharger
                                            </em></label>
                                        <span id='rx66'></span>
                                    </div>


                                    <div id='block-67' class="qo">
                                        <label for='ox67' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                                class="on" />
                                            <em>reduce the cylinder scavenge effect
                                            </em></label>
                                        <span id='rx67'></span>
                                    </div>


                                    <div id='block-68' class="qo">
                                        <label for='ox68' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                                class="on" />
                                            <em>cool the turbocharger
                                            </em></label>
                                        <span id='rx68'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 18 -->
                                <div class="ques">
                                    <p class="qn">18. Which of the following beneficial results can be expected from
                                        supercharging a previously naturally aspirated engine?
                                    </p>
                                    <hr>

                                    <div id='block-69' class="qo">
                                        <label for='ox69' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox69'
                                                class="on" />
                                            <em>Increased turbulence
                                            </em></label>
                                        <span id='rx69'></span>
                                    </div>


                                    <div id='block-70' class="qo">
                                        <label for='ox70' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox70'
                                                class="on" />
                                            <em>Increased mechanical efficiency
                                            </em></label>
                                        <span id='rx70'></span>
                                    </div>


                                    <div id='block-71' class="qo">
                                        <label for='ox71' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                                class="on" />
                                            <em>Increased brake mean effective pressure
                                            </em></label>
                                        <span id='rx71'></span>
                                    </div>


                                    <div id='block-72' class="qo">
                                        <label for='ox72' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                                class="on" />
                                            <em>All of the above.
                                            </em></label>
                                        <span id='rx72'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 19 -->
                                <div class="ques">
                                    <p class="qn">19. Which of the following conditions is realized by the turbocharging
                                        of
                                        a previously naturally aspirated diesel engine?
                                    </p>
                                    <hr>

                                    <div id='block-73' class="qo">
                                        <label for='ox73' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox73'
                                                class="on" />
                                            <em>Ignition lag increases. </em></label>
                                        <span id='rx73'></span>
                                    </div>


                                    <div id='block-74' class="qo">
                                        <label for='ox74' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox74'
                                                class="on" />
                                            <em>Lube oil system pressure increases.
                                            </em></label>
                                        <span id='rx74'></span>
                                    </div>


                                    <div id='block-75' class="qo">
                                        <label for='ox75' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                                class="on" />
                                            <em>Brake specific fuel consumption increases.
                                            </em></label>
                                        <span id='rx75'></span>
                                    </div>


                                    <div id='block-76' class="qo">
                                        <label for='ox76' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                                class="on" />
                                            <em>Mechanical efficiency increases.
                                            </em></label>
                                        <span id='rx76'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 20 -->
                                <div class="ques">
                                    <p class="qn">20. Which of the turbocharging systems listed operates with the least
                                        average back pressure in the exhaust manifold?
                                    </p>
                                    <hr>

                                    <div id='block-77' class="qo">
                                        <label for='ox77' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox77'
                                                class="on" />
                                            <em>Constant volume
                                            </em></label>
                                        <span id='rx77'></span>
                                    </div>


                                    <div id='block-78' class="qo">
                                        <label for='ox78' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox78'
                                                class="on" />
                                            <em>Constant pressure
                                            </em></label>
                                        <span id='rx78'></span>
                                    </div>


                                    <div id='block-79' class="qo">
                                        <label for='ox79' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                                class="on" />
                                            <em>Pulse pressure
                                            </em></label>
                                        <span id='rx79'></span>
                                    </div>


                                    <div id='block-80' class="qo">
                                        <label for='ox80' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                                class="on" />
                                            <em>Radial flow
                                            </em></label>
                                        <span id='rx80'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                    </div>
                                </div>
                                <hr>



                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/scavenging_turbocharging/asset/"; include($IPATH."scavenging_turbocharging.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/scavenging_turbocharging/1.php">1</a>
                        </li>
                        <li class="page-item active" aria-current="page">
                            <a class="page-link" href="/marine_engineering/scavenging_turbocharging/2.php">2</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/scavenging_turbocharging/3.php">3</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/scavenging_turbocharging/4.php">4</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/scavenging_turbocharging/5.php">5</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>