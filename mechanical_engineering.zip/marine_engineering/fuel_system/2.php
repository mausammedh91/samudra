<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/fuel_system/javascript/2.js"></script>

    <title>Fuel Systems & Maintenance (Set 2)| M. C. Q.</title>
    <meta name="description"
        content="The desirable properties of a marine fuel oil should..., A substance found in residual fuels which tends to cause ..., Which of the listed factors will indicate the most about..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, fuel, systems, system, maintenance, fuel systems, systems maintenance, fuel systems maintenance, maintenance multiple, systems maintenance multiple, maintenance multiple choice, fuel systems maintenance multiple, systems maintenance multiple choice, maintenance multiple choice questions, fuel systems maintenance multiple choice, systems maintenance multiple choice questions, services, important, of fuel, submit, oil, cetane, number, diesel, type, high, viscosity, engine, fuels, ignition, lag, marine, injection, air, engineering, point, lube, filter, pumps, heating, sulphur, content, strainer, water, pump, auxiliary, bag, duplex, significance, indication, affects, amount, mechanical, properties, flash, corrosion, listed, ability, metal, steel, sample, octane, sludge, tank, installed, settling, caused, pressure, simplex, absorbent, schedule, boiler, reduced, combustion, process, overspeed, rates, engines, quality, cleaning, cover, instrumentation, control, heat, ship, cetane number, fuel oil, the fuel, of the, in the, the cetane, number of, diesel engine, to be, of a, of diesel, injection lag, diesel fuel, the lube, number is, is an, marine engineering, and high, high viscosity, sulphur content, which of, a diesel, of 45, having a, a high, lag is, filter bag, bag type, number the, an indication, indication of, affects the, the amount, amount of, lube oil, services marine, flash point, point and, viscosity low, heating value, value and, ability of, a fuel, in a, oil strainer, oil the, of 55, octane number, the diesel, used to, may be, caused by, either the, simplex type, type or, type absorbent, absorbent type, duplex type, type submit, of an, the following, lag the, the fuels, fuels viscosity, ignition lag, is reduced, reduced with, with fuels, fuels having, high cetane, is of, of little, little significance, significance in, the combustion, combustion process, fuel is, is important, viscosity submit, the ignition, ignition quality, quality of, the cetane number, the fuel oil, in the fuel, cetane number of, of the fuel, cetane number is, which of the, a diesel engine, having a high, filter bag type, cetane number the, number the cetane, is an indication, an indication of, indication of the, of diesel fuel, the amount of, the lube oil, services marine engineering, flash point and, point and high, and high viscosity, high viscosity low, heating value and, ability of a, of a fuel, in a diesel, fuel oil strainer, number of 55, number of 45, octane number of, type absorbent type, of the following, injection lag the, lag the cetane, number is an, of the fuels, the fuels viscosity, ignition lag is, lag is reduced, is reduced with, reduced with fuels, with fuels having, fuels having a, a high cetane, high cetane number, number is of, is of little, of little significance, little significance in, significance in the, in the combustion, the combustion process, diesel fuel is, the ignition quality, ignition quality of, the cetane number is, cetane number the cetane, number the cetane number, is an indication of, an indication of the, flash point and high, point and high viscosity, and high viscosity low, in a diesel engine, in the fuel oil, which of the following, injection lag the cetane, lag the cetane number, cetane number is an, number is an indication, indication of the fuels, of the fuels viscosity, ignition lag is reduced, lag is reduced with, is reduced with fuels, reduced with fuels having, with fuels having a, fuels having a high, having a high cetane, a high cetane number, high cetane number the, cetane number is of, number is of little, is of little significance, of little significance in, little significance in the, significance in the combustion, in the combustion process, of diesel fuel is, the ignition quality of, cetane number the cetane number, is an indication of the, flash point and high viscosity, point and high viscosity low, injection lag the cetane number, lag the cetane number is, the cetane number is an, cetane number is an indication, number is an indication of, an indication of the fuels, indication of the fuels viscosity, ignition lag is reduced with, lag is reduced with fuels, is reduced with fuels having, reduced with fuels having a, with fuels having a high, fuels having a high cetane, having a high cetane number, a high cetane number the, high cetane number the cetane, number the cetane number is, the cetane number is of, cetane number is of little, number is of little significance, is of little significance in, of little significance in the, little significance in the combustion, significance in the combustion process" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/fuel_system/2.php" style="cursor: default;">FUEL
                        SYSTEMS: <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Fuel Systems & Maintenance (Set 2)</h1>
                                <hr>
                                <p>
                                <h4>Multiple Choice Questions</h4>
                                <hr>
                                <!-- Question 1 -->
                                <div class="ques">
                                    <p class="qn">1. The desirable properties of a marine fuel oil should include
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-1' class="qo">
                                        <label for='ox1' class="ll">
                                            <input type='radio' name='option' id='ox1' class="on" />
                                            <em>high flash point and high viscosity</em></label>
                                        <span id='rx1'></span>
                                    </div>


                                    <div id='block-2' class="qo">
                                        <label for='ox2' class="ll">
                                            <input type='radio' name='option' id='ox2' class="on" />
                                            <em>low flash point and high viscosity
                                            </em></label>
                                        <span id='rx2'></span>
                                    </div>


                                    <div id='block-3' class="qo">
                                        <label for='ox3' class="ll">
                                            <input type='radio' name='option' id='ox3' class="on" />
                                            <em>low heating value and high sulphur content</em></label>
                                        <span id='rx3'></span>
                                    </div>


                                    <div id='block-4' class="qo">
                                        <label for='ox4' class="ll">
                                            <input type='radio' name='option' id='ox4' class="on" />
                                            <em>high heating value and low sulphur content</em></label>
                                        <span id='rx4'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 2 -->
                                <div class="ques">
                                    <p class="qn">2. A substance found in residual fuels which tends to cause exhaust
                                        valve corrosion and grooving, is ____________.
                                    </p>
                                    <hr>

                                    <div id='block-5' class="qo">
                                        <label for='ox5' class="ll">
                                            <input type='radio' name='option' id='ox5' class="on" />
                                            <em>carbon
                                            </em></label>
                                        <span id='rx5'></span>
                                    </div>


                                    <div id='block-6' class="qo">
                                        <label for='ox6' class="ll">
                                            <input type='radio' name='option' id='ox6' class="on" />
                                            <em>vanadium
                                            </em></label>
                                        <span id='rx6'></span>
                                    </div>


                                    <div id='block-7' class="qo">
                                        <label for='ox7' class="ll">
                                            <input type='radio' name='option' id='ox7' class="on" />
                                            <em>calcium
                                            </em></label>
                                        <span id='rx7'></span>
                                    </div>


                                    <div id='block-8' class="qo">
                                        <label for='ox8' class="ll">
                                            <input type='radio' name='option' id='ox8' class="on" />
                                            <em>hydrogen
                                            </em></label>
                                        <span id='rx8'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 3 -->
                                <div class="ques">
                                    <p class="qn">3. Which of the listed factors will indicate the most about the
                                        ability of
                                        a fuel to ignite in a diesel engine?
                                    </p>
                                    <hr>

                                    <div id='block-9' class="qo">
                                        <label for='ox9' class="ll">
                                            <input type='radio' name='option' id='ox9' class="on" />
                                            <em>Viscosity</em></label>
                                        <span id='rx9'></span>
                                    </div>


                                    <div id='block-10' class="qo">
                                        <label for='ox10' class="ll">
                                            <input type='radio' name='option' id='ox10' class="on" />
                                            <em>sulphur content
                                            </em></label>
                                        <span id='rx10'></span>
                                    </div>


                                    <div id='block-11' class="qo">
                                        <label for='ox11' class="ll">
                                            <input type='radio' name='option' id='ox11' class="on" />
                                            <em>Pour point
                                            </em></label>
                                        <span id='rx11'></span>
                                    </div>


                                    <div id='block-12' class="qo">
                                        <label for='ox12' class="ll">
                                            <input type='radio' name='option' id='ox12' class="on" />
                                            <em>Cetane number</em></label>
                                        <span id='rx12'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 4 -->
                                <div class="ques">
                                    <p class="qn">4. To minimize corrosion, fuel oil strainer disks, spacers and scraper
                                        blades are made of _____________.
                                    </p>
                                    <hr>

                                    <div id='block-13' class="qo">
                                        <label for='ox13' class="ll">
                                            <input type='radio' name='option' id='ox13' class="on" />
                                            <em>brass
                                            </em></label>
                                        <span id='rx13'></span>
                                    </div>


                                    <div id='block-14' class="qo">
                                        <label for='ox14' class="ll">
                                            <input type='radio' name='option' id='ox14' class="on" />
                                            <em>copper
                                            </em></label>
                                        <span id='rx14'></span>
                                    </div>


                                    <div id='block-15' class="qo">
                                        <label for='ox15' class="ll">
                                            <input type='radio' name='option' id='ox15' class="on" />
                                            <em>iron
                                            </em></label>
                                        <span id='rx15'></span>
                                    </div>


                                    <div id='block-16' class="qo">
                                        <label for='ox16' class="ll">
                                            <input type='radio' name='option' id='ox16' class="on" />
                                            <em>monel metal or stainless steel</em></label>
                                        <span id='rx16'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 5 -->
                                <div class="ques">
                                    <p class="qn">5. A mixture of 45% cetane and 55% alpha-methyl-naphthalene is
                                        found to have the same ignition delay as a sample of diesel oil. The
                                        sample can be described as having a/an __________.
                                    </p>
                                    <hr>

                                    <div id='block-17' class="qo">
                                        <label for='ox17' class="ll">
                                            <input type='radio' name='option' id='ox17' class="on" />
                                            <em>cetane number of 55</em></label>
                                        <span id='rx17'></span>
                                    </div>


                                    <div id='block-18' class="qo">
                                        <label for='ox18' class="ll">
                                            <input type='radio' name='option' id='ox18' class="on" />
                                            <em>cetane number of 45</em></label>
                                        <span id='rx18'></span>
                                    </div>


                                    <div id='block-19' class="qo">
                                        <label for='ox19' class="ll">
                                            <input type='radio' name='option' id='ox19' class="on" />
                                            <em>octane number of 55</em></label>
                                        <span id='rx19'></span>
                                    </div>


                                    <div id='block-20' class="qo">
                                        <label for='ox20' class="ll">
                                            <input type='radio' name='option' id='ox20' class="on" />
                                            <em>octane number of 45
                                            </em></label>
                                        <span id='rx20'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 6 -->
                                <div class="ques">
                                    <p class="qn">6. The sludge tank installed in the diesel engine room is used to
                                        collect
                                        _____________. <br> I. sludge from the fuel oil settling tanks and
                                        centrifuge <br> II. water that has been collected in the settling tank.
                                    </p>
                                    <hr>

                                    <div id='block-21' class="qo">
                                        <label for='ox21' class="ll">
                                            <input type='radio' name='option' id='ox21' class="on" />
                                            <em>I only
                                            </em></label>
                                        <span id='rx21'></span>
                                    </div>


                                    <div id='block-22' class="qo">
                                        <label for='ox22' class="ll">
                                            <input type='radio' name='option' id='ox22' class="on" />
                                            <em>II only
                                            </em></label>
                                        <span id='rx22'></span>
                                    </div>


                                    <div id='block-23' class="qo">
                                        <label for='ox23' class="ll">
                                            <input type='radio' name='option' id='ox23' class="on" />
                                            <em>both I and II</em></label>
                                        <span id='rx23'></span>
                                    </div>


                                    <div id='block-24' class="qo">
                                        <label for='ox24' class="ll">
                                            <input type='radio' name='option' id='ox24' class="on" />
                                            <em>neither I or II
                                            </em></label>
                                        <span id='rx24'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 7 -->
                                <div class="ques">
                                    <p class="qn">7. Injection lag in a diesel engine may be caused by _________.
                                    </p>
                                    <hr>

                                    <div id='block-25' class="qo">
                                        <label for='ox25' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox25'
                                                class="on" />
                                            <em>a higher cetane number of fuel oil</em></label>
                                        <span id='rx25'></span>
                                    </div>


                                    <div id='block-26' class="qo">
                                        <label for='ox26' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox26'
                                                class="on" />
                                            <em>the diesel fuel used having a high viscosity
                                            </em></label>
                                        <span id='rx26'></span>
                                    </div>


                                    <div id='block-27' class="qo">
                                        <label for='ox27' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                                class="on" />
                                            <em>mechanical rigidity in the lube pump mechanism </em></label>
                                        <span id='rx27'></span>
                                    </div>


                                    <div id='block-28' class="qo">
                                        <label for='ox28' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                                class="on" />
                                            <em>a decrease in the fuel pump delivery pressure
                                            </em></label>
                                        <span id='rx28'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 8 -->
                                <div class="ques">
                                    <p class="qn">8. Diesel engine injection lag is caused by _____________.
                                    </p>
                                    <hr>

                                    <div id='block-29' class="qo">
                                        <label for='ox29' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox29'
                                                class="on" />
                                            <em>compressibility of the fuel
                                            </em></label>
                                        <span id='rx29'></span>
                                    </div>


                                    <div id='block-30' class="qo">
                                        <label for='ox30' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox30'
                                                class="on" />
                                            <em>high fuel oil supply flow </em></label>
                                        <span id='rx30'></span>
                                    </div>


                                    <div id='block-31' class="qo">
                                        <label for='ox31' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                                class="on" />
                                            <em>scored plunger and barrel packing
                                            </em></label>
                                        <span id='rx31'></span>
                                    </div>


                                    <div id='block-32' class="qo">
                                        <label for='ox32' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                                class="on" />
                                            <em>excessive air turbulence
                                            </em></label>
                                        <span id='rx32'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 9 -->
                                <div class="ques">
                                    <p class="qn">9. Automatically fired auxiliary boilers use fuel oil strainer
                                        arrangements of either the simplex type or _____________.
                                    </p>
                                    <hr>

                                    <div id='block-33' class="qo">
                                        <label for='ox33' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox33'
                                                class="on" />
                                            <em>filter bag type
                                            </em></label>
                                        <span id='rx33'></span>
                                    </div>


                                    <div id='block-34' class="qo">
                                        <label for='ox34' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox34'
                                                class="on" />
                                            <em>metal disc type</em></label>
                                        <span id='rx34'></span>
                                    </div>


                                    <div id='block-35' class="qo">
                                        <label for='ox35' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                                class="on" />
                                            <em>absorbent type
                                            </em></label>
                                        <span id='rx35'></span>
                                    </div>


                                    <div id='block-36' class="qo">
                                        <label for='ox36' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                                class="on" />
                                            <em>duplex type
                                            </em></label>
                                        <span id='rx36'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 10 -->
                                <div class="ques">
                                    <p class="qn">10. Piping from booster pumps to injection systems are to be at least
                                        ________.
                                    </p>
                                    <hr>

                                    <div id='block-37' class="qo">
                                        <label for='ox37' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox37'
                                                class="on" />
                                            <em>schedule 60
                                            </em></label>
                                        <span id='rx37'></span>
                                    </div>


                                    <div id='block-38' class="qo">
                                        <label for='ox38' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox38'
                                                class="on" />
                                            <em>schedule 80
                                            </em></label>
                                        <span id='rx38'></span>
                                    </div>


                                    <div id='block-39' class="qo">
                                        <label for='ox39' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                                class="on" />
                                            <em>standard seamless steel
                                            </em></label>
                                        <span id='rx39'></span>
                                    </div>


                                    <div id='block-40' class="qo">
                                        <label for='ox40' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                                class="on" />
                                            <em>none of the above
                                            </em></label>
                                        <span id='rx40'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 11 -->
                                <div class="ques">
                                    <p class="qn">11. The fuel oil strainers located in the fuel oil service system of
                                        an
                                        automatic auxiliary heating boiler are either the duplex type or the
                                        _______________.
                                    </p>
                                    <hr>

                                    <div id='block-41' class="qo">
                                        <label for='ox41' class="ll">
                                            <input type='radio' name='option' id='ox41' class="on" />
                                            <em>filter bag type</em></label>
                                        <span id='rx41'></span>
                                    </div>


                                    <div id='block-42' class="qo">
                                        <label for='ox42' class="ll">
                                            <input type='radio' name='option' id='ox42' class="on" />
                                            <em>filter bag type</em></label>
                                        <span id='rx42'></span>
                                    </div>


                                    <div id='block-43' class="qo">
                                        <label for='ox43' class="ll">
                                            <input type='radio' name='option' id='ox43' class="on" />
                                            <em>simplex type </em></label>
                                        <span id='rx43'></span>
                                    </div>


                                    <div id='block-44' class="qo">
                                        <label for='ox44' class="ll">
                                            <input type='radio' name='option' id='ox44' class="on" />
                                            <em>absorbent type</em></label>
                                        <span id='rx44'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 12 -->
                                <div class="ques">
                                    <p class="qn">12. Which of the following represents the significance the fuel oil
                                        cetane
                                        number?
                                    </p>
                                    <hr>

                                    <div id='block-45' class="qo">
                                        <label for='ox45' class="ll">
                                            <input type='radio' name='option' id='ox45' class="on" />
                                            <em>The cetane number has no affect on injection lag.</em></label>
                                        <span id='rx45'></span>
                                    </div>


                                    <div id='block-46' class="qo">
                                        <label for='ox46' class="ll">
                                            <input type='radio' name='option' id='ox46' class="on" />
                                            <em>The cetane number is an indication of the fuel's viscosity.
                                            </em></label>
                                        <span id='rx46'></span>
                                    </div>


                                    <div id='block-47' class="qo">
                                        <label for='ox47' class="ll">
                                            <input type='radio' name='option' id='ox47' class="on" />
                                            <em>Ignition lag is reduced with fuels having a high cetane number.
                                            </em></label>
                                        <span id='rx47'></span>
                                    </div>


                                    <div id='block-48' class="qo">
                                        <label for='ox48' class="ll">
                                            <input type='radio' name='option' id='ox48' class="on" />
                                            <em>The cetane number is of little significance in the combustion
                                                process.
                                            </em></label>
                                        <span id='rx48'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 13 -->
                                <div class="ques">
                                    <p class="qn">13. Proper filtering and straining of diesel fuel is important because
                                        the
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-49' class="qo">
                                        <label for='ox49' class="ll">
                                            <input type='radio' name='option' id='ox49' class="on" />
                                            <em>fuel oil pump will overspeed if dirt is not removed
                                            </em></label>
                                        <span id='rx49'></span>
                                    </div>


                                    <div id='block-50' class="qo">
                                        <label for='ox50' class="ll">
                                            <input type='radio' name='option' id='ox50' class="on" />
                                            <em>fuel oil transfer pumps cannot tolerate small amounts of grit in the
                                                oil
                                            </em></label>
                                        <span id='rx50'></span>
                                    </div>


                                    <div id='block-51' class="qo">
                                        <label for='ox51' class="ll">
                                            <input type='radio' name='option' id='ox51' class="on" />
                                            <em>fuel injectors may be damaged by foreign particles in the fuel
                                                oil</em></label>
                                        <span id='rx51'></span>
                                    </div>


                                    <div id='block-52' class="qo">
                                        <label for='ox52' class="ll">
                                            <input type='radio' name='option' id='ox52' class="on" />
                                            <em>dirty fuel will clog the intake air filter</em></label>
                                        <span id='rx52'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 14 -->
                                <div class="ques">
                                    <p class="qn">14. Which of the following statements is true concerning the cetane
                                        number of diesel fuel?
                                    </p>
                                    <hr>

                                    <div id='block-53' class="qo">
                                        <label for='ox53' class="ll">
                                            <input type='radio' name='option' id='ox53' class="on" />
                                            <em>The cetane number affects the amount of injection lag.
                                            </em></label>
                                        <span id='rx53'></span>
                                    </div>


                                    <div id='block-54' class="qo">
                                        <label for='ox54' class="ll">
                                            <input type='radio' name='option' id='ox54' class="on" />
                                            <em>The cetane number is of little significance in the combustion
                                                process.
                                            </em></label>
                                        <span id='rx54'></span>
                                    </div>


                                    <div id='block-55' class="qo">
                                        <label for='ox55' class="ll">
                                            <input type='radio' name='option' id='ox55' class="on" />
                                            <em>Ignition lag is reduced with fuels having a high cetane number.
                                            </em></label>
                                        <span id='rx55'></span>
                                    </div>


                                    <div id='block-56' class="qo">
                                        <label for='ox56' class="ll">
                                            <input type='radio' name='option' id='ox56' class="on" />
                                            <em>The cetane number is an indication of the fuel's viscosity.
                                            </em></label>
                                        <span id='rx56'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 15 -->
                                <div class="ques">
                                    <p class="qn">15. If a diesel engine runs out of fuel, you can expect trouble from
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-57' class="qo">
                                        <label for='ox57' class="ll">
                                            <input type='radio' name='option' id='ox57' class="on" />
                                            <em>overheated injector pumps
                                            </em></label>
                                        <span id='rx57'></span>
                                    </div>


                                    <div id='block-58' class="qo">
                                        <label for='ox58' class="ll">
                                            <input type='radio' name='option' id='ox58' class="on" />
                                            <em>water condensed in the cylinders
                                            </em></label>
                                        <span id='rx58'></span>
                                    </div>


                                    <div id='block-59' class="qo">
                                        <label for='ox59' class="ll">
                                            <input type='radio' name='option' id='ox59' class="on" />
                                            <em>fuel dilution of the lube oil </em></label>
                                        <span id='rx59'></span>
                                    </div>


                                    <div id='block-60' class="qo">
                                        <label for='ox60' class="ll">
                                            <input type='radio' name='option' id='ox60' class="on" />
                                            <em>air in the fuel system</em></label>
                                        <span id='rx60'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 16 -->
                                <div class="ques">
                                    <p class="qn">16. The cetane number rates fuels for diesel engines according to its
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-61' class="qo">
                                        <label for='ox61' class="ll">
                                            <input type='radio' name='option' id='ox61' class="on" />
                                            <em>antiknock characteristics
                                            </em></label>
                                        <span id='rx61'></span>
                                    </div>


                                    <div id='block-62' class="qo">
                                        <label for='ox62' class="ll">
                                            <input type='radio' name='option' id='ox62' class="on" />
                                            <em>ignition qualities
                                            </em></label>
                                        <span id='rx62'></span>
                                    </div>


                                    <div id='block-63' class="qo">
                                        <label for='ox63' class="ll">
                                            <input type='radio' name='option' id='ox63' class="on" />
                                            <em>rates of vaporization
                                            </em></label>
                                        <span id='rx63'></span>
                                    </div>


                                    <div id='block-64' class="qo">
                                        <label for='ox64' class="ll">
                                            <input type='radio' name='option' id='ox64' class="on" />
                                            <em>viscosity</em></label>
                                        <span id='rx64'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 17 -->
                                <div class="ques">
                                    <p class="qn">17. The cetane rating of diesel fuel is an indication of the
                                        ______________.
                                    </p>
                                    <hr>

                                    <div id='block-65' class="qo">
                                        <label for='ox65' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox65'
                                                class="on" />
                                            <em>ignition quality of the fuel
                                            </em></label>
                                        <span id='rx65'></span>
                                    </div>


                                    <div id='block-66' class="qo">
                                        <label for='ox66' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox66'
                                                class="on" />
                                            <em>calorific value of the fuel
                                            </em></label>
                                        <span id='rx66'></span>
                                    </div>


                                    <div id='block-67' class="qo">
                                        <label for='ox67' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                                class="on" />
                                            <em>fclearance point of the fuel
                                            </em></label>
                                        <span id='rx67'></span>
                                    </div>


                                    <div id='block-68' class="qo">
                                        <label for='ox68' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                                class="on" />
                                            <em>rate of fuel consumption
                                            </em></label>
                                        <span id='rx68'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 18 -->
                                <div class="ques">
                                    <p class="qn">18. The ignition quality of a fuel oil is an important operational
                                        consideration because it _____________.
                                    </p>
                                    <hr>

                                    <div id='block-69' class="qo">
                                        <label for='ox69' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox69'
                                                class="on" />
                                            <em>indicates the amount of abrasive material in the fuel
                                            </em></label>
                                        <span id='rx69'></span>
                                    </div>


                                    <div id='block-70' class="qo">
                                        <label for='ox70' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox70'
                                                class="on" />
                                            <em>affects the starting ability of a cold engine
                                            </em></label>
                                        <span id='rx70'></span>
                                    </div>


                                    <div id='block-71' class="qo">
                                        <label for='ox71' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                                class="on" />
                                            <em>determines the amount of fuel penetration
                                            </em></label>
                                        <span id='rx71'></span>
                                    </div>


                                    <div id='block-72' class="qo">
                                        <label for='ox72' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                                class="on" />
                                            <em>affects the compression ratio of an operating engine
                                            </em></label>
                                        <span id='rx72'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 19 -->
                                <div class="ques">
                                    <p class="qn">19. When cleaning a duplex strainer, it is important for
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-73' class="qo">
                                        <label for='ox73' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox73'
                                                class="on" />
                                            <em>the pressure to be bled prior to opening the compartment
                                                cover</em></label>
                                        <span id='rx73'></span>
                                    </div>


                                    <div id='block-74' class="qo">
                                        <label for='ox74' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox74'
                                                class="on" />
                                            <em>the lube oil to be allowed to cool before removing the basket
                                            </em></label>
                                        <span id='rx74'></span>
                                    </div>


                                    <div id='block-75' class="qo">
                                        <label for='ox75' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                                class="on" />
                                            <em>the cleaning fluid used to be more viscous than the lube oil
                                            </em></label>
                                        <span id='rx75'></span>
                                    </div>


                                    <div id='block-76' class="qo">
                                        <label for='ox76' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                                class="on" />
                                            <em>a new cover gasket to be installed when reassembling the
                                                unit</em></label>
                                        <span id='rx76'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 20 -->
                                <div class="ques">
                                    <p class="qn">20. Which chemical listed is utilized to prevent and correct most
                                        microbial infections occurring within fuel storage systems?
                                    </p>
                                    <hr>

                                    <div id='block-77' class="qo">
                                        <label for='ox77' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox77'
                                                class="on" />
                                            <em>Bleaches
                                            </em></label>
                                        <span id='rx77'></span>
                                    </div>


                                    <div id='block-78' class="qo">
                                        <label for='ox78' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox78'
                                                class="on" />
                                            <em>Banalities
                                            </em></label>
                                        <span id='rx78'></span>
                                    </div>


                                    <div id='block-79' class="qo">
                                        <label for='ox79' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                                class="on" />
                                            <em>Biocides
                                            </em></label>
                                        <span id='rx79'></span>
                                    </div>


                                    <div id='block-80' class="qo">
                                        <label for='ox80' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                                class="on" />
                                            <em>Benzene additives
                                            </em></label>
                                        <span id='rx80'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                    </div>
                                </div>
                                <hr>



                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/fuel_system/asset/"; include($IPATH."fuel_sidebar.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item"><a class="page-link" href="/marine_engineering/fuel_system/1.php">1</a>
                        </li>
                        <li class="page-item  active" aria-current="page"><a class="page-link"
                                href="/marine_engineering/fuel_system/2.php">2</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="/marine_engineering/fuel_system/3.php">3</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>