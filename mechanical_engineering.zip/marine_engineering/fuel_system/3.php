<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/fuel_system/javascript/3.js"></script>

    <title>Fuel Systems & Maintenance (Set 3)| M. C. Q.</title>
    <meta name="description"
        content="The metal edge type filters used in diesel engine fuel oil..., Proper housekeeping to prevent the formation of microbiological..., Which of the following conditions is NOT an indication..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, fuel, system, maintenance, fuel system, systems, fuel systems, maintenance multiple, maintenance multiple choice, maintenance multiple choice questions, services, of fuel, submit, oil, marine, growth, air, engineering, diesel, engine, microbiological, growths, water, filters, draining, filter, supply, tank, improper, excessive, engines, injection, metal, cleaned, flushing, proper, steam, contamination, pressure, strainer, amounts, organisms, fuels, load, major, problems, pumps, overheating, pump, lines, day, order, power, instrumentation, control, heat, ship, of the, fuel oil, the fuel, all of, the above, above submit, marine engineering, diesel engine, draining the, the filter, microbiological growths, to the, services marine, engine fuel, the system, system and, and draining, of microbiological, growths within, within a, a fuel, of water, which of, the following, of a, amounts of, the growth, growth of, will cause, the major, major cause, cause of, fuel injection, in the, fuel lines, in order, order to, all of the, of the above, the above submit, of the fuel, services marine engineering, diesel engine fuel, engine fuel oil, and draining the, draining the filter, microbiological growths within, growths within a, within a fuel, a fuel system, which of the, of the following, the growth of, the major cause, major cause of, in the fuel, in order to, all of the above, of the above submit, diesel engine fuel oil, and draining the filter, microbiological growths within a, growths within a fuel, within a fuel system, which of the following, the major cause of, all of the above submit, microbiological growths within a fuel, growths within a fuel system" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/fuel_system/3.php" style="cursor: default;">FUEL
                        SYSTEMS: <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Fuel Systems & Maintenance (Set 3)</h1>
                                    <hr>
                                    <p>
                                    <h4>Multiple Choice Questions</h4>
                                    <hr>
                                    <!-- Question 1 -->
                                    <div class="ques">
                                        <p class="qn">1. The metal edge type filters used in diesel engine fuel oil and
                                            lube
                                            oil
                                            systems are normally cleaned in place by _____________.
                                        </p>
                                        <hr>

                                        <div id='block-1' class="qo">
                                            <label for='ox1' class="ll">
                                                <input type='radio' name='option' id='ox1' class="on" />
                                                <em>back flushing the system and draining the filter</em></label>
                                            <span id='rx1'></span>
                                        </div>


                                        <div id='block-2' class="qo">
                                            <label for='ox2' class="ll">
                                                <input type='radio' name='option' id='ox2' class="on" />
                                                <em>opening the drain plug and blowing through the filter
                                                </em></label>
                                            <span id='rx2'></span>
                                        </div>


                                        <div id='block-3' class="qo">
                                            <label for='ox3' class="ll">
                                                <input type='radio' name='option' id='ox3' class="on" />
                                                <em>manually operating a built-in scraper and draining the
                                                    filter</em></label>
                                            <span id='rx3'></span>
                                        </div>


                                        <div id='block-4' class="qo">
                                            <label for='ox4' class="ll">
                                                <input type='radio' name='option' id='ox4' class="on" />
                                                <em>flushing with any approved solvent then draining the system
                                                </em></label>
                                            <span id='rx4'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer1()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 2 -->
                                    <div class="ques">
                                        <p class="qn">2. Proper housekeeping to prevent the formation of microbiological
                                            growths within a fuel system includes the prevention of water
                                            accumulations and the use of _______.
                                        </p>
                                        <hr>

                                        <div id='block-5' class="qo">
                                            <label for='ox5' class="ll">
                                                <input type='radio' name='option' id='ox5' class="on" />
                                                <em>steam coils
                                                </em></label>
                                            <span id='rx5'></span>
                                        </div>


                                        <div id='block-6' class="qo">
                                            <label for='ox6' class="ll">
                                                <input type='radio' name='option' id='ox6' class="on" />
                                                <em>fuel oil centrifuges
                                                </em></label>
                                            <span id='rx6'></span>
                                        </div>


                                        <div id='block-7' class="qo">
                                            <label for='ox7' class="ll">
                                                <input type='radio' name='option' id='ox7' class="on" />
                                                <em>fuel oil discharge filters
                                                </em></label>
                                            <span id='rx7'></span>
                                        </div>


                                        <div id='block-8' class="qo">
                                            <label for='ox8' class="ll">
                                                <input type='radio' name='option' id='ox8' class="on" />
                                                <em>chemical additives called biocides
                                                </em></label>
                                            <span id='rx8'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer2()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 3 -->
                                    <div class="ques">
                                        <p class="qn">3. Which of the following conditions is NOT an indication of
                                            microbial
                                            contamination of the fuel supply?
                                        </p>
                                        <hr>

                                        <div id='block-9' class="qo">
                                            <label for='ox9' class="ll">
                                                <input type='radio' name='option' id='ox9' class="on" />
                                                <em>Evidence of corrosion</em></label>
                                            <span id='rx9'></span>
                                        </div>


                                        <div id='block-10' class="qo">
                                            <label for='ox10' class="ll">
                                                <input type='radio' name='option' id='ox10' class="on" />
                                                <em>Pitting of metal surfaces
                                                </em></label>
                                            <span id='rx10'></span>
                                        </div>


                                        <div id='block-11' class="qo">
                                            <label for='ox11' class="ll">
                                                <input type='radio' name='option' id='ox11' class="on" />
                                                <em>Presence of green slime
                                                </em></label>
                                            <span id='rx11'></span>
                                        </div>


                                        <div id='block-12' class="qo">
                                            <label for='ox12' class="ll">
                                                <input type='radio' name='option' id='ox12' class="on" />
                                                <em>Brightening of copper bering metals</em></label>
                                            <span id='rx12'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer3()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 4 -->
                                    <div class="ques">
                                        <p class="qn">4. An increased pressure differential between the inlet and outlet
                                            of
                                            a
                                            strainer usually indicates the strainer is _____________.
                                        </p>
                                        <hr>

                                        <div id='block-13' class="qo">
                                            <label for='ox13' class="ll">
                                                <input type='radio' name='option' id='ox13' class="on" />
                                                <em>holed
                                                </em></label>
                                            <span id='rx13'></span>
                                        </div>


                                        <div id='block-14' class="qo">
                                            <label for='ox14' class="ll">
                                                <input type='radio' name='option' id='ox14' class="on" />
                                                <em>fouled
                                                </em></label>
                                            <span id='rx14'></span>
                                        </div>


                                        <div id='block-15' class="qo">
                                            <label for='ox15' class="ll">
                                                <input type='radio' name='option' id='ox15' class="on" />
                                                <em>clean
                                                </em></label>
                                            <span id='rx15'></span>
                                        </div>


                                        <div id='block-16' class="qo">
                                            <label for='ox16' class="ll">
                                                <input type='radio' name='option' id='ox16' class="on" />
                                                <em>dry</em></label>
                                            <span id='rx16'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer4()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 5 -->
                                    <div class="ques">
                                        <p class="qn">5. Small amounts of moisture are necessary to trigger the growth
                                            of
                                            microbiological organisms found in some marine fuels. Some
                                            sources of water contamination are _________.
                                        </p>
                                        <hr>

                                        <div id='block-17' class="qo">
                                            <label for='ox17' class="ll">
                                                <input type='radio' name='option' id='ox17' class="on" />
                                                <em>tank surface leakage</em></label>
                                            <span id='rx17'></span>
                                        </div>


                                        <div id='block-18' class="qo">
                                            <label for='ox18' class="ll">
                                                <input type='radio' name='option' id='ox18' class="on" />
                                                <em>humidity and condensation</em></label>
                                            <span id='rx18'></span>
                                        </div>


                                        <div id='block-19' class="qo">
                                            <label for='ox19' class="ll">
                                                <input type='radio' name='option' id='ox19' class="on" />
                                                <em>improper tank washing procedures</em></label>
                                            <span id='rx19'></span>
                                        </div>


                                        <div id='block-20' class="qo">
                                            <label for='ox20' class="ll">
                                                <input type='radio' name='option' id='ox20' class="on" />
                                                <em>All of the above
                                                </em></label>
                                            <span id='rx20'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer5()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 6 -->
                                    <div class="ques">
                                        <p class="qn">6. Which of the following statements describes the results of
                                            excessive microbiological growths within a fuel system?
                                        </p>
                                        <hr>

                                        <div id='block-21' class="qo">
                                            <label for='ox21' class="ll">
                                                <input type='radio' name='option' id='ox21' class="on" />
                                                <em>All excessive amounts of growth will cause the main engines of the
                                                    vessel to stall due to the inability to supply the proper quantities
                                                    of
                                                    fuel to satisfy the existing load.
                                                </em></label>
                                            <span id='rx21'></span>
                                        </div>


                                        <div id='block-22' class="qo">
                                            <label for='ox22' class="ll">
                                                <input type='radio' name='option' id='ox22' class="on" />
                                                <em>The deposits produced by these growths form blockages and flow
                                                    restrictions ultimately leading to improper atomization of the fuel
                                                    into
                                                    the cylinders.
                                                </em></label>
                                            <span id='rx22'></span>
                                        </div>


                                        <div id='block-23' class="qo">
                                            <label for='ox23' class="ll">
                                                <input type='radio' name='option' id='ox23' class="on" />
                                                <em>Eventually the growth of these organisms will deplete the supply of
                                                    food available to them, which in turn will cause their
                                                    demise.</em></label>
                                            <span id='rx23'></span>
                                        </div>


                                        <div id='block-24' class="qo">
                                            <label for='ox24' class="ll">
                                                <input type='radio' name='option' id='ox24' class="on" />
                                                <em>If continual growth is permitted, a sweet odor similar to that
                                                    associated with baking will be noticed when system components
                                                    are opened for inspection.
                                                </em></label>
                                            <span id='rx24'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer6()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 7 -->
                                    <div class="ques">
                                        <p class="qn">7. The major cause of problems occurring with fuel injection
                                            equipment is _____________.
                                        </p>
                                        <hr>

                                        <div id='block-25' class="qo">
                                            <label for='ox25' class="ll">
                                                <input type='radio' name='option' value='fluid dynamics' id='ox25'
                                                    class="on" />
                                                <em>incorrect replacement of barrels and plungers of jerk
                                                    pumps</em></label>
                                            <span id='rx25'></span>
                                        </div>


                                        <div id='block-26' class="qo">
                                            <label for='ox26' class="ll">
                                                <input type='radio' name='option' value='fluid kinetics' id='ox26'
                                                    class="on" />
                                                <em>overheating of the nozzle orifices
                                                </em></label>
                                            <span id='rx26'></span>
                                        </div>


                                        <div id='block-27' class="qo">
                                            <label for='ox27' class="ll">
                                                <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                                    class="on" />
                                                <em>cracked pump housings</em></label>
                                            <span id='rx27'></span>
                                        </div>


                                        <div id='block-28' class="qo">
                                            <label for='ox28' class="ll">
                                                <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                                    class="on" />
                                                <em>dirt in the fuel
                                                </em></label>
                                            <span id='rx28'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer7()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 8 -->
                                    <div class="ques">
                                        <p class="qn">8. The microbiological growths that affect fuel supplies can
                                            easily be
                                            transported from one location to another by _________.
                                        </p>
                                        <hr>

                                        <div id='block-29' class="qo">
                                            <label for='ox29' class="ll">
                                                <input type='radio' name='option' value='fluid dynamics' id='ox29'
                                                    class="on" />
                                                <em>roaches and other insects
                                                </em></label>
                                            <span id='rx29'></span>
                                        </div>


                                        <div id='block-30' class="qo">
                                            <label for='ox30' class="ll">
                                                <input type='radio' name='option' value='fluid kinetics' id='ox30'
                                                    class="on" />
                                                <em>air, solids, or liquids </em></label>
                                            <span id='rx30'></span>
                                        </div>


                                        <div id='block-31' class="qo">
                                            <label for='ox31' class="ll">
                                                <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                                    class="on" />
                                                <em>other non-hydrocarbon fuels
                                                </em></label>
                                            <span id='rx31'></span>
                                        </div>


                                        <div id='block-32' class="qo">
                                            <label for='ox32' class="ll">
                                                <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                                    class="on" />
                                                <em>all of the above
                                                </em></label>
                                            <span id='rx32'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer8()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 9 -->
                                    <div class="ques">
                                        <p class="qn">9. Air in the fuel lines to the fuel injection nozzles of a diesel
                                            engine will
                                            result in _____________.
                                        </p>
                                        <hr>

                                        <div id='block-33' class="qo">
                                            <label for='ox33' class="ll">
                                                <input type='radio' name='option' value='fluid dynamics' id='ox33'
                                                    class="on" />
                                                <em>lower compression pressures
                                                </em></label>
                                            <span id='rx33'></span>
                                        </div>


                                        <div id='block-34' class="qo">
                                            <label for='ox34' class="ll">
                                                <input type='radio' name='option' value='fluid kinetics' id='ox34'
                                                    class="on" />
                                                <em>overheating without smoking</em></label>
                                            <span id='rx34'></span>
                                        </div>


                                        <div id='block-35' class="qo">
                                            <label for='ox35' class="ll">
                                                <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                                    class="on" />
                                                <em>failure to start
                                                </em></label>
                                            <span id='rx35'></span>
                                        </div>


                                        <div id='block-36' class="qo">
                                            <label for='ox36' class="ll">
                                                <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                                    class="on" />
                                                <em>a runaway without load
                                                </em></label>
                                            <span id='rx36'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer9()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 10 -->
                                    <div class="ques">
                                        <p class="qn">10. The major cause of fuel pump and injection system problems is
                                            _____________.
                                        </p>
                                        <hr>

                                        <div id='block-37' class="qo">
                                            <label for='ox37' class="ll">
                                                <input type='radio' name='option' value='fluid dynamics' id='ox37'
                                                    class="on" />
                                                <em>improper adjustments
                                                </em></label>
                                            <span id='rx37'></span>
                                        </div>


                                        <div id='block-38' class="qo">
                                            <label for='ox38' class="ll">
                                                <input type='radio' name='option' value='fluid kinetics' id='ox38'
                                                    class="on" />
                                                <em>contaminated fuel
                                                </em></label>
                                            <span id='rx38'></span>
                                        </div>


                                        <div id='block-39' class="qo">
                                            <label for='ox39' class="ll">
                                                <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                                    class="on" />
                                                <em>kinked fuel lines
                                                </em></label>
                                            <span id='rx39'></span>
                                        </div>


                                        <div id='block-40' class="qo">
                                            <label for='ox40' class="ll">
                                                <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                                    class="on" />
                                                <em>excessive engine vibration
                                                </em></label>
                                            <span id='rx40'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer10()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>

                                    <!-- Question 11 -->
                                    <div class="ques">
                                        <p class="qn">11. Fuel oil day tanks for diesel engines must be checked and
                                            cleaned
                                            at regular intervals in order to remove ___________.
                                        </p>
                                        <hr>

                                        <div id='block-41' class="qo">
                                            <label for='ox41' class="ll">
                                                <input type='radio' name='option' id='ox41' class="on" />
                                                <em>sludge</em></label>
                                            <span id='rx41'></span>
                                        </div>


                                        <div id='block-42' class="qo">
                                            <label for='ox42' class="ll">
                                                <input type='radio' name='option' id='ox42' class="on" />
                                                <em>water</em></label>
                                            <span id='rx42'></span>
                                        </div>


                                        <div id='block-43' class="qo">
                                            <label for='ox43' class="ll">
                                                <input type='radio' name='option' id='ox43' class="on" />
                                                <em>micro-organism growth</em></label>
                                            <span id='rx43'></span>
                                        </div>


                                        <div id='block-44' class="qo">
                                            <label for='ox44' class="ll">
                                                <input type='radio' name='option' id='ox44' class="on" />
                                                <em>all of the above</em></label>
                                            <span id='rx44'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer11()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 12 -->
                                    <div class="ques">
                                        <p class="qn">12. Fuel oil is regularly transferred to the day tank in order to
                                            _____________.
                                        </p>
                                        <hr>

                                        <div id='block-45' class="qo">
                                            <label for='ox45' class="ll">
                                                <input type='radio' name='option' id='ox45' class="on" />
                                                <em>allow impurities to settle out of the fuel
                                                </em></label>
                                            <span id='rx45'></span>
                                        </div>


                                        <div id='block-46' class="qo">
                                            <label for='ox46' class="ll">
                                                <input type='radio' name='option' id='ox46' class="on" />
                                                <em>allow air to escape from the fuel
                                                </em></label>
                                            <span id='rx46'></span>
                                        </div>


                                        <div id='block-47' class="qo">
                                            <label for='ox47' class="ll">
                                                <input type='radio' name='option' id='ox47' class="on" />
                                                <em>make fuel available for immediate use
                                                </em></label>
                                            <span id='rx47'></span>
                                        </div>


                                        <div id='block-48' class="qo">
                                            <label for='ox48' class="ll">
                                                <input type='radio' name='option' id='ox48' class="on" />
                                                <em>all of the above</em></label>
                                            <span id='rx48'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer12()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>
                                    <!-- Question 13 -->
                                    <div class="ques">
                                        <p class="qn">13. Clogged diesel engine fuel oil filters can cause __________,
                                        </p>
                                        <hr>

                                        <div id='block-49' class="qo">
                                            <label for='ox49' class="ll">
                                                <input type='radio' name='option' id='ox49' class="on" />
                                                <em>loss of power
                                                </em></label>
                                            <span id='rx49'></span>
                                        </div>


                                        <div id='block-50' class="qo">
                                            <label for='ox50' class="ll">
                                                <input type='radio' name='option' id='ox50' class="on" />
                                                <em>misfiring</em></label>
                                            <span id='rx50'></span>
                                        </div>


                                        <div id='block-51' class="qo">
                                            <label for='ox51' class="ll">
                                                <input type='radio' name='option' id='ox51' class="on" />
                                                <em>low fuel oil pressure</em></label>
                                            <span id='rx51'></span>
                                        </div>


                                        <div id='block-52' class="qo">
                                            <label for='ox52' class="ll">
                                                <input type='radio' name='option' id='ox52' class="on" />
                                                <em>all of the above</em></label>
                                            <span id='rx52'></span>
                                        </div>
                                        <hr>
                                        <div><button type='button' onclick='displayAnswer13()'
                                                class="sbt">Submit</button>
                                        </div>

                                    </div>
                                    <hr>


                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/fuel_system/asset/"; include($IPATH."fuel_sidebar.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item"><a class="page-link" href="/marine_engineering/fuel_system/1.php">1</a>
                        </li>
                        <li class="page-item "><a class="page-link" href="/marine_engineering/fuel_system/2.php">2</a>
                        </li>
                        <li class="page-item  active" aria-current="page"><a class="page-link"
                                href="/marine_engineering/fuel_system/3.php">3</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>