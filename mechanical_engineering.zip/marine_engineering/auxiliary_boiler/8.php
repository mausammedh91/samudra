<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/auxiliary_boiler/javascript/8.js"></script>

    <title>Auxiliary Boiler (Set 8); Multiple Choice Questions</title>
    <meta name="description"
        content="The concentration of total dissolved solids in the water..., The daily inspection of an operating auxiliary boiler should..., Which of the following conditions could cause black..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, boiler, auxiliary, oil, auxiliary boiler, services, submit, fuel, burner, water, steam, system, engineering, marine, valves, air, systems, safety, heat, flame, control, dissolved, frequent, blows, conditions, insufficient, supply, combustion, high, level, nozzle, instrumentation, ship, of the, marine engineering, in the, of an, an auxiliary, fuel oil, services marine, all safety, the boiler, which of, the following, following conditions, from the, the fuel, combustion air, water level, in a, in an, the burner, burner nozzle, an auxiliary boiler, services marine engineering, of an auxiliary, which of the, of the following, the following conditions, the fuel oil, of an auxiliary boiler, which of the following, of the following conditions, which of the following conditions" />
    <style>
       .dfg {
        text-decoration: none;
        color: brown;
        font-family: sans-serif;
       }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/auxiliary_boiler/8.php" style="cursor: default;">AUXILIARY BOILER:
                        <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Auxiliary Boiler (Set 8)</h1>
                                <hr>
                                <p>
                                <h4>Multiple Choice Questions</h4>
                                <hr>
                                <!-- Question 1 -->
                                <div class="ques">
                                    <p class="qn">1. The concentration of total dissolved solids in the water of an
                                        auxiliary boiler can increase as a result of ___________.
                                    </p>
                                    <hr>

                                    <div id='block-1' class="qo">
                                        <label for='ox1' class="ll">
                                            <input type='radio' name='option' id='ox1' class="on" />
                                            <em>seawater contamination
                                            </em></label>
                                        <span id='rx1'></span>
                                    </div>


                                    <div id='block-2' class="qo">
                                        <label for='ox2' class="ll">
                                            <input type='radio' name='option' id='ox2' class="on" />
                                            <em>frequent surface blows
                                            </em></label>
                                        <span id='rx2'></span>
                                    </div>


                                    <div id='block-3' class="qo">
                                        <label for='ox3' class="ll">
                                            <input type='radio' name='option' id='ox3' class="on" />
                                            <em>dissolved oxygen deaeration </em></label>
                                        <span id='rx3'></span>
                                    </div>


                                    <div id='block-4' class="qo">
                                        <label for='ox4' class="ll">
                                            <input type='radio' name='option' id='ox4' class="on" />
                                            <em>frequent bottom blows</em></label>
                                        <span id='rx4'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 2 -->
                                <div class="ques">
                                    <p class="qn">2. The daily inspection of an operating auxiliary boiler should
                                        include
                                        ____________.
                                    </p>
                                    <hr>

                                    <div id='block-5' class="qo">
                                        <label for='ox5' class="ll">
                                            <input type='radio' name='option' id='ox5' class="on" />
                                            <em>lifting of all safety valves
                                            </em></label>
                                        <span id='rx5'></span>
                                    </div>


                                    <div id='block-6' class="qo">
                                        <label for='ox6' class="ll">
                                            <input type='radio' name='option' id='ox6' class="on" />
                                            <em>an examination of the boiler firesides
                                            </em></label>
                                        <span id='rx6'></span>
                                    </div>


                                    <div id='block-7' class="qo">
                                        <label for='ox7' class="ll">
                                            <input type='radio' name='option' id='ox7' class="on" />
                                            <em>checking for external fuel and water leaks
                                            </em></label>
                                        <span id='rx7'></span>
                                    </div>


                                    <div id='block-8' class="qo">
                                        <label for='ox8' class="ll">
                                            <input type='radio' name='option' id='ox8' class="on" />
                                            <em>measuring steam quality
                                            </em></label>
                                        <span id='rx8'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 3 -->
                                <div class="ques">
                                    <p class="qn">3. Which of the following conditions could cause black smoke to be
                                        discharged from the stack of an auxiliary boiler equipped with
                                        turbine-driven rotary cup atomizers?
                                    </p>
                                    <hr>

                                    <div id='block-9' class="qo">
                                        <label for='ox9' class="ll">
                                            <input type='radio' name='option' id='ox9' class="on" />
                                            <em>Insufficient steam supply to the fuel oil heater. </em></label>
                                        <span id='rx9'></span>
                                    </div>


                                    <div id='block-10' class="qo">
                                        <label for='ox10' class="ll">
                                            <input type='radio' name='option' id='ox10' class="on" />
                                            <em>Excessive opening of the dampers in the combustion air inlet.
                                            </em></label>
                                        <span id='rx10'></span>
                                    </div>


                                    <div id='block-11' class="qo">
                                        <label for='ox11' class="ll">
                                            <input type='radio' name='option' id='ox11' class="on" />
                                            <em>Improper turbine shaft speed in the atomizer assembly.
                                            </em></label>
                                        <span id='rx11'></span>
                                    </div>


                                    <div id='block-12' class="qo">
                                        <label for='ox12' class="ll">
                                            <input type='radio' name='option' id='ox12' class="on" />
                                            <em>high drum water level </em></label>
                                        <span id='rx12'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 4 -->
                                <div class="ques">
                                    <p class="qn">4. Waterside scale in a fire-tube boiler may cause ___________.
                                    </p>
                                    <hr>

                                    <div id='block-13' class="qo">
                                        <label for='ox13' class="ll">
                                            <input type='radio' name='option' id='ox13' class="on" />
                                            <em>increased heat transfer
                                            </em></label>
                                        <span id='rx13'></span>
                                    </div>


                                    <div id='block-14' class="qo">
                                        <label for='ox14' class="ll">
                                            <input type='radio' name='option' id='ox14' class="on" />
                                            <em>fireside erosion
                                            </em></label>
                                        <span id='rx14'></span>
                                    </div>


                                    <div id='block-15' class="qo">
                                        <label for='ox15' class="ll">
                                            <input type='radio' name='option' id='ox15' class="on" />
                                            <em>high steam demand
                                            </em></label>
                                        <span id='rx15'></span>
                                    </div>


                                    <div id='block-16' class="qo">
                                        <label for='ox16' class="ll">
                                            <input type='radio' name='option' id='ox16' class="on" />
                                            <em>overheated tubes
                                            </em></label>
                                        <span id='rx16'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 5 -->
                                <div class="ques">
                                    <p class="qn">5. A smoking burner with a pulsating flame in an auxiliary boiler, is
                                        an
                                        indication that the ______________.
                                    </p>
                                    <hr>

                                    <div id='block-17' class="qo">
                                        <label for='ox17' class="ll">
                                            <input type='radio' name='option' id='ox17' class="on" />
                                            <em>fuel oil supply temperature is normal </em></label>
                                        <span id='rx17'></span>
                                    </div>


                                    <div id='block-18' class="qo">
                                        <label for='ox18' class="ll">
                                            <input type='radio' name='option' id='ox18' class="on" />
                                            <em>burner electrode is incorrectly positioned</em></label>
                                        <span id='rx18'></span>
                                    </div>


                                    <div id='block-19' class="qo">
                                        <label for='ox19' class="ll">
                                            <input type='radio' name='option' id='ox19' class="on" />
                                            <em>fuel/air ratio is incorrect</em></label>
                                        <span id='rx19'></span>
                                    </div>


                                    <div id='block-20' class="qo">
                                        <label for='ox20' class="ll">
                                            <input type='radio' name='option' id='ox20' class="on" />
                                            <em>ignition current is too low
                                            </em></label>
                                        <span id='rx20'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 6 -->
                                <div class="ques">
                                    <p class="qn">6. Which of the following conditions would cause "panting" in a
                                        steaming auxiliary boiler?
                                    </p>
                                    <hr>

                                    <div id='block-21' class="qo">
                                        <label for='ox21' class="ll">
                                            <input type='radio' name='option' id='ox21' class="on" />
                                            <em>Insufficient combustion air
                                            </em></label>
                                        <span id='rx21'></span>
                                    </div>


                                    <div id='block-22' class="qo">
                                        <label for='ox22' class="ll">
                                            <input type='radio' name='option' id='ox22' class="on" />
                                            <em>Low water level
                                            </em></label>
                                        <span id='rx22'></span>
                                    </div>


                                    <div id='block-23' class="qo">
                                        <label for='ox23' class="ll">
                                            <input type='radio' name='option' id='ox23' class="on" />
                                            <em>Flame failure
                                            </em></label>
                                        <span id='rx23'></span>
                                    </div>


                                    <div id='block-24' class="qo">
                                        <label for='ox24' class="ll">
                                            <input type='radio' name='option' id='ox24' class="on" />
                                            <em>Faulty flame scanner
                                            </em></label>
                                        <span id='rx24'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 7 -->
                                <div class="ques">
                                    <p class="qn">7. If oil is dripping from the burner of a coil-type auxiliary steam
                                        generator, the cause may be _____________.
                                    </p>
                                    <hr>

                                    <div id='block-25' class="qo">
                                        <label for='ox25' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox25'
                                                class="on" />
                                            <em>the oil valve not seating properly</em></label>
                                        <span id='rx25'></span>
                                    </div>


                                    <div id='block-26' class="qo">
                                        <label for='ox26' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox26'
                                                class="on" />
                                            <em>a loose burner nozzle
                                            </em></label>
                                        <span id='rx26'></span>
                                    </div>


                                    <div id='block-27' class="qo">
                                        <label for='ox27' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                                class="on" />
                                            <em>carbon on the burner nozzle causing deflection of oil spray</em></label>
                                        <span id='rx27'></span>
                                    </div>


                                    <div id='block-28' class="qo">
                                        <label for='ox28' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                                class="on" />
                                            <em>all of the above
                                            </em></label>
                                        <span id='rx28'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 8 -->
                                <div class="ques">
                                    <p class="qn">8. Before any work is done on a burner in an automatically fired
                                        auxiliary boiler, you should always ___________.
                                    </p>
                                    <hr>

                                    <div id='block-29' class="qo">
                                        <label for='ox29' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox29'
                                                class="on" />
                                            <em>block all control valves
                                            </em></label>
                                        <span id='rx29'></span>
                                    </div>


                                    <div id='block-30' class="qo">
                                        <label for='ox30' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox30'
                                                class="on" />
                                            <em>allow the boiler to cool completely
                                            </em></label>
                                        <span id='rx30'></span>
                                    </div>


                                    <div id='block-31' class="qo">
                                        <label for='ox31' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                                class="on" />
                                            <em>lock all safety interlock switches closed
                                            </em></label>
                                        <span id='rx31'></span>
                                    </div>


                                    <div id='block-32' class="qo">
                                        <label for='ox32' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                                class="on" />
                                            <em>close all manually operated fuel valves
                                            </em></label>
                                        <span id='rx32'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>



                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/auxiliary_boiler/asset/"; include($IPATH."auxiliary_sidebar.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/1.php">1</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/2.php">2</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/3.php">3</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/4.php">4</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/5.php">5</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/6.php">6</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/7.php">7</a>
                        </li>
                        <li class="page-item active" aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/8.php">8</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>