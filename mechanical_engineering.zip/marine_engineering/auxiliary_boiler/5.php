<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/auxiliary_boiler/javascript/5.js"></script>

    <title>Auxiliary Boiler (Set 5); Multiple Choice Questions</title>
    <meta name="description"
        content="The purpose of the safety relief valves installed..., In a forced circulation auxiliary boiler, steam..., The safety valve installed on a coil-type auxiliary boiler is..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, boiler, auxiliary, oil, auxiliary boiler, services, submit, water, steam, circulation, feedwater, tube, fuel, fire-tube, system, oxygen, installed, chamber, water-tube, dissolved, engineering, marine, safety, forced, heating, coils, heat, bottom, burner, concentration, air, content, systems, valves, pressure, proper, reduce, fclearance, coil-type, boilers, controlled, demand, response, control, solids, high, hardness, chloride, purpose, excess, draft, combustion, thermostat, valve, divided, classifications, express, external, plating, recirculated, unevaporated, type, propeller, protect, casing, loss, closed, procedures, total, treatment, frequent, liberated, flow, passes, whirling, passing, tangential, slots, leaves, straight, stream, mixed, primary, incorrect, setting, tested, alkalinity, contamination, phosphate, instrumentation, ship, in the, an auxiliary, the boiler, in a, of the, through the, heating coils, of an, in an, marine engineering, boiler is, is to, fuel oil, forced circulation, steam is, fclearance chamber, a coil-type, auxiliary boilers, fire-tube controlled, controlled circulation, circulation fire-tube, steam demand, feedwater is, the inner, dissolved solids, the water, as a, chloride content, services marine, purpose of, the safety, installed on, for proper, boiler submit, circulation auxiliary, boiler steam, thermostat tube, on a, coil-type auxiliary, on the, boilers are, are divided, divided into, into several, several classifications, classifications one, one of, of which, which is, circulation water-tube, express circulation, circulation submit, installed in, a fire-tube, external boiler, boiler plating, auxiliary water-tube, demand response, response is, is recirculated, recirculated through, through heating, coils in, boiler unevaporated, unevaporated feedwater, protect the, inner casing, casing and, and reduce, reduce heat, heat loss, to steam, a burner, which of, the following, total dissolved, water of, the concentration, concentration of, of dissolved, dissolved oxygen, oxygen is, is liberated, passes through, the whirling, whirling chamber, before passing, passing through, the tangential, tangential slots, leaves the, the burner, burner as, a straight, straight stream, stream until, until mixed, mixed with, with the, water in, boiler should, should be, content chloride, water hardness, an auxiliary boiler, in the boiler, of an auxiliary, auxiliary boiler is, fire-tube controlled circulation, services marine engineering, boiler is to, forced circulation auxiliary, a coil-type auxiliary, auxiliary boilers are, boilers are divided, are divided into, divided into several, into several classifications, several classifications one, classifications one of, one of which, of which is, controlled circulation fire-tube, circulation fire-tube controlled, express circulation submit, in a fire-tube, external boiler plating, in a coil-type, steam demand response, demand response is, steam is recirculated, is recirculated through, recirculated through heating, through heating coils, heating coils in, coils in the, boiler unevaporated feedwater, protect the inner, the inner casing, inner casing and, casing and reduce, and reduce heat, reduce heat loss, which of the, of the following, total dissolved solids, water of an, the concentration of, concentration of dissolved, oxygen is liberated, passes through the, through the whirling, the whirling chamber, before passing through, passing through the, through the tangential, the tangential slots, leaves the burner, the burner as, burner as a, as a straight, a straight stream, straight stream until, stream until mixed, until mixed with, mixed with the, the water in, water in an, in an auxiliary, auxiliary boiler should, boiler should be, content chloride content, of an auxiliary boiler, an auxiliary boiler is, auxiliary boiler is to, auxiliary boilers are divided, boilers are divided into, are divided into several, divided into several classifications, into several classifications one, several classifications one of, classifications one of which, one of which is, fire-tube controlled circulation fire-tube, circulation fire-tube controlled circulation, steam demand response is, steam is recirculated through, is recirculated through heating, recirculated through heating coils, through heating coils in, heating coils in the, coils in the boiler, protect the inner casing, the inner casing and, inner casing and reduce, casing and reduce heat, and reduce heat loss, which of the following, water of an auxiliary, the concentration of dissolved, through the whirling chamber, before passing through the, through the tangential slots, leaves the burner as, the burner as a, burner as a straight, as a straight stream, a straight stream until, straight stream until mixed, stream until mixed with, until mixed with the, the water in an, water in an auxiliary, in an auxiliary boiler, an auxiliary boiler should, auxiliary boiler should be, an auxiliary boiler is to, auxiliary boilers are divided into, boilers are divided into several, are divided into several classifications, divided into several classifications one, into several classifications one of, several classifications one of which, classifications one of which is, steam is recirculated through heating, is recirculated through heating coils, recirculated through heating coils in, through heating coils in the, heating coils in the boiler, protect the inner casing and, the inner casing and reduce, inner casing and reduce heat, casing and reduce heat loss, water of an auxiliary boiler, leaves the burner as a, the burner as a straight, burner as a straight stream, as a straight stream until, a straight stream until mixed, straight stream until mixed with, stream until mixed with the, the water in an auxiliary, water in an auxiliary boiler, in an auxiliary boiler should, an auxiliary boiler should be" />
    <style>
     .dfg {
        text-decoration: none;
        color: brown;
        font-family: sans-serif;
        }
    </style>
</head>
<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/auxiliary_boiler/5.php" style="cursor: default;">AUXILIARY BOILER:
                        <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Auxiliary Boiler (Set 5)</h1>
                                <hr>
                                <p>
                                <h4>Multiple Choice Questions</h4>
                                <hr>
                                <!-- Question 1 -->
                                <div class="ques">
                                    <p class="qn">1. The purpose of the safety relief valves installed on an auxiliary
                                        boiler is to ____________.
                                    </p>
                                    <hr>

                                    <div id='block-1' class="qo">
                                        <label for='ox1' class="ll">
                                            <input type='radio' name='option' id='ox1' class="on" />
                                            <em>relieve excess fuel oil pressure during the "off" fire
                                                cycle</em></label>
                                        <span id='rx1'></span>
                                    </div>


                                    <div id='block-2' class="qo">
                                        <label for='ox2' class="ll">
                                            <input type='radio' name='option' id='ox2' class="on" />
                                            <em>admit water to the dry pipe
                                            </em></label>
                                        <span id='rx2'></span>
                                    </div>


                                    <div id='block-3' class="qo">
                                        <label for='ox3' class="ll">
                                            <input type='radio' name='option' id='ox3' class="on" />
                                            <em>throttle the forced draft fan output for proper combustion</em></label>
                                        <span id='rx3'></span>
                                    </div>


                                    <div id='block-4' class="qo">
                                        <label for='ox4' class="ll">
                                            <input type='radio' name='option' id='ox4' class="on" />
                                            <em>reduce excess steam pressure in the boiler</em></label>
                                        <span id='rx4'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 2 -->
                                <div class="ques">
                                    <p class="qn">2. In a forced circulation auxiliary boiler, steam is formed in the
                                        ____________.
                                    </p>
                                    <hr>

                                    <div id='block-5' class="qo">
                                        <label for='ox5' class="ll">
                                            <input type='radio' name='option' id='ox5' class="on" />
                                            <em>heating coils
                                            </em></label>
                                        <span id='rx5'></span>
                                    </div>


                                    <div id='block-6' class="qo">
                                        <label for='ox6' class="ll">
                                            <input type='radio' name='option' id='ox6' class="on" />
                                            <em>steam accumulator (fclearance chamber)
                                            </em></label>
                                        <span id='rx6'></span>
                                    </div>


                                    <div id='block-7' class="qo">
                                        <label for='ox7' class="ll">
                                            <input type='radio' name='option' id='ox7' class="on" />
                                            <em>hotwell
                                            </em></label>
                                        <span id='rx7'></span>
                                    </div>


                                    <div id='block-8' class="qo">
                                        <label for='ox8' class="ll">
                                            <input type='radio' name='option' id='ox8' class="on" />
                                            <em>thermostat tube
                                            </em></label>
                                        <span id='rx8'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 3 -->
                                <div class="ques">
                                    <p class="qn">3. The safety valve installed on a coil-type auxiliary boiler is
                                        located on
                                        the ____________.
                                    </p>
                                    <hr>

                                    <div id='block-9' class="qo">
                                        <label for='ox9' class="ll">
                                            <input type='radio' name='option' id='ox9' class="on" />
                                            <em>thermostat tube</em></label>
                                        <span id='rx9'></span>
                                    </div>


                                    <div id='block-10' class="qo">
                                        <label for='ox10' class="ll">
                                            <input type='radio' name='option' id='ox10' class="on" />
                                            <em>topmost coil
                                            </em></label>
                                        <span id='rx10'></span>
                                    </div>


                                    <div id='block-11' class="qo">
                                        <label for='ox11' class="ll">
                                            <input type='radio' name='option' id='ox11' class="on" />
                                            <em>water tank
                                            </em></label>
                                        <span id='rx11'></span>
                                    </div>


                                    <div id='block-12' class="qo">
                                        <label for='ox12' class="ll">
                                            <input type='radio' name='option' id='ox12' class="on" />
                                            <em>fclearance chamber</em></label>
                                        <span id='rx12'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 4 -->
                                <div class="ques">
                                    <p class="qn">4. Auxiliary boilers are divided into several classifications, one of
                                        which
                                        is _____________.
                                    </p>
                                    <hr>

                                    <div id='block-13' class="qo">
                                        <label for='ox13' class="ll">
                                            <input type='radio' name='option' id='ox13' class="on" />
                                            <em>fire-tube controlled circulation
                                            </em></label>
                                        <span id='rx13'></span>
                                    </div>


                                    <div id='block-14' class="qo">
                                        <label for='ox14' class="ll">
                                            <input type='radio' name='option' id='ox14' class="on" />
                                            <em>fire-tube controlled circulation
                                            </em></label>
                                        <span id='rx14'></span>
                                    </div>


                                    <div id='block-15' class="qo">
                                        <label for='ox15' class="ll">
                                            <input type='radio' name='option' id='ox15' class="on" />
                                            <em>water-tube natural circulation
                                            </em></label>
                                        <span id='rx15'></span>
                                    </div>


                                    <div id='block-16' class="qo">
                                        <label for='ox16' class="ll">
                                            <input type='radio' name='option' id='ox16' class="on" />
                                            <em>water tube express circulation
                                            </em></label>
                                        <span id='rx16'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 5 -->
                                <div class="ques">
                                    <p class="qn">5. Auxiliary boilers are divided into several classifications, one of
                                        which
                                        is ______________.
                                    </p>
                                    <hr>

                                    <div id='block-17' class="qo">
                                        <label for='ox17' class="ll">
                                            <input type='radio' name='option' id='ox17' class="on" />
                                            <em>water-tube supercritical circulation</em></label>
                                        <span id='rx17'></span>
                                    </div>


                                    <div id='block-18' class="qo">
                                        <label for='ox18' class="ll">
                                            <input type='radio' name='option' id='ox18' class="on" />
                                            <em>water-tube forced circulation</em></label>
                                        <span id='rx18'></span>
                                    </div>


                                    <div id='block-19' class="qo">
                                        <label for='ox19' class="ll">
                                            <input type='radio' name='option' id='ox19' class="on" />
                                            <em>fire-tube controlled circulation </em></label>
                                        <span id='rx19'></span>
                                    </div>


                                    <div id='block-20' class="qo">
                                        <label for='ox20' class="ll">
                                            <input type='radio' name='option' id='ox20' class="on" />
                                            <em>fire-tube express circulation
                                            </em></label>
                                        <span id='rx20'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 6 -->
                                <div class="ques">
                                    <p class="qn">6. The tube sheets installed in a fire-tube auxiliary boiler are
                                        normally
                                        connected by ____________.
                                    </p>
                                    <hr>

                                    <div id='block-21' class="qo">
                                        <label for='ox21' class="ll">
                                            <input type='radio' name='option' id='ox21' class="on" />
                                            <em>girder stays
                                            </em></label>
                                        <span id='rx21'></span>
                                    </div>


                                    <div id='block-22' class="qo">
                                        <label for='ox22' class="ll">
                                            <input type='radio' name='option' id='ox22' class="on" />
                                            <em>fire-tubes and stay-tubes</em></label>
                                        <span id='rx22'></span>
                                    </div>


                                    <div id='block-23' class="qo">
                                        <label for='ox23' class="ll">
                                            <input type='radio' name='option' id='ox23' class="on" />
                                            <em>external boiler plating
                                            </em></label>
                                        <span id='rx23'></span>
                                    </div>


                                    <div id='block-24' class="qo">
                                        <label for='ox24' class="ll">
                                            <input type='radio' name='option' id='ox24' class="on" />
                                            <em>external boiler plating
                                            </em></label>
                                        <span id='rx24'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 7 -->
                                <div class="ques">
                                    <p class="qn">7. In a coil-type forced circulation auxiliary water-tube boiler,
                                        ____________.
                                    </p>
                                    <hr>

                                    <div id='block-25' class="qo">
                                        <label for='ox25' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox25'
                                                class="on" />
                                            <em>steam demand response is comparatively rapid</em></label>
                                        <span id='rx25'></span>
                                    </div>


                                    <div id='block-26' class="qo">
                                        <label for='ox26' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox26'
                                                class="on" />
                                            <em>steam is recirculated through heating coils in the boiler
                                            </em></label>
                                        <span id='rx26'></span>
                                    </div>


                                    <div id='block-27' class="qo">
                                        <label for='ox27' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                                class="on" />
                                            <em>unevaporated feedwater is discharged through the skim tube</em></label>
                                        <span id='rx27'></span>
                                    </div>


                                    <div id='block-28' class="qo">
                                        <label for='ox28' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                                class="on" />
                                            <em>steam demand response is slow
                                            </em></label>
                                        <span id='rx28'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 8 -->
                                <div class="ques">
                                    <p class="qn">8. Which type of pump is typically used to supply fuel to a unit type
                                        auxiliary boiler?
                                    </p>
                                    <hr>

                                    <div id='block-29' class="qo">
                                        <label for='ox29' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox29'
                                                class="on" />
                                            <em>Centrifugal
                                            </em></label>
                                        <span id='rx29'></span>
                                    </div>


                                    <div id='block-30' class="qo">
                                        <label for='ox30' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox30'
                                                class="on" />
                                            <em>Propeller
                                            </em></label>
                                        <span id='rx30'></span>
                                    </div>


                                    <div id='block-31' class="qo">
                                        <label for='ox31' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                                class="on" />
                                            <em>Reciprocating
                                            </em></label>
                                        <span id='rx31'></span>
                                    </div>


                                    <div id='block-32' class="qo">
                                        <label for='ox32' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                                class="on" />
                                            <em>Rotary
                                            </em></label>
                                        <span id='rx32'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 9 -->
                                <div class="ques">
                                    <p class="qn">9. The principal purpose of refractory and insulation installed in the
                                        firebox of an auxiliary boiler is to ____________.
                                    </p>
                                    <hr>

                                    <div id='block-33' class="qo">
                                        <label for='ox33' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox33'
                                                class="on" />
                                            <em>prevent flame impingement on the generating tube bank
                                            </em></label>
                                        <span id='rx33'></span>
                                    </div>


                                    <div id='block-34' class="qo">
                                        <label for='ox34' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox34'
                                                class="on" />
                                            <em>direct the force draft into the space between the inner and outer
                                                casings, to maintain a pressure seal
                                            </em></label>
                                        <span id='rx34'></span>
                                    </div>


                                    <div id='block-35' class="qo">
                                        <label for='ox35' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                                class="on" />
                                            <em>protect the inner casing and reduce heat loss
                                            </em></label>
                                        <span id='rx35'></span>
                                    </div>


                                    <div id='block-36' class="qo">
                                        <label for='ox36' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                                class="on" />
                                            <em>protect the inner casing and reduce heat loss
                                            </em></label>
                                        <span id='rx36'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 10 -->
                                <div class="ques">
                                    <p class="qn">10. In a coil-type auxiliary water-tube circulation boiler
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-37' class="qo">
                                        <label for='ox37' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox37'
                                                class="on" />
                                            <em>unevaporated feedwater collects in the bottom of the fclearance
                                                chamber
                                            </em></label>
                                        <span id='rx37'></span>
                                    </div>


                                    <div id='block-38' class="qo">
                                        <label for='ox38' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox38'
                                                class="on" />
                                            <em>all generated steam is recirculated through heating coils in the boiler
                                            </em></label>
                                        <span id='rx38'></span>
                                    </div>


                                    <div id='block-39' class="qo">
                                        <label for='ox39' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                                class="on" />
                                            <em>heated water fclearancees to steam in the boiler heating coils
                                            </em></label>
                                        <span id='rx39'></span>
                                    </div>


                                    <div id='block-40' class="qo">
                                        <label for='ox40' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                                class="on" />
                                            <em>response to steam demand is slower than in a fire-tube boiler
                                            </em></label>
                                        <span id='rx40'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 11 -->
                                <div class="ques">
                                    <p class="qn">11. Before any work is to be carried out on a burner in an
                                        automatically
                                        fired auxiliary boiler, you should always _____________.
                                    </p>
                                    <hr>

                                    <div id='block-41' class="qo">
                                        <label for='ox41' class="ll">
                                            <input type='radio' name='option' id='ox41' class="on" />
                                            <em>block all control system relays closed</em></label>
                                        <span id='rx41'></span>
                                    </div>


                                    <div id='block-42' class="qo">
                                        <label for='ox42' class="ll">
                                            <input type='radio' name='option' id='ox42' class="on" />
                                            <em>allow the boiler to cool completely</em></label>
                                        <span id='rx42'></span>
                                    </div>


                                    <div id='block-43' class="qo">
                                        <label for='ox43' class="ll">
                                            <input type='radio' name='option' id='ox43' class="on" />
                                            <em>close all manually operated fuel valves</em></label>
                                        <span id='rx43'></span>
                                    </div>


                                    <div id='block-44' class="qo">
                                        <label for='ox44' class="ll">
                                            <input type='radio' name='option' id='ox44' class="on" />
                                            <em>lock all safety interlock switches closed</em></label>
                                        <span id='rx44'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 12 -->
                                <div class="ques">
                                    <p class="qn">12. Which of the following procedures decreases the total dissolved
                                        solids concentration in the water of an auxiliary boiler?
                                    </p>
                                    <hr>

                                    <div id='block-45' class="qo">
                                        <label for='ox45' class="ll">
                                            <input type='radio' name='option' id='ox45' class="on" />
                                            <em>Hydrazine treatment of condensate
                                            </em></label>
                                        <span id='rx45'></span>
                                    </div>


                                    <div id='block-46' class="qo">
                                        <label for='ox46' class="ll">
                                            <input type='radio' name='option' id='ox46' class="on" />
                                            <em>Frequent compounding
                                            </em></label>
                                        <span id='rx46'></span>
                                    </div>


                                    <div id='block-47' class="qo">
                                        <label for='ox47' class="ll">
                                            <input type='radio' name='option' id='ox47' class="on" />
                                            <em>Chemical cleaning
                                            </em></label>
                                        <span id='rx47'></span>
                                    </div>


                                    <div id='block-48' class="qo">
                                        <label for='ox48' class="ll">
                                            <input type='radio' name='option' id='ox48' class="on" />
                                            <em>Bottom blowing
                                            </em></label>
                                        <span id='rx48'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 13 -->
                                <div class="ques">
                                    <p class="qn">13. How is the concentration of dissolved oxygen in the feedwater of
                                        an auxiliary boiler maintained at acceptable limits?
                                    </p>
                                    <hr>

                                    <div id='block-49' class="qo">
                                        <label for='ox49' class="ll">
                                            <input type='radio' name='option' id='ox49' class="on" />
                                            <em>Feedwater is cycled through a DC heater.
                                            </em></label>
                                        <span id='rx49'></span>
                                    </div>


                                    <div id='block-50' class="qo">
                                        <label for='ox50' class="ll">
                                            <input type='radio' name='option' id='ox50' class="on" />
                                            <em>Feedwater is treated with phosphates.
                                            </em></label>
                                        <span id='rx50'></span>
                                    </div>


                                    <div id='block-51' class="qo">
                                        <label for='ox51' class="ll">
                                            <input type='radio' name='option' id='ox51' class="on" />
                                            <em>Oxygen is liberated in the three-stages of feedwater preheating.
                                            </em></label>
                                        <span id='rx51'></span>
                                    </div>


                                    <div id='block-52' class="qo">
                                        <label for='ox52' class="ll">
                                            <input type='radio' name='option' id='ox52' class="on" />
                                            <em>Oxygen is liberated by maintaining the highest practical feedwater
                                                temperature.
                                            </em></label>
                                        <span id='rx52'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 14 -->
                                <div class="ques">
                                    <p class="qn">14. A sprayer plate used in a return flow fuel oil atomizer is
                                        correctly
                                        installed if the oil __________.
                                    </p>
                                    <hr>

                                    <div id='block-53' class="qo">
                                        <label for='ox53' class="ll">
                                            <input type='radio' name='option' id='ox53' class="on" />
                                            <em>passes through the whirling chamber before passing through the
                                                tangential slots
                                            </em></label>
                                        <span id='rx53'></span>
                                    </div>


                                    <div id='block-54' class="qo">
                                        <label for='ox54' class="ll">
                                            <input type='radio' name='option' id='ox54' class="on" />
                                            <em>passes through the tangential slots before passing through the
                                                whirling chamber
                                            </em></label>
                                        <span id='rx54'></span>
                                    </div>


                                    <div id='block-55' class="qo">
                                        <label for='ox55' class="ll">
                                            <input type='radio' name='option' id='ox55' class="on" />
                                            <em>leaves the burner as a straight stream until mixed with the primary
                                                flow of combustion air
                                            </em></label>
                                        <span id='rx55'></span>
                                    </div>


                                    <div id='block-56' class="qo">
                                        <label for='ox56' class="ll">
                                            <input type='radio' name='option' id='ox56' class="on" />
                                            <em>leaves the burner as a straight stream until mixed with the swirling
                                                atomizing steam
                                            </em></label>
                                        <span id='rx56'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 15 -->
                                <div class="ques">
                                    <p class="qn">15. A burner producing black smoke in an automatic auxiliary boiler,
                                        would be caused by a/an ______________.
                                    </p>
                                    <hr>

                                    <div id='block-57' class="qo">
                                        <label for='ox57' class="ll">
                                            <input type='radio' name='option' id='ox57' class="on" />
                                            <em>incorrect electrode setting
                                            </em></label>
                                        <span id='rx57'></span>
                                    </div>


                                    <div id='block-58' class="qo">
                                        <label for='ox58' class="ll">
                                            <input type='radio' name='option' id='ox58' class="on" />
                                            <em>defective solenoid valve
                                            </em></label>
                                        <span id='rx58'></span>
                                    </div>


                                    <div id='block-59' class="qo">
                                        <label for='ox59' class="ll">
                                            <input type='radio' name='option' id='ox59' class="on" />
                                            <em>grounded high tension lead</em></label>
                                        <span id='rx59'></span>
                                    </div>


                                    <div id='block-60' class="qo">
                                        <label for='ox60' class="ll">
                                            <input type='radio' name='option' id='ox60' class="on" />
                                            <em>incorrect primary air setting</em></label>
                                        <span id='rx60'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 16 -->
                                <div class="ques">
                                    <p class="qn">16. The water in an auxiliary boiler should be chemically tested daily
                                        for
                                        alkalinity and _________________.
                                    </p>
                                    <hr>

                                    <div id='block-61' class="qo">
                                        <label for='ox61' class="ll">
                                            <input type='radio' name='option' id='ox61' class="on" />
                                            <em>soap hardness
                                            </em></label>
                                        <span id='rx61'></span>
                                    </div>


                                    <div id='block-62' class="qo">
                                        <label for='ox62' class="ll">
                                            <input type='radio' name='option' id='ox62' class="on" />
                                            <em>nitrogen content
                                            </em></label>
                                        <span id='rx62'></span>
                                    </div>


                                    <div id='block-63' class="qo">
                                        <label for='ox63' class="ll">
                                            <input type='radio' name='option' id='ox63' class="on" />
                                            <em>chloride content
                                            </em></label>
                                        <span id='rx63'></span>
                                    </div>


                                    <div id='block-64' class="qo">
                                        <label for='ox64' class="ll">
                                            <input type='radio' name='option' id='ox64' class="on" />
                                            <em>chloride content
                                            </em></label>
                                        <span id='rx64'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 17 -->
                                <div class="ques">
                                    <p class="qn">17. The water in an auxiliary boiler should be tested for chloride
                                        content to determine ______________.
                                    </p>
                                    <hr>

                                    <div id='block-65' class="qo">
                                        <label for='ox65' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox65'
                                                class="on" />
                                            <em>total dissolved solids </em></label>
                                        <span id='rx65'></span>
                                    </div>


                                    <div id='block-66' class="qo">
                                        <label for='ox66' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox66'
                                                class="on" />
                                            <em>salt contamination
                                            </em></label>
                                        <span id='rx66'></span>
                                    </div>


                                    <div id='block-67' class="qo">
                                        <label for='ox67' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                                class="on" />
                                            <em>water hardness
                                            </em></label>
                                        <span id='rx67'></span>
                                    </div>


                                    <div id='block-68' class="qo">
                                        <label for='ox68' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                                class="on" />
                                            <em>chlorine contamination
                                            </em></label>
                                        <span id='rx68'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 18 -->
                                <div class="ques">
                                    <p class="qn">18. For proper operation, auxiliary boiler feedwater must have which
                                        of
                                        the following characteristics?
                                    </p>
                                    <hr>

                                    <div id='block-69' class="qo">
                                        <label for='ox69' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox69'
                                                class="on" />
                                            <em>High oxygen concentration
                                            </em></label>
                                        <span id='rx69'></span>
                                    </div>


                                    <div id='block-70' class="qo">
                                        <label for='ox70' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox70'
                                                class="on" />
                                            <em>Low pH
                                            </em></label>
                                        <span id='rx70'></span>
                                    </div>


                                    <div id='block-71' class="qo">
                                        <label for='ox71' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                                class="on" />
                                            <em>Proper alkalinity
                                            </em></label>
                                        <span id='rx71'></span>
                                    </div>


                                    <div id='block-72' class="qo">
                                        <label for='ox72' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                                class="on" />
                                            <em>All of the above
                                            </em></label>
                                        <span id='rx72'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 19 -->
                                <div class="ques">
                                    <p class="qn">19. The procedures recommended for auxiliary boilers having high
                                        salinity include ____________.
                                    </p>
                                    <hr>

                                    <div id='block-73' class="qo">
                                        <label for='ox73' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox73'
                                                class="on" />
                                            <em>treating with oxygen scavengers</em></label>
                                        <span id='rx73'></span>
                                    </div>


                                    <div id='block-74' class="qo">
                                        <label for='ox74' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox74'
                                                class="on" />
                                            <em>securing the boiler and giving it a bottom blow
                                            </em></label>
                                        <span id='rx74'></span>
                                    </div>


                                    <div id='block-75' class="qo">
                                        <label for='ox75' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                                class="on" />
                                            <em>increasing the pH
                                            </em></label>
                                        <span id='rx75'></span>
                                    </div>


                                    <div id='block-76' class="qo">
                                        <label for='ox76' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                                class="on" />
                                            <em>reducing the phosphate level </em></label>
                                        <span id='rx76'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 20 -->
                                <div class="ques">
                                    <p class="qn">20. The concentration of dissolved solids in the boiler water of an
                                        auxiliary boiler could increase as a result of ___________.
                                    </p>
                                    <hr>

                                    <div id='block-77' class="qo">
                                        <label for='ox77' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox77'
                                                class="on" />
                                            <em>phosphate treatment
                                            </em></label>
                                        <span id='rx77'></span>
                                    </div>


                                    <div id='block-78' class="qo">
                                        <label for='ox78' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox78'
                                                class="on" />
                                            <em>zero water hardness
                                            </em></label>
                                        <span id='rx78'></span>
                                    </div>


                                    <div id='block-79' class="qo">
                                        <label for='ox79' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                                class="on" />
                                            <em>dissolved oxygen deaeration
                                            </em></label>
                                        <span id='rx79'></span>
                                    </div>


                                    <div id='block-80' class="qo">
                                        <label for='ox80' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                                class="on" />
                                            <em>frequent bottom blows
                                            </em></label>
                                        <span id='rx80'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                    </div>
                                </div>
                                <hr>



                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/auxiliary_boiler/asset/"; include($IPATH."auxiliary_sidebar.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/1.php">1</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/2.php">2</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/3.php">3</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/4.php">4</a>
                        </li>
                        <li class="page-item active" aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/5.php">5</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/6.php">6</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/7.php">7</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/auxiliary_boiler/8.php">8</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>