<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">

    <title>Marine Engineering | samudramanthan.co.in</title>
    <meta name="description"
        content="Learn and practice questions and answers with explanation for marine engineering, competitive examination and entrance test." />
    <meta name="keywords"
        content="marine, engineering, marine engineering, samudramanthan.co.in, more.., system, systems, home, fuel, instrumentation, control, air, heat, ship, know more.., system know, systems know, engineering marine, more.. fuel, instrumentation know, system know more.., systems know more.., engineering marine engineering, know more.. fuel, instrumentation know more..," />
</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
            </ul>
        </div>
        <!-- path end -->

        <!-- slider start -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-5">
                <div class="col-lg-6 col-md-8 mx-auto">
                    <h1 class="fw-light" style="font-family: cursive; font-weight: bolder; font-size: 45px ;">Marine
                        Engineering</h1>
                </div>
            </div>
        </section>


        <!-- slider end -->

        <!-- marketing start  -->
        <div class="album py-5 bg-light">
            <div class="container">

                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/motor_design_component.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>MOTOR</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/motor/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/lubrication.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>LUBRICATING SYSTEMS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/lubricating_system/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/fuel_system.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>FUEL SYSTEMS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/fuel_system/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/aux_boiler.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>AUXILIARY BOILER</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/auxiliary_boiler/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/four_s_engine.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>FOUR STROKE ENGINES</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/four_stroke_engine/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/aut_instrumentation.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>AUTOMATION - INSTRUMENTATION</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/automation/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/turbocharger.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>SCAVENGING,TURBOCHARGING &
                                        AIRCOOLING</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/scavenging_turbocharging/1.php"
                                                style="text-decoration: none; color: black;">Know
                                                More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/governor.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>GOVERNOR AND OVERSPEED CONTROL</strong>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/governor/1.php"
                                                style="text-decoration: none; color: black;">Know
                                                More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/clutch.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>POWER TRANSMISSION,GEARS AND
                                        CLUTCHES</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/power_transmission/1.php"
                                                style="text-decoration: none; color: black;">Know
                                                More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/cooling_system.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>COOLING SYSTEMS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/cooling_system/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/CSS/Mech1.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>MISCELLANEOUS QUESTIONS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/miscellanous_question/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/pump.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>PUMPS AND EDUCTORS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/pump_eductors/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/workshop.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>WORKSHOP PRACTICE, BRAZING, WELDING & GAS
                                        CUTTING</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/workshop_practice/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/rac.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>REFRIGERATION AND AIR
                                        CONDITIONING</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/rac/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/propellor_shaft.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>PROPELLER, SHAFTING AND STERN TUBE
                                        BEARING</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/propeller_shaft/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/fuel_oil.png" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>FUEL OIL PROPERTIES AND PURIFIERS</strong>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/fuel_oil_properties/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/ndt.png" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>METALLURGY AND NON-DESTRUCTIVE
                                        TESTING</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/metallurgy_ndt/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/steam.png" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>STEAM, HEAT AND THERMODYNAMICS</strong>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/steam_heat/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/bilge.png" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>BILGE SYSTEM</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/bilge_system/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/compressed.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>COMPRESSED AIR SYSTEM</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/compressed_air_system/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/heat_exchanger.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>HEAT EXCHANGERS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/heat_exchangers/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/sewage.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>SANITARY AND SEWAGE SYSTEM</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/sanitary_sewage/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/pipe_valves.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>PIPES AND VALVES</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/pipes_valves/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/steering.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>STEERING</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/steering/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/marine_control.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>MARINE CONTROL SYSTEMS AND
                                        INSTRUMENTATION</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/marine_control_instrumentation/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/purified_water.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>DISTILLING SYSTEM AND POTABLE WATER
                                        SYSTEM</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/potable_water_system/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/ship_construction.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>SHIP CONSTRUCTION, REPAIRS AND
                                        REGULATIONS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/ship_construction/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/hydraulic.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>HYDRAULICS AND DECK MACHINERY</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/hydraulic_deck/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/ant_friction.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>LUBRICATION AND ANTI-FRICTION
                                        BEARINGS</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/anti_friction_bearing/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/safety.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>SAFETY, ENVIRONMENTAL PRO., SHIP CONS. &
                                        NAVAL ARCH.</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/safety_environment/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="/marine/electro_technolgy.jpg" alt="" width="100%" height="225">

                            <div class="card-body">
                                <p class="card-text lead text-muted"> <strong>ELECTRO - TECHNOLOGY</strong></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary"><a
                                                href="/marine_engineering/electro_technology/1.php"
                                                style="text-decoration: none; color: black;">Know More...</a></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- marketing end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->


        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>

        <!-- Option 2: Separate Popper and Bootstrap JS -->
        <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>

</html>