<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/motor/javascript/28.js"></script>

    <title>Motor: Maintenance, Design, Components, Operation (Set28)</title>
    <meta name="description"
        content="A diesel engine will lose power if fuel injection occurs too..., Which of the following conditions is most likely to occur when unburned..., Late fuel injection in a diesel engine is indicated byblack..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, motor, design, operation, services, fuel, engine, submit, diesel, oil, injection, cylinder, pressure, system, increase, high, lube, exhaust, air, temperatures, compression, temperature, water, engineering, marine, power, injector, ignition, valve, result, starting, check, excessive, cooling, systems, late, smoke, decrease, normal, intake, stroke, carbon, ring, mechanical, conditions, crankcase, viscosity, bearings, develop, deposits, knock, piston, speeds, greater, horsepower, nozzle, listed, caused, load, spray, plunger, scavenge, propulsion, test, cylinders, decreased, faulty, prevent, overspeed, blue, lines, pistons, strainers, damage, operating, extended, formation, combustion, governor, malfunctions, instrumentation, control, heat, ship, page, diesel engine, the fuel, a diesel, fuel injection, in the, of the, lube oil, fuel oil, of a, the engine, engine will, the cylinder, in a, result in, marine engineering, because the, not be, cylinder compression, which of, will result, a fuel, can be, increase in, check the, services marine, engineering motor, if fuel, fuel will, compression pressure, pressure will, be too, the crankcase, late fuel, injection in, exhaust temperature, knock in, in each, each cylinder, of diesel, than normal, through the, the intake, an increase, caused by, may be, pressure may, may not, be high, high enough, enough cylinder, propulsion diesel, from that, engine fuel, water in, blue smoke, fuel lines, engine can, can cause, the air, will increase, operating a, excessive ring, ring temperatures, a diesel engine, of a diesel, in the fuel, diesel engine will, which of the, in a diesel, will result in, the fuel oil, services marine engineering, marine engineering motor, if fuel injection, because the fuel, in the cylinder, cylinder compression pressure, late fuel injection, fuel injection in, injection in a, knock in each, in each cylinder, a fuel injection, an increase in, pressure may not, may not be, not be high, be high enough, high enough cylinder, enough cylinder compression, propulsion diesel engine, diesel engine fuel, water in the, the fuel lines, diesel engine can, engine can cause, of the engine, excessive ring temperatures, of a diesel engine, in a diesel engine, services marine engineering motor, a diesel engine will, fuel injection in a, injection in a diesel, knock in each cylinder, pressure may not be, may not be high, not be high enough, be high enough cylinder, high enough cylinder compression, water in the fuel, a diesel engine can, diesel engine can cause, fuel injection in a diesel, injection in a diesel engine, pressure may not be high, may not be high enough, not be high enough cylinder, be high enough cylinder compression, of a diesel engine can, a diesel engine can cause" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12"></div>
        <ul id="breadcrumbs-course">
            <li><a href="/Index.php">Home</a></li>
            <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
            <li><a href="/marine_engineering/motor/28.php" style="cursor: default;">MOTOR: <span style="color:#7f0804;"
                        id="lecid">MCQ</span></a></li>
        </ul>
    </div>
    <!-- path end -->
    <!-- main1 start  -->
    <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
        style="background-color: whitesmoke;">
        <div class="row py-lg-8">
            <main class="container bg-light">
                <div class="row">
                    <div class="col-md-8">

                        <article class="blog-post">
                            <h1 class="blog-post-title">Motor: Maintenance, Design, Components, Operation (Set28)</h1>
                            <hr>
                            <p>
                            <h4>Multiple Choice Questions</h4>
                            <hr>
                            <!-- Question 1 -->
                            <div class="ques">
                                <p class="qn">1. A diesel engine will lose power if fuel injection occurs too late in
                                    the
                                    cycle, because the ______________.
                                </p>
                                <hr>

                                <div id='block-1' class="qo">
                                    <label for='ox1' class="ll">
                                        <input type='radio' name='option' id='ox1' class="on" />
                                        <em>fuel droplets will burn as they leave the fuel injector
                                        </em></label>
                                    <span id='rx1'></span>
                                </div>


                                <div id='block-2' class="qo">
                                    <label for='ox2' class="ll">
                                        <input type='radio' name='option' id='ox2' class="on" />
                                        <em>fuel will not be properly atomized in the cylinder
                                        </em></label>
                                    <span id='rx2'></span>
                                </div>


                                <div id='block-3' class="qo">
                                    <label for='ox3' class="ll">
                                        <input type='radio' name='option' id='ox3' class="on" />
                                        <em>maximum expansion of the burned fuel cannot take place in the
                                            cylinder</em></label>
                                    <span id='rx3'></span>
                                </div>


                                <div id='block-4' class="qo">
                                    <label for='ox4' class="ll">
                                        <input type='radio' name='option' id='ox4' class="on" />
                                        <em>compression pressure will be too low to cause fuel ignition
                                        </em></label>
                                    <span id='rx4'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 2 -->
                            <div class="ques">
                                <p class="qn">2. Which of the following conditions is most likely to occur when
                                    unburned fuel contaminates the crankcase of a diesel engine?
                                </p>
                                <hr>

                                <div id='block-5' class="qo">
                                    <label for='ox5' class="ll">
                                        <input type='radio' name='option' id='ox5' class="on" />
                                        <em>Lube oil is diluted and its viscosity is reduced.
                                        </em></label>
                                    <span id='rx5'></span>
                                </div>


                                <div id='block-6' class="qo">
                                    <label for='ox6' class="ll">
                                        <input type='radio' name='option' id='ox6' class="on" />
                                        <em>sulphuric acid is formed.
                                        </em></label>
                                    <span id='rx6'></span>
                                </div>


                                <div id='block-7' class="qo">
                                    <label for='ox7' class="ll">
                                        <input type='radio' name='option' id='ox7' class="on" />
                                        <em>Bearings become pitted and immediately fail.
                                        </em></label>
                                    <span id='rx7'></span>
                                </div>


                                <div id='block-8' class="qo">
                                    <label for='ox8' class="ll">
                                        <input type='radio' name='option' id='ox8' class="on" />
                                        <em>Valve stems develop sludge deposits.
                                        </em></label>
                                    <span id='rx8'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 3 -->
                            <div class="ques">
                                <p class="qn">3. Late fuel injection in a diesel engine is indicated byblack or gray
                                    exhaust smoke with a _____________.
                                </p>
                                <hr>

                                <div id='block-9' class="qo">
                                    <label for='ox9' class="ll">
                                        <input type='radio' name='option' id='ox9' class="on" />
                                        <em>low firing pressure</em></label>
                                    <span id='rx9'></span>
                                </div>


                                <div id='block-10' class="qo">
                                    <label for='ox10' class="ll">
                                        <input type='radio' name='option' id='ox10' class="on" />
                                        <em>low exhaust temperature
                                        </em></label>
                                    <span id='rx10'></span>
                                </div>


                                <div id='block-11' class="qo">
                                    <label for='ox11' class="ll">
                                        <input type='radio' name='option' id='ox11' class="on" />
                                        <em>mechanical knock in each cylinder
                                        </em></label>
                                    <span id='rx11'></span>
                                </div>


                                <div id='block-12' class="qo">
                                    <label for='ox12' class="ll">
                                        <input type='radio' name='option' id='ox12' class="on" />
                                        <em>fuel knock in each cylinder</em></label>
                                    <span id='rx12'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 4 -->
                            <div class="ques">
                                <p class="qn">4. The ignition quality of diesel fuel becomes less critical as
                                    ______________.
                                </p>
                                <hr>

                                <div id='block-13' class="qo">
                                    <label for='ox13' class="ll">
                                        <input type='radio' name='option' id='ox13' class="on" />
                                        <em>the amount of lube oil additives increase
                                        </em></label>
                                    <span id='rx13'></span>
                                </div>


                                <div id='block-14' class="qo">
                                    <label for='ox14' class="ll">
                                        <input type='radio' name='option' id='ox14' class="on" />
                                        <em>piston speeds increase</em></label>
                                    <span id='rx14'></span>
                                </div>


                                <div id='block-15' class="qo">
                                    <label for='ox15' class="ll">
                                        <input type='radio' name='option' id='ox15' class="on" />
                                        <em>injection pressures decrease</em></label>
                                    <span id='rx15'></span>
                                </div>


                                <div id='block-16' class="qo">
                                    <label for='ox16' class="ll">
                                        <input type='radio' name='option' id='ox16' class="on" />
                                        <em>engine speeds decrease</em></label>
                                    <span id='rx16'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 5 -->
                            <div class="ques">
                                <p class="qn">5. Higher than normal temperature air passing through the intake of a
                                    diesel engine will result in _____________.
                                </p>
                                <hr>

                                <div id='block-17' class="qo">
                                    <label for='ox17' class="ll">
                                        <input type='radio' name='option' id='ox17' class="on" />
                                        <em>greater overall efficiency
                                        </em></label>
                                    <span id='rx17'></span>
                                </div>


                                <div id='block-18' class="qo">
                                    <label for='ox18' class="ll">
                                        <input type='radio' name='option' id='ox18' class="on" />
                                        <em>greater fuel economy
                                        </em></label>
                                    <span id='rx18'></span>
                                </div>


                                <div id='block-19' class="qo">
                                    <label for='ox19' class="ll">
                                        <input type='radio' name='option' id='ox19' class="on" />
                                        <em>lower horsepower
                                        </em></label>
                                    <span id='rx19'></span>
                                </div>


                                <div id='block-20' class="qo">
                                    <label for='ox20' class="ll">
                                        <input type='radio' name='option' id='ox20' class="on" />
                                        <em>lower compression ratio</em></label>
                                    <span id='rx20'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 6 -->
                            <div class="ques">
                                <p class="qn">6. When a fuel injection nozzle overheats, which of the problems
                                    listed can be expected?
                                </p>
                                <hr>

                                <div id='block-21' class="qo">
                                    <label for='ox21' class="ll">
                                        <input type='radio' name='option' id='ox21' class="on" />
                                        <em>The fuel metering will vary.</em></label>
                                    <span id='rx21'></span>
                                </div>


                                <div id='block-22' class="qo">
                                    <label for='ox22' class="ll">
                                        <input type='radio' name='option' id='ox22' class="on" />
                                        <em>The fuel will explode. </em></label>
                                    <span id='rx22'></span>
                                </div>


                                <div id='block-23' class="qo">
                                    <label for='ox23' class="ll">
                                        <input type='radio' name='option' id='ox23' class="on" />
                                        <em>The cylinder head will crack.</em></label>
                                    <span id='rx23'></span>
                                </div>


                                <div id='block-24' class="qo">
                                    <label for='ox24' class="ll">
                                        <input type='radio' name='option' id='ox24' class="on" />
                                        <em>The engine will stop.</em></label>
                                    <span id='rx24'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 7 -->
                            <div class="ques">
                                <p class="qn">7. An increase in the fuel injection pump discharge pressure can be
                                    caused by a/an _____________.
                                    <hr>

                                <div id='block-25' class="qo">
                                    <label for='ox25' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox25' class="on" />
                                        <em>leaking delivery valve</em></label>
                                    <span id='rx25'></span>
                                </div>


                                <div id='block-26' class="qo">
                                    <label for='ox26' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox26' class="on" />
                                        <em>increase in engine load</em></label>
                                    <span id='rx26'></span>
                                </div>


                                <div id='block-27' class="qo">
                                    <label for='ox27' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                            class="on" />
                                        <em>plugged injector spray hole
                                        </em></label>
                                    <span id='rx27'></span>
                                </div>


                                <div id='block-28' class="qo">
                                    <label for='ox28' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                            class="on" />
                                        <em>increased plunger stroke
                                        </em></label>
                                    <span id='rx28'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 8 -->
                            <div class="ques">
                                <p class="qn">8. If fuel injection in a diesel engine begins earlier than the design
                                    start
                                    of injection, ignition may be delayed because the _____________.</p>
                                <hr>

                                <div id='block-29' class="qo">
                                    <label for='ox29' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox29' class="on" />
                                        <em>fuel oil injection pressure may not be high enough</em></label>
                                    <span id='rx29'></span>
                                </div>


                                <div id='block-30' class="qo">
                                    <label for='ox30' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox30' class="on" />
                                        <em>cylinder compression pressure may not be high enough</em></label>
                                    <span id='rx30'></span>
                                </div>


                                <div id='block-31' class="qo">
                                    <label for='ox31' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                            class="on" />
                                        <em>cylinder compression temperature may be too high
                                        </em></label>
                                    <span id='rx31'></span>
                                </div>


                                <div id='block-32' class="qo">
                                    <label for='ox32' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                            class="on" />
                                        <em>scavenge and purge process is incomplete </em></label>
                                    <span id='rx32'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 9 -->
                            <div class="ques">
                                <p class="qn">9. Prior to starting, the purpose of turning over a main propulsion
                                    diesel engine with the cylinder test cocks open, is to
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-33' class="qo">
                                    <label for='ox33' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox33' class="on" />
                                        <em>test the starting system
                                        </em></label>
                                    <span id='rx33'></span>
                                </div>


                                <div id='block-34' class="qo">
                                    <label for='ox34' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox34' class="on" />
                                        <em>remove condensation from the cylinders
                                        </em></label>
                                    <span id='rx34'></span>
                                </div>


                                <div id='block-35' class="qo">
                                    <label for='ox35' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                            class="on" />
                                        <em>check the compression
                                        </em></label>
                                    <span id='rx35'></span>
                                </div>


                                <div id='block-36' class="qo">
                                    <label for='ox36' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                            class="on" />
                                        <em>check for proper lube oil pressure
                                        </em></label>
                                    <span id='rx36'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 10 -->
                            <div class="ques">
                                <p class="qn">10. A fuel injection valve opening at a pressure lower than normal will
                                    result in _____________.
                                </p>
                                <hr>

                                <div id='block-37' class="qo">
                                    <label for='ox37' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox37' class="on" />
                                        <em>late fuel injection </em></label>
                                    <span id='rx37'></span>
                                </div>


                                <div id='block-38' class="qo">
                                    <label for='ox38' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox38' class="on" />
                                        <em>early fuel injection</em></label>
                                    <span id='rx38'></span>
                                </div>


                                <div id='block-39' class="qo">
                                    <label for='ox39' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                            class="on" />
                                        <em>high exhaust temperature from that cylinder</em></label>
                                    <span id='rx39'></span>
                                </div>


                                <div id='block-40' class="qo">
                                    <label for='ox40' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                            class="on" />
                                        <em>decreased effective stroke from that injector</em></label>
                                    <span id='rx40'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 11 -->
                            <div class="ques">
                                <p class="qn">11. Faulty operation of diesel engine fuel injection nozzles can be
                                    directly caused by _____________.
                                </p>
                                <hr>

                                <div id='block-41' class="qo">
                                    <label for='ox41' class="ll">
                                        <input type='radio' name='option' id='ox41' class="on" />
                                        <em>water in the fuel oil supply
                                        </em></label>
                                    <span id='rx41'></span>
                                </div>


                                <div id='block-42' class="qo">
                                    <label for='ox42' class="ll">
                                        <input type='radio' name='option' id='ox42' class="on" />
                                        <em>excessive fuel nozzle holder cooling
                                        </em></label>
                                    <span id='rx42'></span>
                                </div>


                                <div id='block-43' class="qo">
                                    <label for='ox43' class="ll">
                                        <input type='radio' name='option' id='ox43' class="on" />
                                        <em>a distorted fuel spray pattern
                                        </em></label>
                                    <span id='rx43'></span>
                                </div>


                                <div id='block-44' class="qo">
                                    <label for='ox44' class="ll">
                                        <input type='radio' name='option' id='ox44' class="on" />
                                        <em>leakage past the plunger into the oil drain
                                        </em></label>
                                    <span id='rx44'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 12 -->
                            <div class="ques">
                                <p class="qn">12. Water in the fuel can prevent the engine from starting, prevent it
                                    from developing full power, or ____________.
                                </p>
                                <hr>

                                <div id='block-45' class="qo">
                                    <label for='ox45' class="ll">
                                        <input type='radio' name='option' id='ox45' class="on" />
                                        <em>run at an irregular speed
                                        </em></label>
                                    <span id='rx45'></span>
                                </div>


                                <div id='block-46' class="qo">
                                    <label for='ox46' class="ll">
                                        <input type='radio' name='option' id='ox46' class="on" />
                                        <em>create high lube oil temperature
                                        </em></label>
                                    <span id='rx46'></span>
                                </div>


                                <div id='block-47' class="qo">
                                    <label for='ox47' class="ll">
                                        <input type='radio' name='option' id='ox47' class="on" />
                                        <em>cause the engine to overspeed
                                        </em></label>
                                    <span id='rx47'></span>
                                </div>


                                <div id='block-48' class="qo">
                                    <label for='ox48' class="ll">
                                        <input type='radio' name='option' id='ox48' class="on" />
                                        <em>cause blue smoke in the exhaust</em></label>
                                    <span id='rx48'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 13 -->
                            <div class="ques">
                                <p class="qn">13. Air in the fuel lines of a diesel engine can cause _____________.
                                </p>
                                <hr>

                                <div id='block-49' class="qo">
                                    <label for='ox49' class="ll">
                                        <input type='radio' name='option' id='ox49' class="on" />
                                        <em>ignition failure
                                        </em></label>
                                    <span id='rx49'></span>
                                </div>


                                <div id='block-50' class="qo">
                                    <label for='ox50' class="ll">
                                        <input type='radio' name='option' id='ox50' class="on" />
                                        <em>oxygen corrosion of the fuel lines
                                        </em></label>
                                    <span id='rx50'></span>
                                </div>


                                <div id='block-51' class="qo">
                                    <label for='ox51' class="ll">
                                        <input type='radio' name='option' id='ox51' class="on" />
                                        <em> the pistons to seize
                                        </em></label>
                                    <span id='rx51'></span>
                                </div>


                                <div id='block-52' class="qo">
                                    <label for='ox52' class="ll">
                                        <input type='radio' name='option' id='ox52' class="on" />
                                        <em> blue smoke
                                        </em></label>
                                    <span id='rx52'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 14 -->
                            <div class="ques">
                                <p class="qn">14. Before starting a diesel engine, you should always
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-53' class="qo">
                                    <label for='ox53' class="ll">
                                        <input type='radio' name='option' id='ox53' class="on" />
                                        <em>check the pyrometer readings
                                        </em></label>
                                    <span id='rx53'></span>
                                </div>


                                <div id='block-54' class="qo">
                                    <label for='ox54' class="ll">
                                        <input type='radio' name='option' id='ox54' class="on" />
                                        <em>check the crankcase oil level</em></label>
                                    <span id='rx54'></span>
                                </div>


                                <div id='block-55' class="qo">
                                    <label for='ox55' class="ll">
                                        <input type='radio' name='option' id='ox55' class="on" />
                                        <em>change the fuel oil strainers </em></label>
                                    <span id='rx55'></span>
                                </div>


                                <div id='block-56' class="qo">
                                    <label for='ox56' class="ll">
                                        <input type='radio' name='option' id='ox56' class="on" />
                                        <em>clean the air filter</em></label>
                                    <span id='rx56'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 15 -->
                            <div class="ques">
                                <p class="qn">15. Dirt in a fuel oil system of a diesel engine can cause
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-57' class="qo">
                                    <label for='ox57' class="ll">
                                        <input type='radio' name='option' id='ox57' class="on" />
                                        <em>damage to strainers</em></label>
                                    <span id='rx57'></span>
                                </div>


                                <div id='block-58' class="qo">
                                    <label for='ox58' class="ll">
                                        <input type='radio' name='option' id='ox58' class="on" />
                                        <em>overspeeding of the engine
                                        </em></label>
                                    <span id='rx58'></span>
                                </div>


                                <div id='block-59' class="qo">
                                    <label for='ox59' class="ll">
                                        <input type='radio' name='option' id='ox59' class="on" />
                                        <em>excessive cooling of the engine
                                        </em></label>
                                    <span id='rx59'></span>
                                </div>


                                <div id='block-60' class="qo">
                                    <label for='ox60' class="ll">
                                        <input type='radio' name='option' id='ox60' class="on" />
                                        <em>injector damage
                                        </em></label>
                                    <span id='rx60'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 16 -->
                            <div class="ques">
                                <p class="qn">16. If cooling water flow through the aftercooler is interrupted, the
                                    power output of a turbocharged diesel engine will drop because the
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-61' class="qo">
                                    <label for='ox61' class="ll">
                                        <input type='radio' name='option' id='ox61' class="on" />
                                        <em>turbocharger will stall
                                        </em></label>
                                    <span id='rx61'></span>
                                </div>


                                <div id='block-62' class="qo">
                                    <label for='ox62' class="ll">
                                        <input type='radio' name='option' id='ox62' class="on" />
                                        <em>density of the air charge will decrease
                                        </em></label>
                                    <span id='rx62'></span>
                                </div>


                                <div id='block-63' class="qo">
                                    <label for='ox63' class="ll">
                                        <input type='radio' name='option' id='ox63' class="on" />
                                        <em>scavenge effect will increase
                                        </em></label>
                                    <span id='rx63'></span>
                                </div>


                                <div id='block-64' class="qo">
                                    <label for='ox64' class="ll">
                                        <input type='radio' name='option' id='ox64' class="on" />
                                        <em>exhaust pressure will increase</em></label>
                                    <span id='rx64'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 17 -->
                            <div class="ques">
                                <p class="qn">17. Operating a propulsion diesel engine at less than 30% of designed
                                    normal load for prolonged periods will result in ____________.
                                </p>
                                <hr>

                                <div id='block-65' class="qo">
                                    <label for='ox65' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox65' class="on" />
                                        <em>decreased fuel consumption per brake horsepower</em></label>
                                    <span id='rx65'></span>
                                </div>


                                <div id='block-66' class="qo">
                                    <label for='ox66' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox66' class="on" />
                                        <em>more complete cylinder scavenging
                                        </em></label>
                                    <span id='rx66'></span>
                                </div>


                                <div id='block-67' class="qo">
                                    <label for='ox67' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                            class="on" />
                                        <em>extended valve life
                                        </em></label>
                                    <span id='rx67'></span>
                                </div>


                                <div id='block-68' class="qo">
                                    <label for='ox68' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                            class="on" />
                                        <em>carbon formation on combustion chamber surfaces
                                        </em></label>
                                    <span id='rx68'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 18 -->
                            <div class="ques">
                                <p class="qn">18. Diesel engine fuel oil contamination often results in
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-69' class="qo">
                                    <label for='ox69' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox69' class="on" />
                                        <em>governor malfunctions
                                        </em></label>
                                    <span id='rx69'></span>
                                </div>


                                <div id='block-70' class="qo">
                                    <label for='ox70' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox70' class="on" />
                                        <em>fuel injection system malfunctions</em></label>
                                    <span id='rx70'></span>
                                </div>


                                <div id='block-71' class="qo">
                                    <label for='ox71' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                            class="on" />
                                        <em>high cylinder lube oil temperatures
                                        </em></label>
                                    <span id='rx71'></span>
                                </div>


                                <div id='block-72' class="qo">
                                    <label for='ox72' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                            class="on" />
                                        <em>low intake temperatures</em></label>
                                    <span id='rx72'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 19 -->
                            <div class="ques">
                                <p class="qn">19. Operating a diesel engine under light loads and at low
                                    temperatures for an extended period can result in _________.
                                </p>
                                <hr>

                                <div id='block-73' class="qo">
                                    <label for='ox73' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox73' class="on" />
                                        <em>formation of carbon on the intake and exhaust ports
                                        </em></label>
                                    <span id='rx73'></span>
                                </div>


                                <div id='block-74' class="qo">
                                    <label for='ox74' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox74' class="on" />
                                        <em>high water jacket temperatures
                                        </em></label>
                                    <span id='rx74'></span>
                                </div>


                                <div id='block-75' class="qo">
                                    <label for='ox75' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                            class="on" />
                                        <em>overheated pistons and cylinders
                                        </em></label>
                                    <span id='rx75'></span>
                                </div>


                                <div id='block-76' class="qo">
                                    <label for='ox76' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                            class="on" />
                                        <em>an increase in lube oil viscosity due to fuel dilution
                                        </em></label>
                                    <span id='rx76'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 20 -->
                            <div class="ques">
                                <p class="qn">20. Which of the conditions listed occurring in a diesel engine would
                                    cause carbon deposits to develop in the piston ring belt?
                                </p>
                                <hr>

                                <div id='block-77' class="qo">
                                    <label for='ox77' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox77' class="on" />
                                        <em>Faulty combustion </em></label>
                                    <span id='rx77'></span>
                                </div>


                                <div id='block-78' class="qo">
                                    <label for='ox78' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox78' class="on" />
                                        <em>Excessive ring temperatures </em></label>
                                    <span id='rx78'></span>
                                </div>


                                <div id='block-79' class="qo">
                                    <label for='ox79' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                            class="on" />
                                        <em>Excessive ring temperatures </em></label>
                                    <span id='rx79'></span>
                                </div>


                                <div id='block-80' class="qo">
                                    <label for='ox80' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                            class="on" />
                                        <em>All of the above.</em></label>
                                    <span id='rx80'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                </div>
                            </div>
                            <hr>



                        </article>
                    </div>

                    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/motor/asset/"; include($IPATH."motor_sidebar.html"); ?>
            </main>
            <nav aria-label="...">
                <ul class="pagination " style=" flex-wrap:wrap; ">
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/1.php">First Page</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/10.php">10</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/20.php">20</a></li>
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/27.php">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/26.php">26</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/27.php">27</a></li>
                    <li class="page-item active" aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/28.php">28</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/29.php">29</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/30.php">30</a></li>
                    <li class="page-item">
                        <a class="page-link" href="/marine_engineering/motor/29.php">Next</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/30.php">30</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/40.php">40</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/44.php">Last Page</a>
                    </li>
                </ul>
            </nav>
        </div>
    </section>
    <!-- main1 end  -->
    <!-- Footer -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
    <!-- Footer End -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
        crossorigin="anonymous"></script>
</body>

</html>