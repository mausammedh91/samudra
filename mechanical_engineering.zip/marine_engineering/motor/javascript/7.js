
//    Question 1
function displayAnswer1() {
    if (document.getElementById('ox1').checked) {
        document.getElementById('rx1').style.fontWeight = 'bold'
        document.getElementById('rx1').style.color = 'red'
        document.getElementById('rx1').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox2').checked) {
        document.getElementById('rx2').style.fontWeight = 'bold'
        document.getElementById('rx2').style.color = 'limegreen'
        document.getElementById('rx2').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox3').checked) {
        document.getElementById('rx3').style.fontWeight = 'bold'
        document.getElementById('rx3').style.color = 'red'
        document.getElementById('rx3').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox4').checked) {
        document.getElementById('rx4').style.fontWeight = 'bold'
        document.getElementById('rx4').style.color = 'red'
        document.getElementById('rx4').innerHTML = 'Incorrect!'
    }
}
//    Question 2
function displayAnswer2() {
    if (document.getElementById('ox5').checked) {
        document.getElementById('rx5').style.fontWeight = 'bold'
        document.getElementById('rx5').style.color = 'limegreen'
        document.getElementById('rx5').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox6').checked) {
        document.getElementById('rx6').style.fontWeight = 'bold'
        document.getElementById('rx6').style.color = 'red'
        document.getElementById('rx6').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox7').checked) {
        document.getElementById('rx7').style.fontWeight = 'bold'
        document.getElementById('rx7').style.color = 'red'
        document.getElementById('rx7').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox8').checked) {
        document.getElementById('rx8').style.fontWeight = 'bold'
        document.getElementById('rx8').style.color = 'red'
        document.getElementById('rx8').innerHTML = 'Incorrect!'
    }
}
//    Question 3
function displayAnswer3() {
    if (document.getElementById('ox9').checked) {
        document.getElementById('rx9').style.fontWeight = 'bold'
        document.getElementById('rx9').style.color = 'red'
        document.getElementById('rx9').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox10').checked) {
        document.getElementById('rx10').style.fontWeight = 'bold'
        document.getElementById('rx10').style.color = 'red'
        document.getElementById('rx10').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox11').checked) {
        document.getElementById('rx11').style.fontWeight = 'bold'
        document.getElementById('rx11').style.color = 'limegreen'
        document.getElementById('rx11').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox12').checked) {
        document.getElementById('rx12').style.fontWeight = 'bold'
        document.getElementById('rx12').style.color = 'red'
        document.getElementById('rx12').innerHTML = 'Incorrect!'
    }
}
//    Question 4
function displayAnswer4() {
    if (document.getElementById('ox13').checked) {
        document.getElementById('rx13').style.fontWeight = 'bold'
        document.getElementById('rx13').style.color = 'red'
        document.getElementById('rx13').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox14').checked) {
        document.getElementById('rx14').style.fontWeight = 'bold'
        document.getElementById('rx14').style.color = 'red'
        document.getElementById('rx14').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox15').checked) {
        document.getElementById('rx15').style.fontWeight = 'bold'
        document.getElementById('rx15').style.color = 'red'
        document.getElementById('rx15').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox16').checked) {
        document.getElementById('rx16').style.fontWeight = 'bold'
        document.getElementById('rx16').style.color = 'limegreen'
        document.getElementById('rx16').innerHTML = 'Correct!'
    }
}


//    Question 5
function displayAnswer5() {
    if (document.getElementById('ox17').checked) {
        document.getElementById('rx17').style.fontWeight = 'bold'
        document.getElementById('rx17').style.color = 'limegreen'
        document.getElementById('rx17').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox18').checked) {
        document.getElementById('rx18').style.fontWeight = 'bold'
        document.getElementById('rx18').style.color = 'red'
        document.getElementById('rx18').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox19').checked) {
        document.getElementById('rx19').style.fontWeight = 'bold'
        document.getElementById('rx19').style.color = 'red'
        document.getElementById('rx19').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox20').checked) {
        document.getElementById('rx20').style.fontWeight = 'bold'
        document.getElementById('rx20').style.color = 'red'
        document.getElementById('rx20').innerHTML = 'Incorrect!'
    }
}
//    Question 6
function displayAnswer6() {
    if (document.getElementById('ox21').checked) {
        document.getElementById('rx21').style.fontWeight = 'bold'
        document.getElementById('rx21').style.color = 'limegreen'
        document.getElementById('rx21').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox22').checked) {
        document.getElementById('rx22').style.fontWeight = 'bold'
        document.getElementById('rx22').style.color = 'red'
        document.getElementById('rx22').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox23').checked) {
        document.getElementById('rx23').style.fontWeight = 'bold'
        document.getElementById('rx23').style.color = 'red'
        document.getElementById('rx23').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox24').checked) {
        document.getElementById('rx24').style.fontWeight = 'bold'
        document.getElementById('rx24').style.color = 'red'
        document.getElementById('rx24').innerHTML = 'Incorrect!'
    }
}
//    Question 7
function displayAnswer7() {
    if (document.getElementById('ox25').checked) {
        document.getElementById('rx25').style.fontWeight = 'bold'
        document.getElementById('rx25').style.color = 'red'
        document.getElementById('rx25').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox26').checked) {
        document.getElementById('rx26').style.fontWeight = 'bold'
        document.getElementById('rx26').style.color = 'red'
        document.getElementById('rx26').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox27').checked) {
        document.getElementById('rx27').style.fontWeight = 'bold'
        document.getElementById('rx27').style.color = 'limegreen'
        document.getElementById('rx27').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox28').checked) {
        document.getElementById('rx28').style.fontWeight = 'bold'
        document.getElementById('rx28').style.color = 'red'
        document.getElementById('rx28').innerHTML = 'Incorrect!'
    }
}
//    Question 8
function displayAnswer8() {
    if (document.getElementById('ox29').checked) {
        document.getElementById('rx29').style.fontWeight = 'bold'
        document.getElementById('rx29').style.color = 'red'
        document.getElementById('rx29').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox30').checked) {
        document.getElementById('rx30').style.fontWeight = 'bold'
        document.getElementById('rx30').style.color = 'red'
        document.getElementById('rx30').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox31').checked) {
        document.getElementById('rx31').style.fontWeight = 'bold'
        document.getElementById('rx31').style.color = 'limegreen'
        document.getElementById('rx31').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox32').checked) {
        document.getElementById('rx32').style.fontWeight = 'bold'
        document.getElementById('rx32').style.color = 'red'
        document.getElementById('rx32').innerHTML = 'Incorrect!'
    }
}


//    Question 9
function displayAnswer9() {
    if (document.getElementById('ox33').checked) {
        document.getElementById('rx33').style.fontWeight = 'bold'
        document.getElementById('rx33').style.color = 'red'
        document.getElementById('rx33').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox34').checked) {
        document.getElementById('rx34').style.fontWeight = 'bold'
        document.getElementById('rx34').style.color = 'red'
        document.getElementById('rx34').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox35').checked) {
        document.getElementById('rx35').style.fontWeight = 'bold'
        document.getElementById('rx35').style.color = 'limegreen'
        document.getElementById('rx35').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox36').checked) {
        document.getElementById('rx36').style.fontWeight = 'bold'
        document.getElementById('rx36').style.color = 'red'
        document.getElementById('rx36').innerHTML = 'Incorrect!'
    }
}
//    Question 10
function displayAnswer10() {
    if (document.getElementById('ox37').checked) {
        document.getElementById('rx37').style.fontWeight = 'bold'
        document.getElementById('rx37').style.color = 'limegreen'
        document.getElementById('rx37').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox38').checked) {
        document.getElementById('rx38').style.fontWeight = 'bold'
        document.getElementById('rx38').style.color = 'red'
        document.getElementById('rx38').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox39').checked) {
        document.getElementById('rx39').style.fontWeight = 'bold'
        document.getElementById('rx39').style.color = 'red'
        document.getElementById('rx39').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox40').checked) {
        document.getElementById('rx40').style.fontWeight = 'bold'
        document.getElementById('rx40').style.color = 'red'
        document.getElementById('rx40').innerHTML = 'Incorrect!'
    }
}
//    Question 11
function displayAnswer11() {
    if (document.getElementById('ox41').checked) {
        document.getElementById('rx41').style.fontWeight = 'bold'
        document.getElementById('rx41').style.color = 'red'
        document.getElementById('rx41').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox42').checked) {
        document.getElementById('rx42').style.fontWeight = 'bold'
        document.getElementById('rx42').style.color = 'red'
        document.getElementById('rx42').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox43').checked) {
        document.getElementById('rx43').style.fontWeight = 'bold'
        document.getElementById('rx43').style.color = 'limegreen'
        document.getElementById('rx43').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox44').checked) {
        document.getElementById('rx44').style.fontWeight = 'bold'
        document.getElementById('rx44').style.color = 'red'
        document.getElementById('rx44').innerHTML = 'Incorrect!'
    }
}
//    Question 12
function displayAnswer12() {
    if (document.getElementById('ox45').checked) {
        document.getElementById('rx45').style.fontWeight = 'bold'
        document.getElementById('rx45').style.color = 'red'
        document.getElementById('rx45').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox46').checked) {
        document.getElementById('rx46').style.fontWeight = 'bold'
        document.getElementById('rx46').style.color = 'red'
        document.getElementById('rx46').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox47').checked) {
        document.getElementById('rx47').style.fontWeight = 'bold'
        document.getElementById('rx47').style.color = 'limegreen'
        document.getElementById('rx47').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox48').checked) {
        document.getElementById('rx48').style.fontWeight = 'bold'
        document.getElementById('rx48').style.color = 'red'
        document.getElementById('rx48').innerHTML = 'Incorrect!'
    }
}


//    Question 13
function displayAnswer13() {
    if (document.getElementById('ox49').checked) {
        document.getElementById('rx49').style.fontWeight = 'bold'
        document.getElementById('rx49').style.color = 'red'
        document.getElementById('rx49').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox50').checked) {
        document.getElementById('rx50').style.fontWeight = 'bold'
        document.getElementById('rx50').style.color = 'red'
        document.getElementById('rx50').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox51').checked) {
        document.getElementById('rx51').style.fontWeight = 'bold'
        document.getElementById('rx51').style.color = 'red'
        document.getElementById('rx51').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox52').checked) {
        document.getElementById('rx52').style.fontWeight = 'bold'
        document.getElementById('rx52').style.color = 'limegreen'
        document.getElementById('rx52').innerHTML = 'Correct!'
    }
}
//    Question 14
function displayAnswer14() {
    if (document.getElementById('ox53').checked) {
        document.getElementById('rx53').style.fontWeight = 'bold'
        document.getElementById('rx53').style.color = 'red'
        document.getElementById('rx53').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox54').checked) {
        document.getElementById('rx54').style.fontWeight = 'bold'
        document.getElementById('rx54').style.color = 'red'
        document.getElementById('rx54').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox55').checked) {
        document.getElementById('rx55').style.fontWeight = 'bold'
        document.getElementById('rx55').style.color = 'red'
        document.getElementById('rx55').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox56').checked) {
        document.getElementById('rx56').style.fontWeight = 'bold'
        document.getElementById('rx56').style.color = 'limegreen'
        document.getElementById('rx56').innerHTML = 'Correct!'
    }
}
//    Question 15
function displayAnswer15() {
    if (document.getElementById('ox57').checked) {
        document.getElementById('rx57').style.fontWeight = 'bold'
        document.getElementById('rx57').style.color = 'red'
        document.getElementById('rx57').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox58').checked) {
        document.getElementById('rx58').style.fontWeight = 'bold'
        document.getElementById('rx58').style.color = 'limegreen'
        document.getElementById('rx58').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox59').checked) {
        document.getElementById('rx59').style.fontWeight = 'bold'
        document.getElementById('rx59').style.color = 'red'
        document.getElementById('rx59').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox60').checked) {
        document.getElementById('rx60').style.fontWeight = 'bold'
        document.getElementById('rx60').style.color = 'red'
        document.getElementById('rx60').innerHTML = 'Incorrect!'
    }
}
//    Question 16
function displayAnswer16() {
    if (document.getElementById('ox61').checked) {
        document.getElementById('rx61').style.fontWeight = 'bold'
        document.getElementById('rx61').style.color = 'limegreen'
        document.getElementById('rx61').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox62').checked) {
        document.getElementById('rx62').style.fontWeight = 'bold'
        document.getElementById('rx62').style.color = 'red'
        document.getElementById('rx62').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox63').checked) {
        document.getElementById('rx63').style.fontWeight = 'bold'
        document.getElementById('rx63').style.color = 'red'
        document.getElementById('rx63').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox64').checked) {
        document.getElementById('rx64').style.fontWeight = 'bold'
        document.getElementById('rx64').style.color = 'red'
        document.getElementById('rx64').innerHTML = 'Incorrect!'
    }
}


//    Question 17
function displayAnswer17() {
    if (document.getElementById('ox65').checked) {
        document.getElementById('rx65').style.fontWeight = 'bold'
        document.getElementById('rx65').style.color = 'red'
        document.getElementById('rx65').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox66').checked) {
        document.getElementById('rx66').style.fontWeight = 'bold'
        document.getElementById('rx66').style.color = 'limegreen'
        document.getElementById('rx66').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox67').checked) {
        document.getElementById('rx67').style.fontWeight = 'bold'
        document.getElementById('rx67').style.color = 'red'
        document.getElementById('rx67').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox68').checked) {
        document.getElementById('rx68').style.fontWeight = 'bold'
        document.getElementById('rx68').style.color = 'red'
        document.getElementById('rx68').innerHTML = 'Incorrect!'
    }
}
//    Question 18
function displayAnswer18() {
    if (document.getElementById('ox69').checked) {
        document.getElementById('rx69').style.fontWeight = 'bold'
        document.getElementById('rx69').style.color = 'limegreen'
        document.getElementById('rx69').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox70').checked) {
        document.getElementById('rx70').style.fontWeight = 'bold'
        document.getElementById('rx70').style.color = 'red'
        document.getElementById('rx70').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox71').checked) {
        document.getElementById('rx71').style.fontWeight = 'bold'
        document.getElementById('rx71').style.color = 'red'
        document.getElementById('rx71').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox72').checked) {
        document.getElementById('rx72').style.fontWeight = 'bold'
        document.getElementById('rx72').style.color = 'red'
        document.getElementById('rx72').innerHTML = 'Incorrect!'
    }
}
//    Question 19
function displayAnswer19() {
    if (document.getElementById('ox73').checked) {
        document.getElementById('rx73').style.fontWeight = 'bold'
        document.getElementById('rx73').style.color = 'red'
        document.getElementById('rx73').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox74').checked) {
        document.getElementById('rx74').style.fontWeight = 'bold'
        document.getElementById('rx74').style.color = 'red'
        document.getElementById('rx74').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox75').checked) {
        document.getElementById('rx75').style.fontWeight = 'bold'
        document.getElementById('rx75').style.color = 'limegreen'
        document.getElementById('rx75').innerHTML = 'Correct!'
    }
    if (document.getElementById('ox76').checked) {
        document.getElementById('rx76').style.fontWeight = 'bold'
        document.getElementById('rx76').style.color = 'red'
        document.getElementById('rx76').innerHTML = 'Incorrect!'
    }
}
//    Question 20
function displayAnswer20() {
    if (document.getElementById('ox77').checked) {
        document.getElementById('rx77').style.fontWeight = 'bold'
        document.getElementById('rx77').style.color = 'red'
        document.getElementById('rx77').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox78').checked) {
        document.getElementById('rx78').style.fontWeight = 'bold'
        document.getElementById('rx78').style.color = 'red'
        document.getElementById('rx78').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox79').checked) {
        document.getElementById('rx79').style.fontWeight = 'bold'
        document.getElementById('rx79').style.color = 'red'
        document.getElementById('rx79').innerHTML = 'Incorrect!'
    }
    if (document.getElementById('ox80').checked) {
        document.getElementById('rx80').style.fontWeight = 'bold'
        document.getElementById('rx80').style.color = 'limegreen'
        document.getElementById('rx80').innerHTML = 'Correct!'
    }
}
