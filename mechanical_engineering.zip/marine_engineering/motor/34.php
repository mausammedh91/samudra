<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/CSS/style1.css">
  <link rel="stylesheet" href="/CSS/style2.css">
  <link rel="stylesheet" href="/CSS/mcq.css">
  <script src="/marine_engineering/motor/javascript/34.js"></script>

  <title>Motor: Maintenance, Design, Components, Operation (Set34)</title>
  <meta name="description"
    content="Cracking of a diesel piston crown can result from..., It is easier to replace a dry cylinder liner than a wet one because..., To facilitate early ring seating of newly installed piston rings..." />
  <meta name="keywords"
    content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, motor, main, ratio, services, submit, ring, cylinder, wear, liner, diesel, piston, clearance, engine, rings, surface, fuel, bearing, excessive, compression, system, oil, increased, engineering, marine, heat, chrome, content, crankshaft, increase, control, wrench, systems, result, wall, water, decrease, center, face, worn, part, side, gap, stroke, generally, groove, stainless, steel, smooth, gauge, blow-by, corrosion, crank, readings, crown, transfer, easier, due, newly, taper, insufficient, jam, expand, top, upper, ash, amount, valve, shallow, measure, micrometer, condition, good, burning, high, sulphur, pumps, greatest, bottom, bearings, auxiliary, connecting, rod, decreased, deflection, practice, lubrication, crankcase, cracked, head, caused, instrumentation, air, ship, page, of the, diesel engine, the cylinder, of a, a diesel, cylinder liner, in the, liner wear, when the, opposite the, marine engineering, to the, in a, engine will, the rings, part of, at the, stainless steel, surface of, main bearing, bearing clearance, the crankshaft, wear is, piston ring, compression ratio, services marine, engineering motor, piston crown, the piston, heat transfer, all of, the above, above submit, easier to, due to, to a, piston rings, can be, the ring, ring face, back clearance, will cause, cause the, worn part, cylinder when, rings expand, on the, the top, ash content, which of, the following, chrome surface, smooth surface, of stainless, the main, measure the, outside micrometer, blow-by is, fuel oil, with a, a high, high sulphur, sulphur content, content in, result in, engine to, wear between, between piston, ring and, and groove, between the, the crank, crank is, is on, the oil, oil control, control ring, the compression, connecting rod, rod and, clearance submit, for all, all four, four readings, the crankcase, a cracked, cracked cylinder, cylinder head, caused by, by excessive, excessive ring, ring back, of the cylinder, a diesel engine, of a diesel, in a diesel, diesel engine will, part of the, liner wear is, services marine engineering, marine engineering motor, all of the, of the above, the above submit, due to a, will cause the, worn part of, the cylinder when, cylinder when the, when the rings, the rings expand, which of the, of the following, of stainless steel, the main bearing, with a high, a high sulphur, high sulphur content, sulphur content in, content in a, cylinder liner wear, wear between piston, between piston ring, piston ring and, ring and groove, when the crank, the crank is, crank is on, opposite the oil, the oil control, oil control ring, connecting rod and, for all four, all four readings, a cracked cylinder, caused by excessive, by excessive ring, in a diesel engine, a diesel engine will, services marine engineering motor, all of the above, of the above submit, worn part of the, part of the cylinder, of the cylinder when, the cylinder when the, cylinder when the rings, when the rings expand, which of the following, with a high sulphur, a high sulphur content, high sulphur content in, sulphur content in a, content in a diesel, wear between piston ring, between piston ring and, piston ring and groove, when the crank is, the crank is on, opposite the oil control, the oil control ring, for all four readings, of a diesel engine, caused by excessive ring, in a diesel engine will, all of the above submit, worn part of the cylinder, part of the cylinder when, of the cylinder when the, the cylinder when the rings, cylinder when the rings expand, with a high sulphur content, a high sulphur content in, high sulphur content in a, sulphur content in a diesel, content in a diesel engine, wear between piston ring and, between piston ring and groove, when the crank is on, opposite the oil control ring" />
  <style>
    .dfg {
      text-decoration: none;
      color: brown;
      font-family: sans-serif;
    }
  </style>
</head>

<body>

  <!-- Navigation start -->
  <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
  <!-- navigation end -->
  <!-- path sart -->
  <div class="container1">
    <div class="col-md-12"></div>
    <ul id="breadcrumbs-course">
      <li><a href="/Index.php">Home</a></li>
      <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
      <li><a href="/marine_engineering/motor/34.php" style="cursor: default;">Motor: <span style="color:#7f0804;"
            id="lecid">MCQ</span></a></li>
    </ul>
  </div>
  <!-- path end -->
  <!-- main1 start  -->
  <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
    style="background-color: whitesmoke;">
    <div class="row py-lg-8">
      <main class="container bg-light">
        <div class="row">
          <div class="col-md-8">

            <article class="blog-post">
              <h1 class="blog-post-title">Motor: Maintenance, Design, Components, Operation (Set34)</h1>
              <hr />
              <p></p>
              <h4>Multiple Choice Questions</h4>
              <hr />
              <!-- Question 1 -->
              <div class="ques">
                <p class="qn">
                  1. Cracking of a diesel piston crown can result from ____________.
                </p>
                <hr />

                <div id="block-1" class="qo">
                  <label for="ox1" class="ll">
                    <input type="radio" name="option" id="ox1" class="on" />
                    <em>excessive piston to liner clearance</em></label>
                  <span id="rx1"></span>
                </div>

                <div id="block-2" class="qo">
                  <label for="ox2" class="ll">
                    <input type="radio" name="option" id="ox2" class="on" />
                    <em>faulty nozzle spray</em></label>
                  <span id="rx2"></span>
                </div>

                <div id="block-3" class="qo">
                  <label for="ox3" class="ll">
                    <input type="radio" name="option" id="ox3" class="on" />
                    <em>the underside of the piston crown being excessively dirty, lowering
                      the rate of heat transfer</em></label>
                  <span id="rx3"></span>
                </div>

                <div id="block-4" class="qo">
                  <label for="ox4" class="ll">
                    <input type="radio" name="option" id="ox4" class="on" />
                    <em>all of the above</em></label>
                  <span id="rx4"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer1()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 2 -->
              <div class="ques">
                <p class="qn">
                  2. It is easier to replace a dry cylinder liner than a wet one because
                  ____________.
                </p>
                <hr />

                <div id="block-5" class="qo">
                  <label for="ox5" class="ll">
                    <input type="radio" name="option" id="ox5" class="on" />
                    <em>of the thin wall thickness </em></label>
                  <span id="rx5"></span>
                </div>

                <div id="block-6" class="qo">
                  <label for="ox6" class="ll">
                    <input type="radio" name="option" id="ox6" class="on" />
                    <em>honing makes it easier to maintain the desired oil film</em></label>
                  <span id="rx6"></span>
                </div>

                <div id="block-7" class="qo">
                  <label for="ox7" class="ll">
                    <input type="radio" name="option" id="ox7" class="on" />
                    <em>water seals are not required</em></label>
                  <span id="rx7"></span>
                </div>

                <div id="block-8" class="qo">
                  <label for="ox8" class="ll">
                    <input type="radio" name="option" id="ox8" class="on" />
                    <em>it fits more loosely due to a decrease in heat transfer through the
                      composite wall
                    </em></label>
                  <span id="rx8"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer2()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 3 -->
              <div class="ques">
                <p class="qn">
                  3. To facilitate early ring seating of newly installed piston rings, while
                  still providing extended ring wear, __________.
                </p>
                <hr />

                <div id="block-9" class="qo">
                  <label for="ox9" class="ll">
                    <input type="radio" name="option" id="ox9" class="on" />
                    <em>inlaid rings can be utilized in which the chrome center of the ring
                      face slightly protrudes beyond the cast iron edges</em></label>
                  <span id="rx9"></span>
                </div>

                <div id="block-10" class="qo">
                  <label for="ox10" class="ll">
                    <input type="radio" name="option" id="ox10" class="on" />
                    <em>the cylinder surface is honed to the smoothest surface attainable</em></label>
                  <span id="rx10"></span>
                </div>

                <div id="block-11" class="qo">
                  <label for="ox11" class="ll">
                    <input type="radio" name="option" id="ox11" class="on" />
                    <em>a taper faced ring can be used</em></label>
                  <span id="rx11"></span>
                </div>

                <div id="block-12" class="qo">
                  <label for="ox12" class="ll">
                    <input type="radio" name="option" id="ox12" class="on" />
                    <em>rings with increased back clearance are provided</em></label>
                  <span id="rx12"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer3()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 4 -->
              <div class="ques">
                <p class="qn">
                  4. Insufficient end clearance on newly fitted piston rings in a diesel
                  engine will cause the rings to ______________.
                </p>
                <hr />

                <div id="block-13" class="qo">
                  <label for="ox13" class="ll">
                    <input type="radio" name="option" id="ox13" class="on" />
                    <em>jam in the least worn part of the cylinder when the rings expand
                    </em></label>
                  <span id="rx13"></span>
                </div>

                <div id="block-14" class="qo">
                  <label for="ox14" class="ll">
                    <input type="radio" name="option" id="ox14" class="on" />
                    <em>break in the most worn part of the cylinder when the rings expand</em></label>
                  <span id="rx14"></span>
                </div>

                <div id="block-15" class="qo">
                  <label for="ox15" class="ll">
                    <input type="radio" name="option" id="ox15" class="on" />
                    <em>wear eccentrically on the side opposite the end gap</em></label>
                  <span id="rx15"></span>
                </div>

                <div id="block-16" class="qo">
                  <label for="ox16" class="ll">
                    <input type="radio" name="option" id="ox16" class="on" />
                    <em>overheat and jam at the top center on the combustion stroke</em></label>
                  <span id="rx16"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer4()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 5 -->
              <div class="ques">
                <p class="qn">
                  5. Heavy fuel oils generally have an upper average ash content of 0.1% by
                  weight. Which of the following conditions could be expected if the ash
                  content increases above this amount?
                </p>
                <hr />

                <div id="block-17" class="qo">
                  <label for="ox17" class="ll">
                    <input type="radio" name="option" id="ox17" class="on" />
                    <em>Glazing of the cylinder liners</em></label>
                  <span id="rx17"></span>
                </div>

                <div id="block-18" class="qo">
                  <label for="ox18" class="ll">
                    <input type="radio" name="option" id="ox18" class="on" />
                    <em>Increased valve wear</em></label>
                  <span id="rx18"></span>
                </div>

                <div id="block-19" class="qo">
                  <label for="ox19" class="ll">
                    <input type="radio" name="option" id="ox19" class="on" />
                    <em>Excessive oil pumping</em></label>
                  <span id="rx19"></span>
                </div>

                <div id="block-20" class="qo">
                  <label for="ox20" class="ll">
                    <input type="radio" name="option" id="ox20" class="on" />
                    <em>Increased fuel consumption</em></label>
                  <span id="rx20"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer5()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 6 -->
              <div class="ques">
                <p class="qn">
                  6. The face surface appearance of a shallow groove, stainless steel,
                  chrome plated compression ring should exhibit through its operating life a
                  ____________.
                </p>
                <hr />

                <div id="block-21" class="qo">
                  <label for="ox21" class="ll">
                    <input type="radio" name="option" id="ox21" class="on" />
                    <em>smooth, shallow groved, chrome surface</em></label>
                  <span id="rx21"></span>
                </div>

                <div id="block-22" class="qo">
                  <label for="ox22" class="ll">
                    <input type="radio" name="option" id="ox22" class="on" />
                    <em> smooth surface of stainless steel </em></label>
                  <span id="rx22"></span>
                </div>

                <div id="block-23" class="qo">
                  <label for="ox23" class="ll">
                    <input type="radio" name="option" id="ox23" class="on" />
                    <em>smooth surface displaying areas of stainless steel and chrome
                    </em></label>
                  <span id="rx23"></span>
                </div>

                <div id="block-24" class="qo">
                  <label for="ox24" class="ll">
                    <input type="radio" name="option" id="ox24" class="on" />
                    <em>surface of gradually deepening grooves </em></label>
                  <span id="rx24"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer6()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 7 -->
              <div class="ques">
                <p class="qn">
                  7. To determine the main bearing clearance of a propulsion diesel engine,
                  you should measure the main bearing shell using a ball anvil outside
                  micrometer and measure the crankshaft journal using a/an _____________.
                </p>
                <hr />

                <div id="block-25" class="qo">
                  <label for="ox25" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox25" class="on" />
                    <em>telescoping gauge</em></label>
                  <span id="rx25"></span>
                </div>

                <div id="block-26" class="qo">
                  <label for="ox26" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox26" class="on" />
                    <em>ring "snap" gauge </em></label>
                  <span id="rx26"></span>
                </div>

                <div id="block-27" class="qo">
                  <label for="ox27" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox27" class="on" />
                    <em>inside vernier caliper</em></label>
                  <span id="rx27"></span>
                </div>

                <div id="block-28" class="qo">
                  <label for="ox28" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox28" class="on" />
                    <em>outside micrometer </em></label>
                  <span id="rx28"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer7()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 8 -->
              <div class="ques">
                <p class="qn">
                  8. Visual inspection of chrome-plated piston compression rings reveals a
                  black ring face at the position of the cylinder liner ports. This
                  condition indicates a ring which ________________.
                </p>
                <hr />

                <div id="block-29" class="qo">
                  <label for="ox29" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox29" class="on" />
                    <em>has a crown-face</em></label>
                  <span id="rx29"></span>
                </div>

                <div id="block-30" class="qo">
                  <label for="ox30" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox30" class="on" />
                    <em>exceeds wear limits through normal wear</em></label>
                  <span id="rx30"></span>
                </div>

                <div id="block-31" class="qo">
                  <label for="ox31" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox31" class="on" />
                    <em>has excessive blow-by </em></label>
                  <span id="rx31"></span>
                </div>

                <div id="block-32" class="qo">
                  <label for="ox32" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox32" class="on" />
                    <em>is in good condition </em></label>
                  <span id="rx32"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer8()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 9 -->
              <div class="ques">
                <p class="qn">
                  9. The consistent burning of fuel oil with a high sulphur content in a
                  diesel engine will result in _____________.
                </p>
                <hr />

                <div id="block-33" class="qo">
                  <label for="ox33" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox33" class="on" />
                    <em>clogged fuel injection pumps</em></label>
                  <span id="rx33"></span>
                </div>

                <div id="block-34" class="qo">
                  <label for="ox34" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox34" class="on" />
                    <em>increased cylinder liner wear</em></label>
                  <span id="rx34"></span>
                </div>

                <div id="block-35" class="qo">
                  <label for="ox35" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox35" class="on" />
                    <em>intake valve stem corrosion</em></label>
                  <span id="rx35"></span>
                </div>

                <div id="block-36" class="qo">
                  <label for="ox36" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox36" class="on" />
                    <em>varnish deposit on pistons </em></label>
                  <span id="rx36"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer9()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 10 -->
              <div class="ques">
                <p class="qn">
                  10. Burning fuel with a high sulphur content in a diesel engine will
                  _____________.
                </p>
                <hr />

                <div id="block-37" class="qo">
                  <label for="ox37" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox37" class="on" />
                    <em>increase thermal efficiency</em></label>
                  <span id="rx37"></span>
                </div>

                <div id="block-38" class="qo">
                  <label for="ox38" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox38" class="on" />
                    <em>cause clogging of the fuel system</em></label>
                  <span id="rx38"></span>
                </div>

                <div id="block-39" class="qo">
                  <label for="ox39" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox39" class="on" />
                    <em>increase the ability of the engine to start in cold weather</em></label>
                  <span id="rx39"></span>
                </div>

                <div id="block-40" class="qo">
                  <label for="ox40" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox40" class="on" />
                    <em>produce corrosion in the cylinder and exhaust system at low loads</em></label>
                  <span id="rx40"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer10()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />

              <!-- Question 11 -->
              <div class="ques">
                <p class="qn">
                  11. Which of the following statements concerning cylinder liner wear is
                  true?
                </p>
                <hr />

                <div id="block-41" class="qo">
                  <label for="ox41" class="ll">
                    <input type="radio" name="option" id="ox41" class="on" />
                    <em>Liner wear is normally greatest in the middle of the cylinder.
                    </em></label>
                  <span id="rx41"></span>
                </div>

                <div id="block-42" class="qo">
                  <label for="ox42" class="ll">
                    <input type="radio" name="option" id="ox42" class="on" />
                    <em>Excessive liner wear causes wear between piston ring and groove.</em></label>
                  <span id="rx42"></span>
                </div>

                <div id="block-43" class="qo">
                  <label for="ox43" class="ll">
                    <input type="radio" name="option" id="ox43" class="on" />
                    <em>Excessive, but uniform liner wear will not cause wear between piston
                      ring and groove.</em></label>
                  <span id="rx43"></span>
                </div>

                <div id="block-44" class="qo">
                  <label for="ox44" class="ll">
                    <input type="radio" name="option" id="ox44" class="on" />
                    <em>Liner wear is distributed equally between the upper and lower
                      portions of the cylinder.
                    </em></label>
                  <span id="rx44"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer11()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 12 -->
              <div class="ques">
                <p class="qn">
                  12. Generally, where should you expect to find the greatest amount of wear
                  on a cylinder liner?
                </p>
                <hr />

                <div id="block-45" class="qo">
                  <label for="ox45" class="ll">
                    <input type="radio" name="option" id="ox45" class="on" />
                    <em>Adjacent to the piston skirt when the crank is on TDC.</em></label>
                  <span id="rx45"></span>
                </div>

                <div id="block-46" class="qo">
                  <label for="ox46" class="ll">
                    <input type="radio" name="option" id="ox46" class="on" />
                    <em>Along the lower part of the liner wall opposite the oil control
                      ring.</em></label>
                  <span id="rx46"></span>
                </div>

                <div id="block-47" class="qo">
                  <label for="ox47" class="ll">
                    <input type="radio" name="option" id="ox47" class="on" />
                    <em>Opposite the top ring shortly after piston travel has ended the
                      compression stroke.</em></label>
                  <span id="rx47"></span>
                </div>

                <div id="block-48" class="qo">
                  <label for="ox48" class="ll">
                    <input type="radio" name="option" id="ox48" class="on" />
                    <em>Opposite the oil control ring when the crank is on bottom dead
                      center.</em></label>
                  <span id="rx48"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer12()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 13 -->
              <div class="ques">
                <p class="qn">
                  13. Worn main bearings will cause the compression ratio of an auxiliary
                  diesel engine to _____________.
                </p>
                <hr />

                <div id="block-49" class="qo">
                  <label for="ox49" class="ll">
                    <input type="radio" name="option" id="ox49" class="on" />
                    <em>increase</em></label>
                  <span id="rx49"></span>
                </div>

                <div id="block-50" class="qo">
                  <label for="ox50" class="ll">
                    <input type="radio" name="option" id="ox50" class="on" />
                    <em>decrease</em></label>
                  <span id="rx50"></span>
                </div>

                <div id="block-51" class="qo">
                  <label for="ox51" class="ll">
                    <input type="radio" name="option" id="ox51" class="on" />
                    <em>remain the same</em></label>
                  <span id="rx51"></span>
                </div>

                <div id="block-52" class="qo">
                  <label for="ox52" class="ll">
                    <input type="radio" name="option" id="ox52" class="on" />
                    <em>increase on compression; decrease on expansion</em></label>
                  <span id="rx52"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer13()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />

              <!-- Question 14 -->
              <div class="ques">
                <p class="qn">
                  14. The insertion of shims between the foot of a marine type connecting
                  rod and a bearing box would result in __________.
                </p>
                <hr />

                <div id="block-53" class="qo">
                  <label for="ox53" class="ll">
                    <input type="radio" name="option" id="ox53" class="on" />
                    <em>increased compression ratio</em></label>
                  <span id="rx53"></span>
                </div>

                <div id="block-54" class="qo">
                  <label for="ox54" class="ll">
                    <input type="radio" name="option" id="ox54" class="on" />
                    <em>decreased compression ratio </em></label>
                  <span id="rx54"></span>
                </div>

                <div id="block-55" class="qo">
                  <label for="ox55" class="ll">
                    <input type="radio" name="option" id="ox55" class="on" />
                    <em>increased bearing clearance </em></label>
                  <span id="rx55"></span>
                </div>

                <div id="block-56" class="qo">
                  <label for="ox56" class="ll">
                    <input type="radio" name="option" id="ox56" class="on" />
                    <em>decreased bearing clearance</em></label>
                  <span id="rx56"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer14()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />

              <!-- Question 15 -->
              <div class="ques">
                <p class="qn">
                  15. Diesel engine crankshaft deflection readings are generally taken at
                  four crank positions. Good engineering practice requires the deflection
                  gauge or indicator to be ___________.
                </p>
                <hr />

                <div id="block-57" class="qo">
                  <label for="ox57" class="ll">
                    <input type="radio" name="option" id="ox57" class="on" />
                    <em>placed as near the crankpin axis as possible</em></label>
                  <span id="rx57"></span>
                </div>

                <div id="block-58" class="qo">
                  <label for="ox58" class="ll">
                    <input type="radio" name="option" id="ox58" class="on" />
                    <em>removed each time the crankshaft is repositioned</em></label>
                  <span id="rx58"></span>
                </div>

                <div id="block-59" class="qo">
                  <label for="ox59" class="ll">
                    <input type="radio" name="option" id="ox59" class="on" />
                    <em>left in place for all four readings</em></label>
                  <span id="rx59"></span>
                </div>

                <div id="block-60" class="qo">
                  <label for="ox60" class="ll">
                    <input type="radio" name="option" id="ox60" class="on" />
                    <em>reset to zero for all four readings</em></label>
                  <span id="rx60"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer15()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />

              <!-- Question 16 -->
              <div class="ques">
                <p class="qn">
                  16. An acceptable method of measuring for the correct rotational force
                  applied to the connecting rod and main bearing bolts, is to use a
                  _____________.
                </p>
                <hr />

                <div id="block-61" class="qo">
                  <label for="ox61" class="ll">
                    <input type="radio" name="option" id="ox61" class="on" />
                    <em>torque wrench</em></label>
                  <span id="rx61"></span>
                </div>

                <div id="block-62" class="qo">
                  <label for="ox62" class="ll">
                    <input type="radio" name="option" id="ox62" class="on" />
                    <em>monkey wrench </em></label>
                  <span id="rx62"></span>
                </div>

                <div id="block-63" class="qo">
                  <label for="ox63" class="ll">
                    <input type="radio" name="option" id="ox63" class="on" />
                    <em>pipe wrench </em></label>
                  <span id="rx63"></span>
                </div>

                <div id="block-64" class="qo">
                  <label for="ox64" class="ll">
                    <input type="radio" name="option" id="ox64" class="on" />
                    <em>slugging wrench</em></label>
                  <span id="rx64"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer16()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 17 -->
              <div class="ques">
                <p class="qn">
                  17. Small cracks in the crankshaft bearing surface of a diesel engine are
                  an indication of _____________.
                </p>
                <hr />

                <div id="block-65" class="qo">
                  <label for="ox65" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox65" class="on" />
                    <em>corrosion fretting</em></label>
                  <span id="rx65"></span>
                </div>

                <div id="block-66" class="qo">
                  <label for="ox66" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox66" class="on" />
                    <em>insufficient lubrication</em></label>
                  <span id="rx66"></span>
                </div>

                <div id="block-67" class="qo">
                  <label for="ox67" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox67" class="on" />
                    <em>abnormal wear</em></label>
                  <span id="rx67"></span>
                </div>

                <div id="block-68" class="qo">
                  <label for="ox68" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox68" class="on" />
                    <em>fatigue failure</em></label>
                  <span id="rx68"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer17()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 18 -->
              <div class="ques">
                <p class="qn">
                  18. If water is found in the crankcase of a diesel engine, the cause may
                  be due to _____________.
                </p>
                <hr />

                <div id="block-69" class="qo">
                  <label for="ox69" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox69" class="on" />
                    <em>a cracked cylinder head</em></label>
                  <span id="rx69"></span>
                </div>

                <div id="block-70" class="qo">
                  <label for="ox70" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox70" class="on" />
                    <em>a leaky cylinder head gasket</em></label>
                  <span id="rx70"></span>
                </div>

                <div id="block-71" class="qo">
                  <label for="ox71" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox71" class="on" />
                    <em>a cracked cylinder liner</em></label>
                  <span id="rx71"></span>
                </div>

                <div id="block-72" class="qo">
                  <label for="ox72" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox72" class="on" />
                    <em>all of the above</em></label>
                  <span id="rx72"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer18()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 19 -->
              <div class="ques">
                <p class="qn">
                  19. Diesel engine piston ring blow-by is usually caused by excessive ring
                  clearance at the ring ____________.
                </p>
                <hr />

                <div id="block-73" class="qo">
                  <label for="ox73" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox73" class="on" />
                    <em>back</em></label>
                  <span id="rx73"></span>
                </div>

                <div id="block-74" class="qo">
                  <label for="ox74" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox74" class="on" />
                    <em>side</em></label>
                  <span id="rx74"></span>
                </div>

                <div id="block-75" class="qo">
                  <label for="ox75" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox75" class="on" />
                    <em>gap</em></label>
                  <span id="rx75"></span>
                </div>

                <div id="block-76" class="qo">
                  <label for="ox76" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox76" class="on" />
                    <em>bottom</em></label>
                  <span id="rx76"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer19()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
              <!-- Question 20 -->
              <div class="ques">
                <p class="qn">
                  20. Diesel engine "blow-by" into the crankcase is caused by excessive ring
                  ____________.
                </p>
                <hr />

                <div id="block-77" class="qo">
                  <label for="ox77" class="ll">
                    <input type="radio" name="option" value="fluid dynamics" id="ox77" class="on" />
                    <em>back clearance</em></label>
                  <span id="rx77"></span>
                </div>

                <div id="block-78" class="qo">
                  <label for="ox78" class="ll">
                    <input type="radio" name="option" value="fluid kinetics" id="ox78" class="on" />
                    <em>side clearance</em></label>
                  <span id="rx78"></span>
                </div>

                <div id="block-79" class="qo">
                  <label for="ox79" class="ll">
                    <input type="radio" name="option" value="fluid kinematics" id="ox79" class="on" />
                    <em>gap clearance</em></label>
                  <span id="rx79"></span>
                </div>

                <div id="block-80" class="qo">
                  <label for="ox80" class="ll">
                    <input type="radio" name="option" value="fluid mechanics" id="ox80" class="on" />
                    <em>taper clearance</em></label>
                  <span id="rx80"></span>
                </div>
                <hr />
                <div>
                  <button type="button" onclick="displayAnswer20()" class="sbt">
                    Submit
                  </button>
                </div>
              </div>
              <hr />
            </article>

          </div>

          <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/motor/asset/"; include($IPATH."motor_sidebar.html"); ?>
      </main>
      <nav aria-label="...">
        <ul class="pagination " style=" flex-wrap:wrap; ">
          <li class="page-item " aria-current="page">
            <a class="page-link" href="/marine_engineering/motor/1.php">First Page</a>
          </li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/10.php">10</a></li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/20.php">20</a></li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/30.php">30</a></li>
          <li class="page-item " aria-current="page">
            <a class="page-link" href="/marine_engineering/motor/33.php">Previous</a>
          </li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/32.php">32</a></li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/33.php">33</a></li>
          <li class="page-item active" aria-current="page">
            <a class="page-link" href="/marine_engineering/motor/34.php">34</a>
          </li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/35.php">35</a></li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/36.php">36</a></li>
          <li class="page-item">
            <a class="page-link" href="/marine_engineering/motor/35.php">Next</a>
          </li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/40.php">40</a></li>
          <li class="page-item"><a class="page-link" href="/marine_engineering/motor/44.php">Last Page</a></li>
        </ul>
      </nav>
    </div>
  </section>
  <!-- main1 end  -->
  <!-- Footer -->
  <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
  <!-- Footer End -->
  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
    crossorigin="anonymous"></script>
</body>

</html>