<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/motor/javascript/43.js"></script>

    <title>Motor: Maintenance, Design, Components, Operation (Set43)</title>
    <meta name="description"
        content="Hydraulic starters are installed on many lifeboat diesel engines instead..., If a diesel engine fails to start, one of the likely causes is..., A diesel engine may fail to start when being cranked, due to..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, motor, main, operation, services, starting, air, submit, engine, diesel, system, hydraulic, valve, systems, pressure, high, oil, pump, fuel, flywheel, marine, start, compression, gear, cam, direct, valves, engineering, engines, accumulator, drive, electric, reversing, propulsion, cylinders, pilot, two-strokecycle, starters, speed, lube, fail, force, overspeed, pinion, starter, current, large, exhaust, mechanical, higher, fails, due, viscosity, clutch, bendix, rotating, operated, disengage, bearing, mechanism, prior, rotation, admission, aan, opening, check, individual, operates, intake, listed, types, timing, motors, centrifugal, tank, ring, auxiliary, equipped, instrumentation, control, heat, ship, page, diesel engine, of the, starting motor, the engine, a diesel, the flywheel, the starting, which of, starting air, in a, and the, marine engineering, diesel engines, air start, lube oil, pressure submit, a hydraulic, hydraulic starting, in the, electric starting, the pinion, direct reversing, main propulsion, propulsion diesel, of starting, to the, starting system, air starting, starting valves, services marine, engineering motor, hydraulic starters, starters are, starting systems, the system, does not, if a, fails to, to start, pressure high, high lube, pump pressure, fuel oil, fail to, due to, the diesel, the hydraulic, a bendix, bendix drive, starting cam, engine electric, under a, the following, the starter, starter motor, motor will, for a, is used, used to, prior to, admission of, the cylinders, an air, a two-strokecycle, check valve, valve individual, valve submit, two-strokecycle diesel, because the, intake and, and exhaust, types of, by the, used in, system is, the pump, pump and, with a, flywheel ring, ring gear, equipped with, exhaust valve, a diesel engine, which of the, main propulsion diesel, air starting valves, services marine engineering, marine engineering motor, hydraulic starters are, high lube oil, a hydraulic starting, the diesel engine, in the hydraulic, a bendix drive, of the starting, the starting cam, diesel engine electric, engine electric starting, electric starting motor, of the following, the starter motor, starter motor will, propulsion diesel engine, admission of starting, of starting air, check valve individual, two-strokecycle diesel engine, intake and exhaust, used in a, in a hydraulic, hydraulic starting system, starting system is, pump and the, the flywheel ring, flywheel ring gear, services marine engineering motor, diesel engine electric starting, which of the following, the starter motor will, main propulsion diesel engine, admission of starting air, used in a hydraulic, hydraulic starting system is, the flywheel ring gear" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12"></div>
        <ul id="breadcrumbs-course">
            <li><a href="/Index.php">Home</a></li>
            <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
            <li><a href="/marine_engineering/motor/43.php" style="cursor: default;">Motor: <span style="color:#7f0804;"
                        id="lecid">MCQ</span></a></li>
        </ul>
    </div>
    <!-- path end -->
    <!-- main1 start  -->
    <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
        style="background-color: whitesmoke;">
        <div class="row py-lg-8">
            <main class="container bg-light">
                <div class="row">
                    <div class="col-md-8">

                        <article class="blog-post">
                            <h1 class="blog-post-title">Motor: Maintenance, Design, Components, Operation (Set43)</h1>
                            <hr>
                            <p>
                            <h4>Multiple Choice Questions</h4>
                            <hr>
                            <!-- Question 1 -->
                            <div class="ques">
                                <p class="qn">1. Hydraulic starters are installed on many lifeboat diesel engines
                                    instead of comparable air start systems, because ____________.
                                </p>
                                <hr>

                                <div id='block-1' class="qo">
                                    <label for='ox1' class="ll">
                                        <input type='radio' name='option' id='ox1' class="on" />
                                        <em>hydraulic starters are the least expensive of all starting systems
                                        </em></label>
                                    <span id='rx1'></span>
                                </div>


                                <div id='block-2' class="qo">
                                    <label for='ox2' class="ll">
                                        <input type='radio' name='option' id='ox2' class="on" />
                                        <em>the system does not require high pressure piping
                                        </em></label>
                                    <span id='rx2'></span>
                                </div>


                                <div id='block-3' class="qo">
                                    <label for='ox3' class="ll">
                                        <input type='radio' name='option' id='ox3' class="on" />
                                        <em>hydraulic systems turn diesel engines at higher rates of speed than
                                            air starters</em></label>
                                    <span id='rx3'></span>
                                </div>


                                <div id='block-4' class="qo">
                                    <label for='ox4' class="ll">
                                        <input type='radio' name='option' id='ox4' class="on" />
                                        <em>the system can be manually recharged</em></label>
                                    <span id='rx4'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 2 -->
                            <div class="ques">
                                <p class="qn">2. If a diesel engine fails to start, one of the likely causes is
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-5' class="qo">
                                    <label for='ox5' class="ll">
                                        <input type='radio' name='option' id='ox5' class="on" />
                                        <em>low compression temperature
                                        </em></label>
                                    <span id='rx5'></span>
                                </div>


                                <div id='block-6' class="qo">
                                    <label for='ox6' class="ll">
                                        <input type='radio' name='option' id='ox6' class="on" />
                                        <em>low ambient air pressure
                                        </em></label>
                                    <span id='rx6'></span>
                                </div>


                                <div id='block-7' class="qo">
                                    <label for='ox7' class="ll">
                                        <input type='radio' name='option' id='ox7' class="on" />
                                        <em>high lube oil pump pressure</em></label>
                                    <span id='rx7'></span>
                                </div>


                                <div id='block-8' class="qo">
                                    <label for='ox8' class="ll">
                                        <input type='radio' name='option' id='ox8' class="on" />
                                        <em>high fuel oil booster pump pressure
                                        </em></label>
                                    <span id='rx8'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 3 -->
                            <div class="ques">
                                <p class="qn">3. A diesel engine may fail to start when being cranked, due to
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-9' class="qo">
                                    <label for='ox9' class="ll">
                                        <input type='radio' name='option' id='ox9' class="on" />
                                        <em>high cetane number</em></label>
                                    <span id='rx9'></span>
                                </div>


                                <div id='block-10' class="qo">
                                    <label for='ox10' class="ll">
                                        <input type='radio' name='option' id='ox10' class="on" />
                                        <em>insufficient compression
                                        </em></label>
                                    <span id='rx10'></span>
                                </div>


                                <div id='block-11' class="qo">
                                    <label for='ox11' class="ll">
                                        <input type='radio' name='option' id='ox11' class="on" />
                                        <em>low lube oil viscosity
                                        </em></label>
                                    <span id='rx11'></span>
                                </div>


                                <div id='block-12' class="qo">
                                    <label for='ox12' class="ll">
                                        <input type='radio' name='option' id='ox12' class="on" />
                                        <em>high lube oil pressure</em></label>
                                    <span id='rx12'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 4 -->
                            <div class="ques">
                                <p class="qn">4. If a hydraulic starting motor turns, but the diesel engine does not,
                                    the most likely cause is ____________.
                                </p>
                                <hr>

                                <div id='block-13' class="qo">
                                    <label for='ox13' class="ll">
                                        <input type='radio' name='option' id='ox13' class="on" />
                                        <em>excessive viscosity in the hydraulic fluid
                                        </em></label>
                                    <span id='rx13'></span>
                                </div>


                                <div id='block-14' class="qo">
                                    <label for='ox14' class="ll">
                                        <input type='radio' name='option' id='ox14' class="on" />
                                        <em>a malfunctioning overrunning clutch
                                        </em></label>
                                    <span id='rx14'></span>
                                </div>


                                <div id='block-15' class="qo">
                                    <label for='ox15' class="ll">
                                        <input type='radio' name='option' id='ox15' class="on" />
                                        <em>loss of accumulator precharge
                                        </em></label>
                                    <span id='rx15'></span>
                                </div>


                                <div id='block-16' class="qo">
                                    <label for='ox16' class="ll">
                                        <input type='radio' name='option' id='ox16' class="on" />
                                        <em>air in the hydraulic system</em></label>
                                    <span id='rx16'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 5 -->
                            <div class="ques">
                                <p class="qn">5. A bendix drive starting motor disengages the drive gear from the
                                    flywheel by ______________.
                                </p>
                                <hr>

                                <div id='block-17' class="qo">
                                    <label for='ox17' class="ll">
                                        <input type='radio' name='option' id='ox17' class="on" />
                                        <em>spring force
                                        </em></label>
                                    <span id='rx17'></span>
                                </div>


                                <div id='block-18' class="qo">
                                    <label for='ox18' class="ll">
                                        <input type='radio' name='option' id='ox18' class="on" />
                                        <em>rotating of the starting cam</em></label>
                                    <span id='rx18'></span>
                                </div>


                                <div id='block-19' class="qo">
                                    <label for='ox19' class="ll">
                                        <input type='radio' name='option' id='ox19' class="on" />
                                        <em>the high rotating speed of the flywheel</em></label>
                                    <span id='rx19'></span>
                                </div>


                                <div id='block-20' class="qo">
                                    <label for='ox20' class="ll">
                                        <input type='radio' name='option' id='ox20' class="on" />
                                        <em>applying accumulator pressure</em></label>
                                    <span id='rx20'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 6 -->
                            <div class="ques">
                                <p class="qn">6. A diesel engine electric starting motor is operated under a no-load
                                    condition. Continuing to operate the motor unloaded will
                                    _______________.
                                </p>
                                <hr>

                                <div id='block-21' class="qo">
                                    <label for='ox21' class="ll">
                                        <input type='radio' name='option' id='ox21' class="on" />
                                        <em>disengage the throw out bearing
                                        </em></label>
                                    <span id='rx21'></span>
                                </div>


                                <div id='block-22' class="qo">
                                    <label for='ox22' class="ll">
                                        <input type='radio' name='option' id='ox22' class="on" />
                                        <em>overspeed and cause serious damage
                                        </em></label>
                                    <span id='rx22'></span>
                                </div>


                                <div id='block-23' class="qo">
                                    <label for='ox23' class="ll">
                                        <input type='radio' name='option' id='ox23' class="on" />
                                        <em>fail to develop normal speed </em></label>
                                    <span id='rx23'></span>
                                </div>


                                <div id='block-24' class="qo">
                                    <label for='ox24' class="ll">
                                        <input type='radio' name='option' id='ox24' class="on" />
                                        <em>cause the pinion to fail
                                        </em></label>
                                    <span id='rx24'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 7 -->
                            <div class="ques">
                                <p class="qn">7. If the diesel engine starter-drive mechanism fails to disengage after
                                    the engine starts, which of the following situations will occur?
                                </p>
                                <hr>

                                <div id='block-25' class="qo">
                                    <label for='ox25' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox25' class="on" />
                                        <em>The engine will stall.</em></label>
                                    <span id='rx25'></span>
                                </div>


                                <div id='block-26' class="qo">
                                    <label for='ox26' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox26' class="on" />
                                        <em>The starter motor will have reverse current.
                                        </em></label>
                                    <span id='rx26'></span>
                                </div>


                                <div id='block-27' class="qo">
                                    <label for='ox27' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                            class="on" />
                                        <em>The engine flywheel will be burred.</em></label>
                                    <span id='rx27'></span>
                                </div>


                                <div id='block-28' class="qo">
                                    <label for='ox28' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                            class="on" />
                                        <em>the starter motor will overspeed
                                        </em></label>
                                    <span id='rx28'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 8 -->
                            <div class="ques">
                                <p class="qn">8. During maneuvering operations for a direct reversing large, lowspeed,
                                    main propulsion diesel engine, which of the following
                                    actions is used to stop the shaft from turning prior to reversing the
                                    engine rotation?
                                </p>
                                <hr>

                                <div id='block-29' class="qo">
                                    <label for='ox29' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox29' class="on" />
                                        <em>Flywheel inertia
                                        </em></label>
                                    <span id='rx29'></span>
                                </div>


                                <div id='block-30' class="qo">
                                    <label for='ox30' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox30' class="on" />
                                        <em>Admission of starting air
                                        </em></label>
                                    <span id='rx30'></span>
                                </div>


                                <div id='block-31' class="qo">
                                    <label for='ox31' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                            class="on" />
                                        <em>The way of the vessel
                                        </em></label>
                                    <span id='rx31'></span>
                                </div>


                                <div id='block-32' class="qo">
                                    <label for='ox32' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                            class="on" />
                                        <em>securing of fuel to the cylinders </em></label>
                                    <span id='rx32'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 9 -->
                            <div class="ques">
                                <p class="qn">9. The pilot valves in an air pilot starting system for a
                                    two-stroke/cycle,
                                    direct-reversing, main propulsion diesel engine are operated by
                                    either a ported distributor disc or a/an _____________.
                                </p>
                                <hr>

                                <div id='block-33' class="qo">
                                    <label for='ox33' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox33' class="on" />
                                        <em>regulator valve
                                        </em></label>
                                    <span id='rx33'></span>
                                </div>


                                <div id='block-34' class="qo">
                                    <label for='ox34' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox34' class="on" />
                                        <em>quick opening main air valve</em></label>
                                    <span id='rx34'></span>
                                </div>


                                <div id='block-35' class="qo">
                                    <label for='ox35' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                            class="on" />
                                        <em>pilot air start check valve
                                        </em></label>
                                    <span id='rx35'></span>
                                </div>


                                <div id='block-36' class="qo">
                                    <label for='ox36' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                            class="on" />
                                        <em>individual cam for each pilot valve
                                        </em></label>
                                    <span id='rx36'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 10 -->
                            <div class="ques">
                                <p class="qn">10. A two-stroke/cycle diesel engine requires less starting air than a
                                    four-stroke/cycle diesel engine, of equal displacement, because
                                    the two-stroke/cycle diesel engine _____________.
                                </p>
                                <hr>

                                <div id='block-37' class="qo">
                                    <label for='ox37' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox37' class="on" />
                                        <em>has little or no internal friction</em></label>
                                    <span id='rx37'></span>
                                </div>


                                <div id='block-38' class="qo">
                                    <label for='ox38' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox38' class="on" />
                                        <em>has a lower effective compression ratio
                                        </em></label>
                                    <span id='rx38'></span>
                                </div>


                                <div id='block-39' class="qo">
                                    <label for='ox39' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                            class="on" />
                                        <em>operates with scavenge air under a positive pressure</em></label>
                                    <span id='rx39'></span>
                                </div>


                                <div id='block-40' class="qo">
                                    <label for='ox40' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                            class="on" />
                                        <em>operates without energy absorbing intake and exhaust strokes</em></label>
                                    <span id='rx40'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 11 -->
                            <div class="ques">
                                <p class="qn">11. Which of the listed types of starting systems is often used on large,
                                    low-speed, direct reversing, main propulsion diesel engines?
                                </p>
                                <hr>

                                <div id='block-41' class="qo">
                                    <label for='ox41' class="ll">
                                        <input type='radio' name='option' id='ox41' class="on" />
                                        <em>Electric</em></label>
                                    <span id='rx41'></span>
                                </div>


                                <div id='block-42' class="qo">
                                    <label for='ox42' class="ll">
                                        <input type='radio' name='option' id='ox42' class="on" />
                                        <em>Hydraulic</em></label>
                                    <span id='rx42'></span>
                                </div>


                                <div id='block-43' class="qo">
                                    <label for='ox43' class="ll">
                                        <input type='radio' name='option' id='ox43' class="on" />
                                        <em>Air</em></label>
                                    <span id='rx43'></span>
                                </div>


                                <div id='block-44' class="qo">
                                    <label for='ox44' class="ll">
                                        <input type='radio' name='option' id='ox44' class="on" />
                                        <em>all of the above</em></label>
                                    <span id='rx44'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 12 -->
                            <div class="ques">
                                <p class="qn">12. The timing of diesel engine air starting valves is controlled by
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-45' class="qo">
                                    <label for='ox45' class="ll">
                                        <input type='radio' name='option' id='ox45' class="on" />
                                        <em>the air start valve timing gears and rods</em></label>
                                    <span id='rx45'></span>
                                </div>


                                <div id='block-46' class="qo">
                                    <label for='ox46' class="ll">
                                        <input type='radio' name='option' id='ox46' class="on" />
                                        <em>a cylinder check valve</em></label>
                                    <span id='rx46'></span>
                                </div>


                                <div id='block-47' class="qo">
                                    <label for='ox47' class="ll">
                                        <input type='radio' name='option' id='ox47' class="on" />
                                        <em>individual cams and valve gear</em></label>
                                    <span id='rx47'></span>
                                </div>


                                <div id='block-48' class="qo">
                                    <label for='ox48' class="ll">
                                        <input type='radio' name='option' id='ox48' class="on" />
                                        <em>an air manifold poppet valve</em></label>
                                    <span id='rx48'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 13 -->
                            <div class="ques">
                                <p class="qn">13. Which of the types of motors listed is used in a hydraulic starter?
                                </p>
                                <hr>

                                <div id='block-49' class="qo">
                                    <label for='ox49' class="ll">
                                        <input type='radio' name='option' id='ox49' class="on" />
                                        <em>Piston
                                        </em></label>
                                    <span id='rx49'></span>
                                </div>


                                <div id='block-50' class="qo">
                                    <label for='ox50' class="ll">
                                        <input type='radio' name='option' id='ox50' class="on" />
                                        <em>Gear</em></label>
                                    <span id='rx50'></span>
                                </div>


                                <div id='block-51' class="qo">
                                    <label for='ox51' class="ll">
                                        <input type='radio' name='option' id='ox51' class="on" />
                                        <em>Turbine</em></label>
                                    <span id='rx51'></span>
                                </div>


                                <div id='block-52' class="qo">
                                    <label for='ox52' class="ll">
                                        <input type='radio' name='option' id='ox52' class="on" />
                                        <em>centrifugal</em></label>
                                    <span id='rx52'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 14 -->
                            <div class="ques">
                                <p class="qn">14. An accumulator used in a hydraulic starting system is generally
                                    located between the _____________.
                                </p>
                                <hr>

                                <div id='block-53' class="qo">
                                    <label for='ox53' class="ll">
                                        <input type='radio' name='option' id='ox53' class="on" />
                                        <em>pump and the compressor</em></label>
                                    <span id='rx53'></span>
                                </div>


                                <div id='block-54' class="qo">
                                    <label for='ox54' class="ll">
                                        <input type='radio' name='option' id='ox54' class="on" />
                                        <em>storage tank and the pump
                                        </em></label>
                                    <span id='rx54'></span>
                                </div>


                                <div id='block-55' class="qo">
                                    <label for='ox55' class="ll">
                                        <input type='radio' name='option' id='ox55' class="on" />
                                        <em>starting motor and the reserve tank
                                        </em></label>
                                    <span id='rx55'></span>
                                </div>


                                <div id='block-56' class="qo">
                                    <label for='ox56' class="ll">
                                        <input type='radio' name='option' id='ox56' class="on" />
                                        <em>pump and the starting motor</em></label>
                                    <span id='rx56'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 15 -->
                            <div class="ques">
                                <p class="qn">15. The device used to store a charged pressure for an hydraulic
                                    starting system is called the _____________.
                                </p>
                                <hr>

                                <div id='block-57' class="qo">
                                    <label for='ox57' class="ll">
                                        <input type='radio' name='option' id='ox57' class="on" />
                                        <em>reservoir
                                        </em></label>
                                    <span id='rx57'></span>
                                </div>


                                <div id='block-58' class="qo">
                                    <label for='ox58' class="ll">
                                        <input type='radio' name='option' id='ox58' class="on" />
                                        <em>hand pump
                                        </em></label>
                                    <span id='rx58'></span>
                                </div>


                                <div id='block-59' class="qo">
                                    <label for='ox59' class="ll">
                                        <input type='radio' name='option' id='ox59' class="on" />
                                        <em>accelerator</em></label>
                                    <span id='rx59'></span>
                                </div>


                                <div id='block-60' class="qo">
                                    <label for='ox60' class="ll">
                                        <input type='radio' name='option' id='ox60' class="on" />
                                        <em>accumulator</em></label>
                                    <span id='rx60'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 16 -->
                            <div class="ques">
                                <p class="qn">16. The pinion of an electric starting motor used with a diesel engine
                                    engages the flywheel ring gear by a/an ____________.
                                </p>
                                <hr>

                                <div id='block-61' class="qo">
                                    <label for='ox61' class="ll">
                                        <input type='radio' name='option' id='ox61' class="on" />
                                        <em>automatic follow-up
                                        </em></label>
                                    <span id='rx61'></span>
                                </div>


                                <div id='block-62' class="qo">
                                    <label for='ox62' class="ll">
                                        <input type='radio' name='option' id='ox62' class="on" />
                                        <em>muff coupling and release
                                        </em></label>
                                    <span id='rx62'></span>
                                </div>


                                <div id='block-63' class="qo">
                                    <label for='ox63' class="ll">
                                        <input type='radio' name='option' id='ox63' class="on" />
                                        <em>friction-type clutch
                                        </em></label>
                                    <span id='rx63'></span>
                                </div>


                                <div id='block-64' class="qo">
                                    <label for='ox64' class="ll">
                                        <input type='radio' name='option' id='ox64' class="on" />
                                        <em>bendrix drive or similar mechanism</em></label>
                                    <span id='rx64'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 17 -->
                            <div class="ques">
                                <p class="qn">17. Auxiliary diesel engine electric starting motors use ____________.
                                </p>
                                <hr>

                                <div id='block-65' class="qo">
                                    <label for='ox65' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox65' class="on" />
                                        <em>alternating current
                                        </em></label>
                                    <span id='rx65'></span>
                                </div>


                                <div id='block-66' class="qo">
                                    <label for='ox66' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox66' class="on" />
                                        <em>400 cycle per second motor-generators
                                        </em></label>
                                    <span id='rx66'></span>
                                </div>


                                <div id='block-67' class="qo">
                                    <label for='ox67' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                            class="on" />
                                        <em>low amp, high voltage AC
                                        </em></label>
                                    <span id='rx67'></span>
                                </div>


                                <div id='block-68' class="qo">
                                    <label for='ox68' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                            class="on" />
                                        <em>direct current
                                        </em></label>
                                    <span id='rx68'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 18 -->
                            <div class="ques">
                                <p class="qn">18. In a starting motor equipped with a Bendix drive, the pinion moves
                                    and meshes with the flywheel ring gear due to __________.
                                    <hr>

                                <div id='block-69' class="qo">
                                    <label for='ox69' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox69' class="on" />
                                        <em>the mechanical linkage
                                        </em></label>
                                    <span id='rx69'></span>
                                </div>


                                <div id='block-70' class="qo">
                                    <label for='ox70' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox70' class="on" />
                                        <em>the threaded sleeve's rotation
                                        </em></label>
                                    <span id='rx70'></span>
                                </div>


                                <div id='block-71' class="qo">
                                    <label for='ox71' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                            class="on" />
                                        <em>centrifugal force
                                        </em></label>
                                    <span id='rx71'></span>
                                </div>


                                <div id='block-72' class="qo">
                                    <label for='ox72' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                            class="on" />
                                        <em>electromotive force</em></label>
                                    <span id='rx72'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 19 -->
                            <div class="ques">
                                <p class="qn">19. A large two-stroke/cycle direct reversing diesel engine is to be
                                    reversed. Prior to the admission of starting air you must
                                    ____________.
                                </p>
                                <hr>

                                <div id='block-73' class="qo">
                                    <label for='ox73' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox73' class="on" />
                                        <em>line up the engine for restarting with light diesel oil</em></label>
                                    <span id='rx73'></span>
                                </div>


                                <div id='block-74' class="qo">
                                    <label for='ox74' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox74' class="on" />
                                        <em>reposition the fuel injection cam
                                        </em></label>
                                    <span id='rx74'></span>
                                </div>


                                <div id='block-75' class="qo">
                                    <label for='ox75' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                            class="on" />
                                        <em>change the intake and exhaust valve cam positions
                                        </em></label>
                                    <span id='rx75'></span>
                                </div>


                                <div id='block-76' class="qo">
                                    <label for='ox76' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                            class="on" />
                                        <em>place the starting cam in the intermediate position</em></label>
                                    <span id='rx76'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 20 -->
                            <div class="ques">
                                <p class="qn">20. In a medium-speed marine propulsion engine equipped with direct
                                    air starting valves, the cylinders without air starting valves fire first
                                    because the ____________.
                                </p>
                                <hr>

                                <div id='block-77' class="qo">
                                    <label for='ox77' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox77' class="on" />
                                        <em>operation is under higher compression
                                        </em></label>
                                    <span id='rx77'></span>
                                </div>


                                <div id='block-78' class="qo">
                                    <label for='ox78' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox78' class="on" />
                                        <em>fuel is admitted only to these cylinders during cranking
                                        </em></label>
                                    <span id='rx78'></span>
                                </div>


                                <div id='block-79' class="qo">
                                    <label for='ox79' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                            class="on" />
                                        <em>compression is released during starting by opening the exhaust
                                            valve
                                        </em></label>
                                    <span id='rx79'></span>
                                </div>


                                <div id='block-80' class="qo">
                                    <label for='ox80' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                            class="on" />
                                        <em>cylinders are not chilled by the expansion of the starting air
                                        </em></label>
                                    <span id='rx80'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                </div>
                            </div>
                            <hr>



                        </article>
                    </div>

                    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/motor/asset/"; include($IPATH."motor_sidebar.html"); ?>
            </main>
            <nav aria-label="...">
                <ul class="pagination " style=" flex-wrap:wrap; ">
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/1.php">First Page</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/10.php">10</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/20.php">20</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/30.php">30</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/40.php">40</a></li>
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/42.php">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/41.php">41</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/42.php">42</a></li>
                    <li class="page-item active" aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/43.php">43</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/44.php">44</a></li>
                    <!-- <li class="page-item"><a class="page-link" href="/marine_engineering/motor/43.php">43</a></li> -->
                    <li class="page-item">
                        <a class="page-link" href="/marine_engineering/motor/44.html">Next</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/44.php">Last Page</a>
                    </li>
                </ul>
            </nav>
        </div>
    </section>
    <!-- main1 end  -->
    <!-- Footer -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
    <!-- Footer End -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
        crossorigin="anonymous"></script>
</body>

</html>