<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/motor/javascript/40.js"></script>

    <title>Motor: Maintenance, Design, Components, Operation (Set40)</title>
    <meta name="description"
        content="Crank lead can be adjusted to change which of the listed operating..., When a hydraulic valve lifter is on the base circle of the cam..., In a diesel engine, blow-by is generally the result of..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, motor, main, operation, services, engine, starting, submit, air, diesel, valve, fuel, system, piston, pressure, engines, speed, type, exhaust, oil, cylinder, events, rings, high, two-strokecycle, valves, engineering, marine, conditions, spring, control, compression, excessive, consecutive, starts, systems, combustion, result, lube, cold, four-strokecycle, gap, head, disc, supply, manifold, increasing, water, listed, longer, scavenging, temperatures, clearance, worn, seats, skirt, content, power, load, fails, fire, indicator, ports, injection, line, cooling, turbocharger, compressor, blades, required, large, crown, build, metal, spraying, bearing, gear, fitted, inlet, reversing, lubrication, mains, construction, sufficient, heating, temperature, compressed, auxiliary, distributor, instrumentation, heat, ship, page, of the, diesel engine, in a, starting air, the starting, a diesel, to be, in the, engine the, which of, the piston, to the, a two-strokecycle, two-strokecycle engine, is to, consecutive starts, engine speed, marine engineering, can be, on the, the valve, lube oil, the fuel, diesel engines, between the, of a, increasing the, services marine, engineering motor, the listed, events exhaust, exhaust events, scavenging events, when a, by the, oil pressure, worn valve, valve seats, conditions can, a piston, piston skirt, content fuel, engine can, piston rings, engine submit, but fails, fails to, to fire, be excessive, compression pressure, air in, the cylinder, system the, the exhaust, the turbocharger, turbocharger compressor, compressor blades, the following, four-strokecycle diesel, the rings, the end, be made, gap is, is required, a large, piston crown, cylinder head, build up, up the, by metal, metal spraying, at the, reversing engines, used to, air mains, starting valves, heating the, the engine, engine is, air system, compressed air, air starting, air valve, a diesel engine, the starting air, which of the, in a diesel, in a two-strokecycle, a two-strokecycle engine, is to be, services marine engineering, marine engineering motor, of the listed, events exhaust events, diesel engine can, but fails to, fails to fire, air in the, in the fuel, the turbocharger compressor, turbocharger compressor blades, of the following, gap is required, diesel engine the, the piston crown, build up the, by metal spraying, of the starting, starting air mains, heating the engine, diesel engine is, in the starting, starting air valve, in a diesel engine, in a two-strokecycle engine, services marine engineering motor, which of the listed, a diesel engine can, but fails to fire, air in the fuel, the turbocharger compressor blades, which of the following, the starting air valve, in a diesel engine can" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12"></div>
        <ul id="breadcrumbs-course">
            <li><a href="/Index.php">Home</a></li>
            <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
            <li><a href="/marine_engineering/motor/40.php" style="cursor: default;">Motor: <span style="color:#7f0804;"
                        id="lecid">MCQ</span></a></li>
        </ul>
    </div>
    <!-- path end -->
    <!-- main1 start  -->
    <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
        style="background-color: whitesmoke;">
        <div class="row py-lg-8">
            <main class="container bg-light">
                <div class="row">
                    <div class="col-md-8">

                        <article class="blog-post">
                            <h1 class="blog-post-title">Motor: Maintenance, Design, Components, Operation (Set40)</h1>
                            <hr>
                            <p>
                            <h4>Multiple Choice Questions</h4>
                            <hr>
                            <!-- Question 1 -->
                            <div class="ques">
                                <p class="qn">1. Crank lead can be adjusted to change which of the listed operating
                                    conditions?
                                </p>
                                <hr>

                                <div id='block-1' class="qo">
                                    <label for='ox1' class="ll">
                                        <input type='radio' name='option' id='ox1' class="on" />
                                        <em>Longer combustion events. </em></label>
                                    <span id='rx1'></span>
                                </div>


                                <div id='block-2' class="qo">
                                    <label for='ox2' class="ll">
                                        <input type='radio' name='option' id='ox2' class="on" />
                                        <em>Exhaust events starting before scavenging events.</em></label>
                                    <span id='rx2'></span>
                                </div>


                                <div id='block-3' class="qo">
                                    <label for='ox3' class="ll">
                                        <input type='radio' name='option' id='ox3' class="on" />
                                        <em>Exhaust events lasting longer than scavenging events.</em></label>
                                    <span id='rx3'></span>
                                </div>


                                <div id='block-4' class="qo">
                                    <label for='ox4' class="ll">
                                        <input type='radio' name='option' id='ox4' class="on" />
                                        <em>Higher combustion temperatures</em></label>
                                    <span id='rx4'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 2 -->
                            <div class="ques">
                                <p class="qn">2. When a hydraulic valve lifter is on the base circle of the cam, "zero"
                                    tappet clearance is maintained by the ______________.
                                </p>
                                <hr>

                                <div id='block-5' class="qo">
                                    <label for='ox5' class="ll">
                                        <input type='radio' name='option' id='ox5' class="on" />
                                        <em>valve spring
                                        </em></label>
                                    <span id='rx5'></span>
                                </div>


                                <div id='block-6' class="qo">
                                    <label for='ox6' class="ll">
                                        <input type='radio' name='option' id='ox6' class="on" />
                                        <em>plunger spring
                                        </em></label>
                                    <span id='rx6'></span>
                                </div>


                                <div id='block-7' class="qo">
                                    <label for='ox7' class="ll">
                                        <input type='radio' name='option' id='ox7' class="on" />
                                        <em>oil pressure</em></label>
                                    <span id='rx7'></span>
                                </div>


                                <div id='block-8' class="qo">
                                    <label for='ox8' class="ll">
                                        <input type='radio' name='option' id='ox8' class="on" />
                                        <em>rocker arm
                                        </em></label>
                                    <span id='rx8'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 3 -->
                            <div class="ques">
                                <p class="qn">3. In a diesel engine, blow-by is generally the result of worn
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-9' class="qo">
                                    <label for='ox9' class="ll">
                                        <input type='radio' name='option' id='ox9' class="on" />
                                        <em>valve guides</em></label>
                                    <span id='rx9'></span>
                                </div>


                                <div id='block-10' class="qo">
                                    <label for='ox10' class="ll">
                                        <input type='radio' name='option' id='ox10' class="on" />
                                        <em>oil control rings</em></label>
                                    <span id='rx10'></span>
                                </div>


                                <div id='block-11' class="qo">
                                    <label for='ox11' class="ll">
                                        <input type='radio' name='option' id='ox11' class="on" />
                                        <em>valve seats</em></label>
                                    <span id='rx11'></span>
                                </div>


                                <div id='block-12' class="qo">
                                    <label for='ox12' class="ll">
                                        <input type='radio' name='option' id='ox12' class="on" />
                                        <em>compression ringst</em></label>
                                    <span id='rx12'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 4 -->
                            <div class="ques">
                                <p class="qn">4. Which of the listed conditions can cause lacquer to be deposited
                                    on a piston skirt?
                                </p>
                                <hr>

                                <div id='block-13' class="qo">
                                    <label for='ox13' class="ll">
                                        <input type='radio' name='option' id='ox13' class="on" />
                                        <em>High sulphur content fuel
                                        </em></label>
                                    <span id='rx13'></span>
                                </div>


                                <div id='block-14' class="qo">
                                    <label for='ox14' class="ll">
                                        <input type='radio' name='option' id='ox14' class="on" />
                                        <em>High lube oil temperatures
                                        </em></label>
                                    <span id='rx14'></span>
                                </div>


                                <div id='block-15' class="qo">
                                    <label for='ox15' class="ll">
                                        <input type='radio' name='option' id='ox15' class="on" />
                                        <em>High vanadium content fuel
                                        </em></label>
                                    <span id='rx15'></span>
                                </div>


                                <div id='block-16' class="qo">
                                    <label for='ox16' class="ll">
                                        <input type='radio' name='option' id='ox16' class="on" />
                                        <em>Excessive piston slap
                                        </em></label>
                                    <span id='rx16'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 5 -->
                            <div class="ques">
                                <p class="qn">5. Scuffed cylinder liner wearing surfaces in a diesel engine can result
                                    from _____________.
                                </p>
                                <hr>

                                <div id='block-17' class="qo">
                                    <label for='ox17' class="ll">
                                        <input type='radio' name='option' id='ox17' class="on" />
                                        <em>chromium plating piston rings</em></label>
                                    <span id='rx17'></span>
                                </div>


                                <div id='block-18' class="qo">
                                    <label for='ox18' class="ll">
                                        <input type='radio' name='option' id='ox18' class="on" />
                                        <em>knurling the piston skirt</em></label>
                                    <span id='rx18'></span>
                                </div>


                                <div id='block-19' class="qo">
                                    <label for='ox19' class="ll">
                                        <input type='radio' name='option' id='ox19' class="on" />
                                        <em>extended maximum power operation</em></label>
                                    <span id='rx19'></span>
                                </div>


                                <div id='block-20' class="qo">
                                    <label for='ox20' class="ll">
                                        <input type='radio' name='option' id='ox20' class="on" />
                                        <em>applying load to a cold diesel engine</em></label>
                                    <span id='rx20'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 6 -->
                            <div class="ques">
                                <p class="qn">6. If a diesel engine driving a generator turns over freely but fails to
                                    fire
                                    properly, the cause could be ____________.
                                </p>
                                <hr>

                                <div id='block-21' class="qo">
                                    <label for='ox21' class="ll">
                                        <input type='radio' name='option' id='ox21' class="on" />
                                        <em>excessive compression pressure
                                        </em></label>
                                    <span id='rx21'></span>
                                </div>


                                <div id='block-22' class="qo">
                                    <label for='ox22' class="ll">
                                        <input type='radio' name='option' id='ox22' class="on" />
                                        <em>air in the fuel lines
                                        </em></label>
                                    <span id='rx22'></span>
                                </div>


                                <div id='block-23' class="qo">
                                    <label for='ox23' class="ll">
                                        <input type='radio' name='option' id='ox23' class="on" />
                                        <em>high fuel pressure</em></label>
                                    <span id='rx23'></span>
                                </div>


                                <div id='block-24' class="qo">
                                    <label for='ox24' class="ll">
                                        <input type='radio' name='option' id='ox24' class="on" />
                                        <em>excessive load
                                        </em></label>
                                    <span id='rx24'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 7 -->
                            <div class="ques">
                                <p class="qn">7. When a diesel engine compression pressure is checked, the
                                    indicator is connected to the _____________.
                                </p>
                                <hr>

                                <div id='block-25' class="qo">
                                    <label for='ox25' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox25' class="on" />
                                        <em>cylinder exhaust ports</em></label>
                                    <span id='rx25'></span>
                                </div>


                                <div id='block-26' class="qo">
                                    <label for='ox26' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox26' class="on" />
                                        <em>injection line</em></label>
                                    <span id='rx26'></span>
                                </div>


                                <div id='block-27' class="qo">
                                    <label for='ox27' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                            class="on" />
                                        <em>cylinder indicator cock</em></label>
                                    <span id='rx27'></span>
                                </div>


                                <div id='block-28' class="qo">
                                    <label for='ox28' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                            class="on" />
                                        <em>banjo oiler line</em></label>
                                    <span id='rx28'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 8 -->
                            <div class="ques">
                                <p class="qn">8. In a diesel engine exhaust system, the cooling of the exhaust gases
                                    below their dew point, will result in ____________.
                                </p>
                                <hr>

                                <div id='block-29' class="qo">
                                    <label for='ox29' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox29' class="on" />
                                        <em>increased engine back pressure
                                        </em></label>
                                    <span id='rx29'></span>
                                </div>


                                <div id='block-30' class="qo">
                                    <label for='ox30' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox30' class="on" />
                                        <em>sulphuric acid corrosion
                                        </em></label>
                                    <span id='rx30'></span>
                                </div>


                                <div id='block-31' class="qo">
                                    <label for='ox31' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                            class="on" />
                                        <em>surface pitting of the turbocharger compressor blades
                                        </em></label>
                                    <span id='rx31'></span>
                                </div>


                                <div id='block-32' class="qo">
                                    <label for='ox32' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                            class="on" />
                                        <em>moisture impingement on the turbocharger compressor blades</em></label>
                                    <span id='rx32'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 9 -->
                            <div class="ques">
                                <p class="qn">9. Which of the following statements is true regarding the installation
                                    of piston rings on two-stroke/cycle, diesel engines as compared to
                                    four-stroke/cycle, diesel engines?
                                </p>
                                <hr>

                                <div id='block-33' class="qo">
                                    <label for='ox33' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox33' class="on" />
                                        <em>In a two-stroke/cycle engine, the rings run hotter, requiring the end
                                            gap to be greater.</em></label>
                                    <span id='rx33'></span>
                                </div>


                                <div id='block-34' class="qo">
                                    <label for='ox34' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox34' class="on" />
                                        <em>Some provision must be made in a two-stroke/cycle engine to keep
                                            the rings from binding in the ports.
                                        </em></label>
                                    <span id='rx34'></span>
                                </div>


                                <div id='block-35' class="qo">
                                    <label for='ox35' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                            class="on" />
                                        <em>No gap is required to exist between the ends of the ring when cold
                                            in a two-stroke/cycle engine, but a small gap is required in a
                                            fourstroke/cycle engine.</em></label>
                                    <span id='rx35'></span>
                                </div>


                                <div id='block-36' class="qo">
                                    <label for='ox36' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                            class="on" />
                                        <em>The end gaps should be staggered on either side of a piston in a
                                            two-stroke/cycle engine, while staggering is not necessary in a
                                            four-stroke/cycle engine.</em></label>
                                    <span id='rx36'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 10 -->
                            <div class="ques">
                                <p class="qn">10. In a large, low-speed diesel engine the clearance between the
                                    piston crown and cylinder head is found to be excessive. In order to
                                    correct for this, you should ______________.
                                </p>
                                <hr>

                                <div id='block-37' class="qo">
                                    <label for='ox37' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox37' class="on" />
                                        <em>build up the piston crown by metal spraying</em></label>
                                    <span id='rx37'></span>
                                </div>


                                <div id='block-38' class="qo">
                                    <label for='ox38' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox38' class="on" />
                                        <em>build up the cylinder head by metal spraying
                                        </em></label>
                                    <span id='rx38'></span>
                                </div>


                                <div id='block-39' class="qo">
                                    <label for='ox39' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                            class="on" />
                                        <em>insert shims between the crankpin bearing box and the connecting
                                            rod foot
                                        </em></label>
                                    <span id='rx39'></span>
                                </div>


                                <div id='block-40' class="qo">
                                    <label for='ox40' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                            class="on" />
                                        <em>install a thinner head gasket
                                        </em></label>
                                    <span id='rx40'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 11 -->
                            <div class="ques">
                                <p class="qn">11. Bouncing of the valve gear in a diesel engine can be caused by
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-41' class="qo">
                                    <label for='ox41' class="ll">
                                        <input type='radio' name='option' id='ox41' class="on" />
                                        <em>prolonged high speed operation</em></label>
                                    <span id='rx41'></span>
                                </div>


                                <div id='block-42' class="qo">
                                    <label for='ox42' class="ll">
                                        <input type='radio' name='option' id='ox42' class="on" />
                                        <em>spring surge</em></label>
                                    <span id='rx42'></span>
                                </div>


                                <div id='block-43' class="qo">
                                    <label for='ox43' class="ll">
                                        <input type='radio' name='option' id='ox43' class="on" />
                                        <em>worn valve seats</em></label>
                                    <span id='rx43'></span>
                                </div>


                                <div id='block-44' class="qo">
                                    <label for='ox44' class="ll">
                                        <input type='radio' name='option' id='ox44' class="on" />
                                        <em>excessively tightened spring retainers</em></label>
                                    <span id='rx44'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 12 -->
                            <div class="ques">
                                <p class="qn">12. Where engine bores exceed 230 mm, a bursting disc or flame
                                    arrester is to be fitted ___________.
                                </p>
                                <hr>

                                <div id='block-45' class="qo">
                                    <label for='ox45' class="ll">
                                        <input type='radio' name='option' id='ox45' class="on" />
                                        <em>at the supply inlet to the control air manifold for non- reversing
                                            engines</em></label>
                                    <span id='rx45'></span>
                                </div>


                                <div id='block-46' class="qo">
                                    <label for='ox46' class="ll">
                                        <input type='radio' name='option' id='ox46' class="on" />
                                        <em>on the exhaust manifold prior to the inlet of the turbochargers</em></label>
                                    <span id='rx46'></span>
                                </div>


                                <div id='block-47' class="qo">
                                    <label for='ox47' class="ll">
                                        <input type='radio' name='option' id='ox47' class="on" />
                                        <em>on all devices subject to the by-products of combustion or
                                            lubrication system vapors
                                        </em></label>
                                    <span id='rx47'></span>
                                </div>


                                <div id='block-48' class="qo">
                                    <label for='ox48' class="ll">
                                        <input type='radio' name='option' id='ox48' class="on" />
                                        <em>in way of the starting valve of each cylinder for direct reversing
                                            engines having a main starting manifold
                                        </em></label>
                                    <span id='rx48'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 13 -->
                            <div class="ques">
                                <p class="qn">13. What may be used to protect starting air mains against explosions
                                    arising from improperly functioning starting valves?
                                </p>
                                <hr>

                                <div id='block-49' class="qo">
                                    <label for='ox49' class="ll">
                                        <input type='radio' name='option' id='ox49' class="on" />
                                        <em>The starting air main shall be protected by the use of a rupture disc.
                                        </em></label>
                                    <span id='rx49'></span>
                                </div>


                                <div id='block-50' class="qo">
                                    <label for='ox50' class="ll">
                                        <input type='radio' name='option' id='ox50' class="on" />
                                        <em>No protection is necessary because all starting air valves are
                                            designed similar to check valves.</em></label>
                                    <span id='rx50'></span>
                                </div>


                                <div id='block-51' class="qo">
                                    <label for='ox51' class="ll">
                                        <input type='radio' name='option' id='ox51' class="on" />
                                        <em>An isolation non-return valve is to be installed at the starting air
                                            supply connection to each engine.
                                        </em></label>
                                    <span id='rx51'></span>
                                </div>


                                <div id='block-52' class="qo">
                                    <label for='ox52' class="ll">
                                        <input type='radio' name='option' id='ox52' class="on" />
                                        <em>The materials used in the construction of the starting air mains will
                                            contain any explosion.
                                        </em></label>
                                    <span id='rx52'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 14 -->
                            <div class="ques">
                                <p class="qn">14. The total air capacity for non-reversible main engines is to be
                                    sufficient for _______.
                                </p>
                                <hr>

                                <div id='block-53' class="qo">
                                    <label for='ox53' class="ll">
                                        <input type='radio' name='option' id='ox53' class="on" />
                                        <em>six consecutive starts</em></label>
                                    <span id='rx53'></span>
                                </div>


                                <div id='block-54' class="qo">
                                    <label for='ox54' class="ll">
                                        <input type='radio' name='option' id='ox54' class="on" />
                                        <em>eight consecutive starts
                                        </em></label>
                                    <span id='rx54'></span>
                                </div>


                                <div id='block-55' class="qo">
                                    <label for='ox55' class="ll">
                                        <input type='radio' name='option' id='ox55' class="on" />
                                        <em>ten consecutive starts
                                        </em></label>
                                    <span id='rx55'></span>
                                </div>


                                <div id='block-56' class="qo">
                                    <label for='ox56' class="ll">
                                        <input type='radio' name='option' id='ox56' class="on" />
                                        <em>twelve consecutive starts </em></label>
                                    <span id='rx56'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 15 -->
                            <div class="ques">
                                <p class="qn">15. Starting a large propulsion diesel engine using diesel fuel during
                                    cold weather conditions can be made easier by ______.
                                    <hr>

                                <div id='block-57' class="qo">
                                    <label for='ox57' class="ll">
                                        <input type='radio' name='option' id='ox57' class="on" />
                                        <em>increasing the quantity of starting air</em></label>
                                    <span id='rx57'></span>
                                </div>


                                <div id='block-58' class="qo">
                                    <label for='ox58' class="ll">
                                        <input type='radio' name='option' id='ox58' class="on" />
                                        <em>increasing the lube oil pressure
                                        </em></label>
                                    <span id='rx58'></span>
                                </div>


                                <div id='block-59' class="qo">
                                    <label for='ox59' class="ll">
                                        <input type='radio' name='option' id='ox59' class="on" />
                                        <em>heating the engine fuel supply
                                        </em></label>
                                    <span id='rx59'></span>
                                </div>


                                <div id='block-60' class="qo">
                                    <label for='ox60' class="ll">
                                        <input type='radio' name='option' id='ox60' class="on" />
                                        <em>heating the engine jacket water
                                        </em></label>
                                    <span id='rx60'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 16 -->
                            <div class="ques">
                                <p class="qn">16. A diesel engine is turned at normal cranking speed, but fails to fire.
                                    This can occur from _____________.
                                </p>
                                <hr>

                                <div id='block-61' class="qo">
                                    <label for='ox61' class="ll">
                                        <input type='radio' name='option' id='ox61' class="on" />
                                        <em>low lube oil temperature
                                        </em></label>
                                    <span id='rx61'></span>
                                </div>


                                <div id='block-62' class="qo">
                                    <label for='ox62' class="ll">
                                        <input type='radio' name='option' id='ox62' class="on" />
                                        <em>low starting air temperature
                                        </em></label>
                                    <span id='rx62'></span>
                                </div>


                                <div id='block-63' class="qo">
                                    <label for='ox63' class="ll">
                                        <input type='radio' name='option' id='ox63' class="on" />
                                        <em>air in the fuel injection system
                                        </em></label>
                                    <span id='rx63'></span>
                                </div>


                                <div id='block-64' class="qo">
                                    <label for='ox64' class="ll">
                                        <input type='radio' name='option' id='ox64' class="on" />
                                        <em>water in the starting air system</em></label>
                                    <span id='rx64'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 17 -->
                            <div class="ques">
                                <p class="qn">17. Which of the following methods is used to prevent throttling of
                                    compressed air through the diesel engine air starting valves?
                                </p>
                                <hr>

                                <div id='block-65' class="qo">
                                    <label for='ox65' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox65' class="on" />
                                        <em>Holding the valve open for a long period</em></label>
                                    <span id='rx65'></span>
                                </div>


                                <div id='block-66' class="qo">
                                    <label for='ox66' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox66' class="on" />
                                        <em>Increasing the starting air pressure used</em></label>
                                    <span id='rx66'></span>
                                </div>


                                <div id='block-67' class="qo">
                                    <label for='ox67' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                            class="on" />
                                        <em>Opening the starting air valve quickly</em></label>
                                    <span id='rx67'></span>
                                </div>


                                <div id='block-68' class="qo">
                                    <label for='ox68' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                            class="on" />
                                        <em>Reducing the starting air valve size
                                        </em></label>
                                    <span id='rx68'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 18 -->
                            <div class="ques">
                                <p class="qn">18. In the starting process of a diesel engine, the main object is to
                                    attain the compression conditions sufficient to ______________.
                                    <hr>

                                <div id='block-69' class="qo">
                                    <label for='ox69' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox69' class="on" />
                                        <em>turn the flywheel
                                        </em></label>
                                    <span id='rx69'></span>
                                </div>


                                <div id='block-70' class="qo">
                                    <label for='ox70' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox70' class="on" />
                                        <em>reduce friction
                                        </em></label>
                                    <span id='rx70'></span>
                                </div>


                                <div id='block-71' class="qo">
                                    <label for='ox71' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                            class="on" />
                                        <em>overcome inertia
                                        </em></label>
                                    <span id='rx71'></span>
                                </div>


                                <div id='block-72' class="qo">
                                    <label for='ox72' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                            class="on" />
                                        <em>ignite the fuel</em></label>
                                    <span id='rx72'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 19 -->
                            <div class="ques">
                                <p class="qn">19. Fluid type starting motors used for starting auxiliary diesel engines
                                    may either be of the piston type or the _____________.
                                </p>
                                <hr>

                                <div id='block-73' class="qo">
                                    <label for='ox73' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox73' class="on" />
                                        <em>gear type</em></label>
                                    <span id='rx73'></span>
                                </div>


                                <div id='block-74' class="qo">
                                    <label for='ox74' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox74' class="on" />
                                        <em>vane type</em></label>
                                    <span id='rx74'></span>
                                </div>


                                <div id='block-75' class="qo">
                                    <label for='ox75' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                            class="on" />
                                        <em>impeller type
                                        </em></label>
                                    <span id='rx75'></span>
                                </div>


                                <div id='block-76' class="qo">
                                    <label for='ox76' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                            class="on" />
                                        <em>accumulator type</em></label>
                                    <span id='rx76'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 20 -->
                            <div class="ques">
                                <p class="qn">20. A six-cylinder, four-stroke/cycle diesel engine is fitted with a
                                    rotary
                                    distributor type air starting system. The speed of the rotating
                                    distributor disc is _____________.
                                </p>
                                <hr>

                                <div id='block-77' class="qo">
                                    <label for='ox77' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox77' class="on" />
                                        <em>one-half engine speed
                                        </em></label>
                                    <span id='rx77'></span>
                                </div>


                                <div id='block-78' class="qo">
                                    <label for='ox78' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox78' class="on" />
                                        <em>the same as engine speed
                                        </em></label>
                                    <span id='rx78'></span>
                                </div>


                                <div id='block-79' class="qo">
                                    <label for='ox79' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                            class="on" />
                                        <em>twice engine speed </em></label>
                                    <span id='rx79'></span>
                                </div>


                                <div id='block-80' class="qo">
                                    <label for='ox80' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                            class="on" />
                                        <em>four times engine speed
                                        </em></label>
                                    <span id='rx80'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                </div>
                            </div>
                            <hr>



                        </article>
                    </div>

                    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/motor/asset/"; include($IPATH."motor_sidebar.html"); ?>
            </main>
            <nav aria-label="...">
                <ul class="pagination " style=" flex-wrap:wrap; ">
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/1.php">First Page</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/10.php">10</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/20.php">20</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/30.php">30</a></li>
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/39.php">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/38.php">38</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/39.php">39</a></li>
                    <li class="page-item active" aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/40.php">40</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/41.php">41</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/42.php">42</a></li>
                    <li class="page-item">
                        <a class="page-link" href="/marine_engineering/motor/41.php">Next</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/40.php">40</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/44.php">Last Page</a>
                    </li>
                </ul>
            </nav>
        </div>
    </section>
    <!-- main1 end  -->
    <!-- Footer -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
    <!-- Footer End -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
        crossorigin="anonymous"></script>
</body>

</html>