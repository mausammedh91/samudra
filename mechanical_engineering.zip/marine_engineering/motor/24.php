<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/motor/javascript/24.js"></script>

    <title>Motor: Maintenance, Design, Components, Operation (Set24)</title>
    <meta name="description"
        content="A dry-type exhaust muffler clogged with soot..., Diesel engine cylinder head test cocks are..., Air may be bled from the fuel system..., Which of the terms listed below represents the operational..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, motor, operation, design, services, fuel, submit, engine, exhaust, temperature, pressure, diesel, air, injection, cylinder, system, normal, oil, speed, high, compression, water, nozzle, firing, early, timing, engineering, marine, power, valves, excessive, valve, load, stroke, lube, piston, systems, check, filters, maximum, due, operating, cooling, test, lubrication, connect, gas, changing, listed, vibration, open, leak, line, improper, expansion, occur, start, started, lines, pump, pumps, increase, level, instrumentation, control, heat, ship, page, exhaust temperature, the fuel, diesel engine, of the, fuel injection, in the, firing pressure, a diesel, low exhaust, fuel will, injection timing, normal with, normal exhaust, on the, lube oil, temperature and, marine engineering, fuel system, the compression, which of, the nozzle, will be, and low, timing is, the cylinder, above normal, with a, below normal, temperature submit, due to, compression pressure, engine is, fuel oil, high exhaust, services marine, engineering motor, will cause, connect the, the exhaust, from the, at the, changing fuel, fuel filters, maximum speed, into the, pressure and, early injection, early fuel, is indicated, indicated by, a normal, temperature below, will occur, compression stroke, engine operating, the engine, can be, the water, should be, fuel lines, an increase, increase in, pressure on, low firing, and high, high firing, pressure low, check the, engine fuel, the piston, a diesel engine, of the fuel, low exhaust temperature, normal exhaust temperature, exhaust temperature and, which of the, normal with a, in the fuel, diesel engine is, high exhaust temperature, services marine engineering, marine engineering motor, from the fuel, the fuel system, changing fuel filters, early injection timing, early fuel injection, fuel injection timing, injection timing is, timing is indicated, is indicated by, above normal with, with a normal, a normal exhaust, exhaust temperature below, temperature below normal, below normal with, on the compression, the compression stroke, the fuel oil, an increase in, pressure on the, temperature and low, and low firing, low firing pressure, temperature and high, and high firing, high firing pressure, firing pressure low, pressure low exhaust, diesel engine fuel, services marine engineering motor, early fuel injection timing, injection timing is indicated, timing is indicated by, above normal with a, normal with a normal, with a normal exhaust, a normal exhaust temperature, normal exhaust temperature below, exhaust temperature below normal, temperature below normal with, on the compression stroke, a diesel engine is, of the fuel oil, high exhaust temperature and, exhaust temperature and low, temperature and low firing, and low firing pressure, exhaust temperature and high, temperature and high firing, and high firing pressure, firing pressure low exhaust, pressure low exhaust temperature, low exhaust temperature and, injection timing is indicated by, normal with a normal exhaust, with a normal exhaust temperature, a normal exhaust temperature below, normal exhaust temperature below normal, exhaust temperature below normal with, exhaust temperature and low firing, temperature and low firing pressure, exhaust temperature and high firing, temperature and high firing pressure, firing pressure low exhaust temperature, pressure low exhaust temperature and" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12"></div>
        <ul id="breadcrumbs-course">
            <li><a href="/Index.php">Home</a></li>
            <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
            <li><a href="/marine_engineering/motor/24.php" style="cursor: default;">Motor: <span style="color:#7f0804;"
                        id="lecid">MCQ</span></a></li>
        </ul>
    </div>
    <!-- path end -->
    <!-- main1 start  -->
    <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
        style="background-color: whitesmoke;">
        <div class="row py-lg-8">
            <main class="container bg-light">
                <div class="row">
                    <div class="col-md-8">

                        <article class="blog-post">
                            <h1 class="blog-post-title">Motor: Maintenance, Design, Components, Operation (Set24)</h1>
                            <hr>
                            <p>
                            <h4>Multiple Choice Questions</h4>
                            <hr>
                            <!-- Question 1 -->
                            <div class="ques">
                                <p class="qn">1. A dry-type exhaust muffler clogged with soot, will cause
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-1' class="qo">
                                    <label for='ox1' class="ll">
                                        <input type='radio' name='option' id='ox1' class="on" />
                                        <em>low exhaust temperature</em></label>
                                    <span id='rx1'></span>
                                </div>


                                <div id='block-2' class="qo">
                                    <label for='ox2' class="ll">
                                        <input type='radio' name='option' id='ox2' class="on" />
                                        <em>loss of engine power
                                        </em></label>
                                    <span id='rx2'></span>
                                </div>


                                <div id='block-3' class="qo">
                                    <label for='ox3' class="ll">
                                        <input type='radio' name='option' id='ox3' class="on" />
                                        <em>burned intake valves</em></label>
                                    <span id='rx3'></span>
                                </div>


                                <div id='block-4' class="qo">
                                    <label for='ox4' class="ll">
                                        <input type='radio' name='option' id='ox4' class="on" />
                                        <em>engine racing</em></label>
                                    <span id='rx4'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 2 -->
                            <div class="ques">
                                <p class="qn">2. Diesel engine cylinder head test cocks are used to ________.
                                </p>
                                <hr>

                                <div id='block-5' class="qo">
                                    <label for='ox5' class="ll">
                                        <input type='radio' name='option' id='ox5' class="on" />
                                        <em>check cylinder lubrication
                                        </em></label>
                                    <span id='rx5'></span>
                                </div>


                                <div id='block-6' class="qo">
                                    <label for='ox6' class="ll">
                                        <input type='radio' name='option' id='ox6' class="on" />
                                        <em>connect the pressure indicator
                                        </em></label>
                                    <span id='rx6'></span>
                                </div>


                                <div id='block-7' class="qo">
                                    <label for='ox7' class="ll">
                                        <input type='radio' name='option' id='ox7' class="on" />
                                        <em>pressure test cylinder heads
                                        </em></label>
                                    <span id='rx7'></span>
                                </div>


                                <div id='block-8' class="qo">
                                    <label for='ox8' class="ll">
                                        <input type='radio' name='option' id='ox8' class="on" />
                                        <em>connect the exhaust gas pyrometers
                                        </em></label>
                                    <span id='rx8'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 3 -->
                            <div class="ques">
                                <p class="qn">3. Air may be bled from the fuel system by _____________.
                                </p>
                                <hr>

                                <div id='block-9' class="qo">
                                    <label for='ox9' class="ll">
                                        <input type='radio' name='option' id='ox9' class="on" />
                                        <em>blowing down the air tanks</em></label>
                                    <span id='rx9'></span>
                                </div>


                                <div id='block-10' class="qo">
                                    <label for='ox10' class="ll">
                                        <input type='radio' name='option' id='ox10' class="on" />
                                        <em>loosening the compression nuts at the injectors
                                        </em></label>
                                    <span id='rx10'></span>
                                </div>


                                <div id='block-11' class="qo">
                                    <label for='ox11' class="ll">
                                        <input type='radio' name='option' id='ox11' class="on" />
                                        <em>changing fuel filters
                                        </em></label>
                                    <span id='rx11'></span>
                                </div>


                                <div id='block-12' class="qo">
                                    <label for='ox12' class="ll">
                                        <input type='radio' name='option' id='ox12' class="on" />
                                        <em>changing fuel filters</em></label>
                                    <span id='rx12'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 4 -->
                            <div class="ques">
                                <p class="qn">4. Which of the terms listed below represents the operational speed at
                                    which excessive engine vibration is created?
                                </p>
                                <hr>

                                <div id='block-13' class="qo">
                                    <label for='ox13' class="ll">
                                        <input type='radio' name='option' id='ox13' class="on" />
                                        <em>Non-harmonic speed.
                                        </em></label>
                                    <span id='rx13'></span>
                                </div>


                                <div id='block-14' class="qo">
                                    <label for='ox14' class="ll">
                                        <input type='radio' name='option' id='ox14' class="on" />
                                        <em>Critical speed. </em></label>
                                    <span id='rx14'></span>
                                </div>


                                <div id='block-15' class="qo">
                                    <label for='ox15' class="ll">
                                        <input type='radio' name='option' id='ox15' class="on" />
                                        <em>Maximum speed. </em></label>
                                    <span id='rx15'></span>
                                </div>


                                <div id='block-16' class="qo">
                                    <label for='ox16' class="ll">
                                        <input type='radio' name='option' id='ox16' class="on" />
                                        <em>Design maximum speed.</em></label>
                                    <span id='rx16'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 5 -->
                            <div class="ques">
                                <p class="qn">5. If the needle valve in a fuel injection nozzle sticks open,
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-17' class="qo">
                                    <label for='ox17' class="ll">
                                        <input type='radio' name='option' id='ox17' class="on" />
                                        <em>fuel will leak into the nozzle drain line
                                        </em></label>
                                    <span id='rx17'></span>
                                </div>


                                <div id='block-18' class="qo">
                                    <label for='ox18' class="ll">
                                        <input type='radio' name='option' id='ox18' class="on" />
                                        <em>no fuel will be delivered through the nozzle
                                        </em></label>
                                    <span id='rx18'></span>
                                </div>


                                <div id='block-19' class="qo">
                                    <label for='ox19' class="ll">
                                        <input type='radio' name='option' id='ox19' class="on" />
                                        <em>the nozzle will overheat
                                        </em></label>
                                    <span id='rx19'></span>
                                </div>


                                <div id='block-20' class="qo">
                                    <label for='ox20' class="ll">
                                        <input type='radio' name='option' id='ox20' class="on" />
                                        <em> injection lag will be increased</em></label>
                                    <span id='rx20'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 6 -->
                            <div class="ques">
                                <p class="qn">6. Which of the conditions listed would cause simultaneous high
                                    cylinder firing pressure and low exhaust temperature?
                                </p>
                                <hr>

                                <div id='block-21' class="qo">
                                    <label for='ox21' class="ll">
                                        <input type='radio' name='option' id='ox21' class="on" />
                                        <em>Improper fuel rack positioning.</em></label>
                                    <span id='rx21'></span>
                                </div>


                                <div id='block-22' class="qo">
                                    <label for='ox22' class="ll">
                                        <input type='radio' name='option' id='ox22' class="on" />
                                        <em>Lengthy opening of the exhaust valve.</em></label>
                                    <span id='rx22'></span>
                                </div>


                                <div id='block-23' class="qo">
                                    <label for='ox23' class="ll">
                                        <input type='radio' name='option' id='ox23' class="on" />
                                        <em>Excessively early injection timing. </em></label>
                                    <span id='rx23'></span>
                                </div>


                                <div id='block-24' class="qo">
                                    <label for='ox24' class="ll">
                                        <input type='radio' name='option' id='ox24' class="on" />
                                        <em>Extended light load operation.</em></label>
                                    <span id='rx24'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 7 -->
                            <div class="ques">
                                <p class="qn">7. Early fuel injection timing is indicated by the cylinder pressure being
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-25' class="qo">
                                    <label for='ox25' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox25' class="on" />
                                        <em>above normal with a below normal exhaust temperature</em></label>
                                    <span id='rx25'></span>
                                </div>


                                <div id='block-26' class="qo">
                                    <label for='ox26' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox26' class="on" />
                                        <em>above normal with a normal exhaust temperature</em></label>
                                    <span id='rx26'></span>
                                </div>


                                <div id='block-27' class="qo">
                                    <label for='ox27' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                            class="on" />
                                        <em>below normal with a normal exhaust temperature</em></label>
                                    <span id='rx27'></span>
                                </div>


                                <div id='block-28' class="qo">
                                    <label for='ox28' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                            class="on" />
                                        <em>below normal with an above normal exhaust temperature
                                        </em></label>
                                    <span id='rx28'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 8 -->
                            <div class="ques">
                                <p class="qn">8. If fuel injection occurs too early, a diesel engine will lose power
                                    because the _____________.</p>
                                <hr>

                                <div id='block-29' class="qo">
                                    <label for='ox29' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox29' class="on" />
                                        <em>fuel will not be properly atomized in the cylinder</em></label>
                                    <span id='rx29'></span>
                                </div>


                                <div id='block-30' class="qo">
                                    <label for='ox30' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox30' class="on" />
                                        <em>ignition will be delayed due to low compression pressure</em></label>
                                    <span id='rx30'></span>
                                </div>


                                <div id='block-31' class="qo">
                                    <label for='ox31' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                            class="on" />
                                        <em>maximum fuel expansion will occur on the compression stroke
                                        </em></label>
                                    <span id='rx31'></span>
                                </div>


                                <div id='block-32' class="qo">
                                    <label for='ox32' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                            class="on" />
                                        <em>fuel will ignite after top dead center</em></label>
                                    <span id='rx32'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 9 -->
                            <div class="ques">
                                <p class="qn">9. Diesel engine air start valve timing is controlled by
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-33' class="qo">
                                    <label for='ox33' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox33' class="on" />
                                        <em>engine operating speed
                                        </em></label>
                                    <span id='rx33'></span>
                                </div>


                                <div id='block-34' class="qo">
                                    <label for='ox34' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox34' class="on" />
                                        <em>an air manifold</em></label>
                                    <span id='rx34'></span>
                                </div>


                                <div id='block-35' class="qo">
                                    <label for='ox35' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                            class="on" />
                                        <em>a hydraulic distributor</em></label>
                                    <span id='rx35'></span>
                                </div>


                                <div id='block-36' class="qo">
                                    <label for='ox36' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                            class="on" />
                                        <em>individual cams and valve gear</em></label>
                                    <span id='rx36'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 10 -->
                            <div class="ques">
                                <p class="qn">10. A diesel engine fails to start due to excessive water in the fuel.
                                    Before the engine can be started, the water should be removed
                                    from the _____________.
                                </p>
                                <hr>

                                <div id='block-37' class="qo">
                                    <label for='ox37' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox37' class="on" />
                                        <em>fuel lines </em></label>
                                    <span id='rx37'></span>
                                </div>


                                <div id='block-38' class="qo">
                                    <label for='ox38' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox38' class="on" />
                                        <em>lube oil filter</em></label>
                                    <span id='rx38'></span>
                                </div>


                                <div id='block-39' class="qo">
                                    <label for='ox39' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                            class="on" />
                                        <em>crank case pump</em></label>
                                    <span id='rx39'></span>
                                </div>


                                <div id='block-40' class="qo">
                                    <label for='ox40' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                            class="on" />
                                        <em>rocker arm reservoir</em></label>
                                    <span id='rx40'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 11 -->
                            <div class="ques">
                                <p class="qn">11. If you suspect a diesel engine is misfiring due to air leakage into
                                    the fuel system, you should begin looking for the leak at the
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-41' class="qo">
                                    <label for='ox41' class="ll">
                                        <input type='radio' name='option' id='ox41' class="on" />
                                        <em>fuel line connections to the cylinder injection valves
                                        </em></label>
                                    <span id='rx41'></span>
                                </div>


                                <div id='block-42' class="qo">
                                    <label for='ox42' class="ll">
                                        <input type='radio' name='option' id='ox42' class="on" />
                                        <em>gasket surfaces of the fuel oil filters</em></label>
                                    <span id='rx42'></span>
                                </div>


                                <div id='block-43' class="qo">
                                    <label for='ox43' class="ll">
                                        <input type='radio' name='option' id='ox43' class="on" />
                                        <em>discharge fittings of the fuel injector pumps</em></label>
                                    <span id='rx43'></span>
                                </div>


                                <div id='block-44' class="qo">
                                    <label for='ox44' class="ll">
                                        <input type='radio' name='option' id='ox44' class="on" />
                                        <em>suction side of the fuel oil transfer pump</em></label>
                                    <span id='rx44'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 12 -->
                            <div class="ques">
                                <p class="qn">12. An increase in the load on a turbocharged diesel engine operating
                                    at constant speed will result in an increase in _____________.
                                </p>
                                <hr>

                                <div id='block-45' class="qo">
                                    <label for='ox45' class="ll">
                                        <input type='radio' name='option' id='ox45' class="on" />
                                        <em>exhaust temperature
                                        </em></label>
                                    <span id='rx45'></span>
                                </div>


                                <div id='block-46' class="qo">
                                    <label for='ox46' class="ll">
                                        <input type='radio' name='option' id='ox46' class="on" />
                                        <em>air box pressure
                                        </em></label>
                                    <span id='rx46'></span>
                                </div>


                                <div id='block-47' class="qo">
                                    <label for='ox47' class="ll">
                                        <input type='radio' name='option' id='ox47' class="on" />
                                        <em>brake mean effective pressure
                                        </em></label>
                                    <span id='rx47'></span>
                                </div>


                                <div id='block-48' class="qo">
                                    <label for='ox48' class="ll">
                                        <input type='radio' name='option' id='ox48' class="on" />
                                        <em>all of the above</em></label>
                                    <span id='rx48'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 13 -->
                            <div class="ques">
                                <p class="qn">13. When a diesel engine is operated at partial load, as compared to
                                    full load, a decrease will occur in the average _____________.
                                </p>
                                <hr>

                                <div id='block-49' class="qo">
                                    <label for='ox49' class="ll">
                                        <input type='radio' name='option' id='ox49' class="on" />
                                        <em>air quantity aspirated
                                        </em></label>
                                    <span id='rx49'></span>
                                </div>


                                <div id='block-50' class="qo">
                                    <label for='ox50' class="ll">
                                        <input type='radio' name='option' id='ox50' class="on" />
                                        <em>fuel injection pressure
                                        </em></label>
                                    <span id='rx50'></span>
                                </div>


                                <div id='block-51' class="qo">
                                    <label for='ox51' class="ll">
                                        <input type='radio' name='option' id='ox51' class="on" />
                                        <em>combustion pressure on the power stroke
                                        </em></label>
                                    <span id='rx51'></span>
                                </div>


                                <div id='block-52' class="qo">
                                    <label for='ox52' class="ll">
                                        <input type='radio' name='option' id='ox52' class="on" />
                                        <em>compression pressure on the compression stroke
                                        </em></label>
                                    <span id='rx52'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 14 -->
                            <div class="ques">
                                <p class="qn">14. Air in the fuel can cause _____________.
                                </p>
                                <hr>

                                <div id='block-53' class="qo">
                                    <label for='ox53' class="ll">
                                        <input type='radio' name='option' id='ox53' class="on" />
                                        <em>high lube oil temperature
                                        </em></label>
                                    <span id='rx53'></span>
                                </div>


                                <div id='block-54' class="qo">
                                    <label for='ox54' class="ll">
                                        <input type='radio' name='option' id='ox54' class="on" />
                                        <em>blue smoke</em></label>
                                    <span id='rx54'></span>
                                </div>


                                <div id='block-55' class="qo">
                                    <label for='ox55' class="ll">
                                        <input type='radio' name='option' id='ox55' class="on" />
                                        <em>the engine to stop </em></label>
                                    <span id='rx55'></span>
                                </div>


                                <div id='block-56' class="qo">
                                    <label for='ox56' class="ll">
                                        <input type='radio' name='option' id='ox56' class="on" />
                                        <em>piston seizure </em></label>
                                    <span id='rx56'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 15 -->
                            <div class="ques">
                                <p class="qn">15. Early injection timing is indicated by ____________.
                                </p>
                                <hr>

                                <div id='block-57' class="qo">
                                    <label for='ox57' class="ll">
                                        <input type='radio' name='option' id='ox57' class="on" />
                                        <em>high exhaust temperature and low firing pressure</em></label>
                                    <span id='rx57'></span>
                                </div>


                                <div id='block-58' class="qo">
                                    <label for='ox58' class="ll">
                                        <input type='radio' name='option' id='ox58' class="on" />
                                        <em>high exhaust temperature and high firing pressure
                                        </em></label>
                                    <span id='rx58'></span>
                                </div>


                                <div id='block-59' class="qo">
                                    <label for='ox59' class="ll">
                                        <input type='radio' name='option' id='ox59' class="on" />
                                        <em>low exhaust temperature and low firing pressure</em></label>
                                    <span id='rx59'></span>
                                </div>


                                <div id='block-60' class="qo">
                                    <label for='ox60' class="ll">
                                        <input type='radio' name='option' id='ox60' class="on" />
                                        <em>low exhaust temperature and high firing pressure
                                        </em></label>
                                    <span id='rx60'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 16 -->
                            <div class="ques">
                                <p class="qn">16. Which of the following operating procedures should be carried out
                                    immediately after any diesel engine is started?
                                </p>
                                <hr>

                                <div id='block-61' class="qo">
                                    <label for='ox61' class="ll">
                                        <input type='radio' name='option' id='ox61' class="on" />
                                        <em>Take all exhaust temperature readings.
                                        </em></label>
                                    <span id='rx61'></span>
                                </div>


                                <div id='block-62' class="qo">
                                    <label for='ox62' class="ll">
                                        <input type='radio' name='option' id='ox62' class="on" />
                                        <em>Check the sump oil level.
                                        </em></label>
                                    <span id='rx62'></span>
                                </div>


                                <div id='block-63' class="qo">
                                    <label for='ox63' class="ll">
                                        <input type='radio' name='option' id='ox63' class="on" />
                                        <em>Verify proper lube oil pressure.
                                        </em></label>
                                    <span id='rx63'></span>
                                </div>


                                <div id='block-64' class="qo">
                                    <label for='ox64' class="ll">
                                        <input type='radio' name='option' id='ox64' class="on" />
                                        <em>Check the water level in expansion tank</em></label>
                                    <span id='rx64'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 17 -->
                            <div class="ques">
                                <p class="qn">17. The most common diesel engine fuel system problems are caused
                                    by _____________.
                                </p>
                                <hr>

                                <div id='block-65' class="qo">
                                    <label for='ox65' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox65' class="on" />
                                        <em>incorrect adjustments</em></label>
                                    <span id='rx65'></span>
                                </div>


                                <div id='block-66' class="qo">
                                    <label for='ox66' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox66' class="on" />
                                        <em>dirty fuel
                                        </em></label>
                                    <span id='rx66'></span>
                                </div>


                                <div id='block-67' class="qo">
                                    <label for='ox67' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                            class="on" />
                                        <em>broken fuel lines
                                        </em></label>
                                    <span id='rx67'></span>
                                </div>


                                <div id='block-68' class="qo">
                                    <label for='ox68' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                            class="on" />
                                        <em>excessive vibration</em></label>
                                    <span id='rx68'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 18 -->
                            <div class="ques">
                                <p class="qn">18. If sludge accumulates on the underside of a diesel engine piston, it
                                    will ______________.
                                </p>
                                <hr>

                                <div id='block-69' class="qo">
                                    <label for='ox69' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox69' class="on" />
                                        <em>cause blow-by
                                        </em></label>
                                    <span id='rx69'></span>
                                </div>


                                <div id='block-70' class="qo">
                                    <label for='ox70' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox70' class="on" />
                                        <em>chemically attack the piston skirt </em></label>
                                    <span id='rx70'></span>
                                </div>


                                <div id='block-71' class="qo">
                                    <label for='ox71' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                            class="on" />
                                        <em>form an emulsion of lube oil and water
                                        </em></label>
                                    <span id='rx71'></span>
                                </div>


                                <div id='block-72' class="qo">
                                    <label for='ox72' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                            class="on" />
                                        <em>raise the piston temperature</em></label>
                                    <span id='rx72'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 19 -->
                            <div class="ques">
                                <p class="qn">19. Faulty operation of diesel engine fuel injection nozzles can be a
                                    direct cause of ______________.
                                </p>
                                <hr>

                                <div id='block-73' class="qo">
                                    <label for='ox73' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox73' class="on" />
                                        <em>excessive fuel nozzle holder cooling
                                        </em></label>
                                    <span id='rx73'></span>
                                </div>


                                <div id='block-74' class="qo">
                                    <label for='ox74' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox74' class="on" />
                                        <em>sediment in the fuel supply
                                        </em></label>
                                    <span id='rx74'></span>
                                </div>


                                <div id='block-75' class="qo">
                                    <label for='ox75' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                            class="on" />
                                        <em>distortion of the fuel spray pattern
                                        </em></label>
                                    <span id='rx75'></span>
                                </div>


                                <div id='block-76' class="qo">
                                    <label for='ox76' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                            class="on" />
                                        <em>improper atomization of the fuel
                                        </em></label>
                                    <span id='rx76'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 20 -->
                            <div class="ques">
                                <p class="qn">20. Low cylinder compression pressure and a high exhaust
                                    temperature may indicate ______________.</p>
                                <hr>

                                <div id='block-77' class="qo">
                                    <label for='ox77' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox77' class="on" />
                                        <em>early fuel injection timing</em></label>
                                    <span id='rx77'></span>
                                </div>


                                <div id='block-78' class="qo">
                                    <label for='ox78' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox78' class="on" />
                                        <em>leaking valves</em></label>
                                    <span id='rx78'></span>
                                </div>


                                <div id='block-79' class="qo">
                                    <label for='ox79' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                            class="on" />
                                        <em>a continuously open scavenge air port</em></label>
                                    <span id='rx79'></span>
                                </div>


                                <div id='block-80' class="qo">
                                    <label for='ox80' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                            class="on" />
                                        <em>low cooling water temperature</em></label>
                                    <span id='rx80'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                </div>
                            </div>
                            <hr>



                        </article>
                    </div>

                    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/motor/asset/"; include($IPATH."motor_sidebar.html"); ?>
            </main>
            <nav aria-label="...">
                <ul class="pagination " style=" flex-wrap:wrap; ">
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/1.php">First Page</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/10.php">10</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/20.php">20</a></li>
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/23.php">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/22.php">22</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/23.php">23</a></li>
                    <li class="page-item active" aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/24.php">24</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/25.php">25</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/26.php">26</a></li>
                    <li class="page-item">
                        <a class="page-link" href="/marine_engineering/motor/25.php">Next</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/30.php">30</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/40.php">40</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/44.php">Last Page</a>
                    </li>
                </ul>
            </nav>
        </div>
    </section>
    <!-- main1 end  -->
    <!-- Footer -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
    <!-- Footer End -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
        crossorigin="anonymous"></script>
</body>

</html>