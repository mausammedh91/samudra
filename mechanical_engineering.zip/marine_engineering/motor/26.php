<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/motor/javascript/26.js"></script>

    <title>Motor: Maintenance, Design, Components, Operation (Set26)</title>
    <meta name="description"
        content="A large low speed main propulsion diesel engine may..., Immediately after any diesel engine is started, the engineer..., In a diesel engine lube oil system, which of the following..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, motor, main, services, engine, submit, diesel, fuel, pressure, cylinder, oil, exhaust, water, crankcase, temperature, piston, system, high, air, cooling, excessive, combustion, increase, engineering, marine, lube, consumption, injection, result, heat, systems, propulsion, head, bearings, caused, compression, scavenge, temperatures, output, rings, operating, power, engines, large, heavy, check, saltwater, gas, occur, nozzle, increased, early, timing, knock, light, load, insufficient, burning, expansion, scale, exchanger, tube, sea, carbon, deposits, scavenging, effective, passages, valves, hot, bearing, lubrication, develop, instrumentation, control, ship, page, diesel engine, of the, a diesel, of a, in a, which of, can be, the crankcase, lube oil, the following, the engine, cooling water, in the, marine engineering, propulsion diesel, be caused, caused by, will be, the exhaust, on the, exhaust back, back pressure, increase in, fuel oil, that cylinder, services marine, engineering motor, a large, main propulsion, engine may, crankcase pressure, exhaust temperature, combustion in, engine can, scavenge air, fuel consumption, may occur, pressure of, by the, all of, injection timing, combustion knock, piston rings, piston cooling, result in, heat exchanger, water system, operating the, sea water, in an, an increase, engine power, power output, cylinder scavenging, scavenging submit, a compression, consumption submit, water passages, cylinder head, may be, excessive lube, oil consumption, from the, the fuel, crankcase submit, diesel engines, and air, will develop, a diesel engine, in a diesel, which of the, of the following, can be caused, be caused by, exhaust back pressure, services marine engineering, marine engineering motor, main propulsion diesel, propulsion diesel engine, diesel engine may, diesel engine can, engine can be, pressure of a, all of the, operating the engine, an increase in, engine power output, cylinder scavenging submit, excessive lube oil, in the crankcase, the crankcase submit, in a diesel engine, which of the following, can be caused by, services marine engineering motor, main propulsion diesel engine, a diesel engine can, diesel engine can be, engine can be caused, in the crankcase submit, in a diesel engine can, a diesel engine can be, diesel engine can be caused, engine can be caused by" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>


<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12"></div>
        <ul id="breadcrumbs-course">
            <li><a href="/Index.php">Home</a></li>
            <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
            <li><a href="/marine_engineering/motor/26.php" style="cursor: default;">Motor: <span style="color:#7f0804;"
                        id="lecid">MCQ</span></a></li>
        </ul>
    </div>
    <!-- path end -->
    <!-- main1 start  -->
    <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
        style="background-color: whitesmoke;">
        <div class="row py-lg-8">
            <main class="container bg-light">
                <div class="row">
                    <div class="col-md-8">

                        <article class="blog-post">
                            <h1 class="blog-post-title">Motor: Maintenance, Design, Components, Operation (Set26)</h1>
                            <hr>
                            <p>
                            <h4>Multiple Choice Questions</h4>
                            <hr>
                            <!-- Question 1 -->
                            <div class="ques">
                                <p class="qn">1. A large low speed main propulsion diesel engine may
                                    becomeoverloaded by_______________. <br> I. a heavily fouled hull <br> II.
                                    strong head winds and heavy seas
                                </p>
                                <hr>

                                <div id='block-1' class="qo">
                                    <label for='ox1' class="ll">
                                        <input type='radio' name='option' id='ox1' class="on" />
                                        <em>I only
                                        </em></label>
                                    <span id='rx1'></span>
                                </div>


                                <div id='block-2' class="qo">
                                    <label for='ox2' class="ll">
                                        <input type='radio' name='option' id='ox2' class="on" />
                                        <em>II only
                                        </em></label>
                                    <span id='rx2'></span>
                                </div>


                                <div id='block-3' class="qo">
                                    <label for='ox3' class="ll">
                                        <input type='radio' name='option' id='ox3' class="on" />
                                        <em>both I and II</em></label>
                                    <span id='rx3'></span>
                                </div>


                                <div id='block-4' class="qo">
                                    <label for='ox4' class="ll">
                                        <input type='radio' name='option' id='ox4' class="on" />
                                        <em>neither I nor II</em></label>
                                    <span id='rx4'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 2 -->
                            <div class="ques">
                                <p class="qn">2. Immediately after any diesel engine is started, the engineer should
                                    check the ____________.
                                </p>
                                <hr>

                                <div id='block-5' class="qo">
                                    <label for='ox5' class="ll">
                                        <input type='radio' name='option' id='ox5' class="on" />
                                        <em>crankcase pressure
                                        </em></label>
                                    <span id='rx5'></span>
                                </div>


                                <div id='block-6' class="qo">
                                    <label for='ox6' class="ll">
                                        <input type='radio' name='option' id='ox6' class="on" />
                                        <em>lube oil pressure
                                        </em></label>
                                    <span id='rx6'></span>
                                </div>


                                <div id='block-7' class="qo">
                                    <label for='ox7' class="ll">
                                        <input type='radio' name='option' id='ox7' class="on" />
                                        <em>saltwater pressure
                                        </em></label>
                                    <span id='rx7'></span>
                                </div>


                                <div id='block-8' class="qo">
                                    <label for='ox8' class="ll">
                                        <input type='radio' name='option' id='ox8' class="on" />
                                        <em>exhaust temperature
                                        </em></label>
                                    <span id='rx8'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 3 -->
                            <div class="ques">
                                <p class="qn">3. In a diesel engine lube oil system, which of the following parts
                                    should be lubricated first?
                                </p>
                                <hr>

                                <div id='block-9' class="qo">
                                    <label for='ox9' class="ll">
                                        <input type='radio' name='option' id='ox9' class="on" />
                                        <em>Camshaft bearings</em></label>
                                    <span id='rx9'></span>
                                </div>


                                <div id='block-10' class="qo">
                                    <label for='ox10' class="ll">
                                        <input type='radio' name='option' id='ox10' class="on" />
                                        <em>Main bearings
                                        </em></label>
                                    <span id='rx10'></span>
                                </div>


                                <div id='block-11' class="qo">
                                    <label for='ox11' class="ll">
                                        <input type='radio' name='option' id='ox11' class="on" />
                                        <em>Piston crowns
                                        </em></label>
                                    <span id='rx11'></span>
                                </div>


                                <div id='block-12' class="qo">
                                    <label for='ox12' class="ll">
                                        <input type='radio' name='option' id='ox12' class="on" />
                                        <em>Cylinder walls</em></label>
                                    <span id='rx12'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 4 -->
                            <div class="ques">
                                <p class="qn">4. Poor combustion in a diesel engine can be caused by
                                    ______________.
                                </p>
                                <hr>

                                <div id='block-13' class="qo">
                                    <label for='ox13' class="ll">
                                        <input type='radio' name='option' id='ox13' class="on" />
                                        <em>high compression pressure
                                        </em></label>
                                    <span id='rx13'></span>
                                </div>


                                <div id='block-14' class="qo">
                                    <label for='ox14' class="ll">
                                        <input type='radio' name='option' id='ox14' class="on" />
                                        <em>low intake air temperature</em></label>
                                    <span id='rx14'></span>
                                </div>


                                <div id='block-15' class="qo">
                                    <label for='ox15' class="ll">
                                        <input type='radio' name='option' id='ox15' class="on" />
                                        <em>low exhaust pressure</em></label>
                                    <span id='rx15'></span>
                                </div>


                                <div id='block-16' class="qo">
                                    <label for='ox16' class="ll">
                                        <input type='radio' name='option' id='ox16' class="on" />
                                        <em>high scavenge air pressure</em></label>
                                    <span id='rx16'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 5 -->
                            <div class="ques">
                                <p class="qn">5. Diesel engine exhaust gas temperatures can be used to determine
                                    individual cylinder _____________.
                                </p>
                                <hr>

                                <div id='block-17' class="qo">
                                    <label for='ox17' class="ll">
                                        <input type='radio' name='option' id='ox17' class="on" />
                                        <em>performance
                                        </em></label>
                                    <span id='rx17'></span>
                                </div>


                                <div id='block-18' class="qo">
                                    <label for='ox18' class="ll">
                                        <input type='radio' name='option' id='ox18' class="on" />
                                        <em>horsepower output
                                        </em></label>
                                    <span id='rx18'></span>
                                </div>


                                <div id='block-19' class="qo">
                                    <label for='ox19' class="ll">
                                        <input type='radio' name='option' id='ox19' class="on" />
                                        <em>fuel consumption
                                        </em></label>
                                    <span id='rx19'></span>
                                </div>


                                <div id='block-20' class="qo">
                                    <label for='ox20' class="ll">
                                        <input type='radio' name='option' id='ox20' class="on" />
                                        <em>scavenge effect</em></label>
                                    <span id='rx20'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 6 -->
                            <div class="ques">
                                <p class="qn">6. Which of the following problems may occur if the opening pressure
                                    of a fuel injection nozzle is greater than specified by the engine
                                    manufacturer?
                                </p>
                                <hr>

                                <div id='block-21' class="qo">
                                    <label for='ox21' class="ll">
                                        <input type='radio' name='option' id='ox21' class="on" />
                                        <em>The amount of fuel injected will be increased. </em></label>
                                    <span id='rx21'></span>
                                </div>


                                <div id='block-22' class="qo">
                                    <label for='ox22' class="ll">
                                        <input type='radio' name='option' id='ox22' class="on" />
                                        <em>The start of injection will be retarded.</em></label>
                                    <span id='rx22'></span>
                                </div>


                                <div id='block-23' class="qo">
                                    <label for='ox23' class="ll">
                                        <input type='radio' name='option' id='ox23' class="on" />
                                        <em>The nozzle will permit fuel to dribble. </em></label>
                                    <span id='rx23'></span>
                                </div>


                                <div id='block-24' class="qo">
                                    <label for='ox24' class="ll">
                                        <input type='radio' name='option' id='ox24' class="on" />
                                        <em>The spray pattern will be distorted.</em></label>
                                    <span id='rx24'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 7 -->
                            <div class="ques">
                                <p class="qn">7. All of the diesel engine cylinder firing pressures are normal, yet all
                                    of the exhaust temperatures are low. Which of the following
                                    situations is responsible for this condition?
                                </p>
                                <hr>

                                <div id='block-25' class="qo">
                                    <label for='ox25' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox25' class="on" />
                                        <em>Excessively early injection timing</em></label>
                                    <span id='rx25'></span>
                                </div>


                                <div id='block-26' class="qo">
                                    <label for='ox26' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox26' class="on" />
                                        <em>Combustion knock</em></label>
                                    <span id='rx26'></span>
                                </div>


                                <div id='block-27' class="qo">
                                    <label for='ox27' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                            class="on" />
                                        <em>Leaking piston rings
                                        </em></label>
                                    <span id='rx27'></span>
                                </div>


                                <div id='block-28' class="qo">
                                    <label for='ox28' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                            class="on" />
                                        <em>Light load
                                        </em></label>
                                    <span id='rx28'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 8 -->
                            <div class="ques">
                                <p class="qn">8. Insufficient piston cooling for a large, low-speed, main propulsion
                                    diesel engine burning heavy fuels, can result in _____________.</p>
                                <hr>

                                <div id='block-29' class="qo">
                                    <label for='ox29' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox29' class="on" />
                                        <em>excessive crosshead temperatures</em></label>
                                    <span id='rx29'></span>
                                </div>


                                <div id='block-30' class="qo">
                                    <label for='ox30' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox30' class="on" />
                                        <em>dangerous thermal expansion of the piston skirt</em></label>
                                    <span id='rx30'></span>
                                </div>


                                <div id='block-31' class="qo">
                                    <label for='ox31' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                            class="on" />
                                        <em>high temperature corrosion and burning off of piston crown metal
                                        </em></label>
                                    <span id='rx31'></span>
                                </div>


                                <div id='block-32' class="qo">
                                    <label for='ox32' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                            class="on" />
                                        <em>change in fuel cetane number</em></label>
                                    <span id='rx32'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 9 -->
                            <div class="ques">
                                <p class="qn">9. Which of the following factors tends to increase scale formation on
                                    the saltwater side of a heat exchanger used in a diesel engine
                                    cooling water system?
                                </p>
                                <hr>

                                <div id='block-33' class="qo">
                                    <label for='ox33' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox33' class="on" />
                                        <em>Baffle plates that have been bent during prior removal.
                                        </em></label>
                                    <span id='rx33'></span>
                                </div>


                                <div id='block-34' class="qo">
                                    <label for='ox34' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox34' class="on" />
                                        <em>Leaks in the cooler tube nest.
                                        </em></label>
                                    <span id='rx34'></span>
                                </div>


                                <div id='block-35' class="qo">
                                    <label for='ox35' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                            class="on" />
                                        <em>Operating the engine while maintaining a high sea water outlet
                                            temperature.
                                        </em></label>
                                    <span id='rx35'></span>
                                </div>


                                <div id='block-36' class="qo">
                                    <label for='ox36' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                            class="on" />
                                        <em>A punctured sea water strainer supplying cooling water to the heat
                                            exchanger.</em></label>
                                    <span id='rx36'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 10 -->
                            <div class="ques">
                                <p class="qn">10. High exhaust back pressure will result in an increase in
                                    ______________.
                                </p>
                                <hr>

                                <div id='block-37' class="qo">
                                    <label for='ox37' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox37' class="on" />
                                        <em>turbocharger efficiency</em></label>
                                    <span id='rx37'></span>
                                </div>


                                <div id='block-38' class="qo">
                                    <label for='ox38' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox38' class="on" />
                                        <em>engine power output</em></label>
                                    <span id='rx38'></span>
                                </div>


                                <div id='block-39' class="qo">
                                    <label for='ox39' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                            class="on" />
                                        <em>carbon deposits on fuel injectors</em></label>
                                    <span id='rx39'></span>
                                </div>


                                <div id='block-40' class="qo">
                                    <label for='ox40' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                            class="on" />
                                        <em>cylinder scavenging</em></label>
                                    <span id='rx40'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 11 -->
                            <div class="ques">
                                <p class="qn">11. Any increase in the exhaust back pressure of a four-stroke/cycle
                                    diesel engine will _____________.
                                </p>
                                <hr>

                                <div id='block-41' class="qo">
                                    <label for='ox41' class="ll">
                                        <input type='radio' name='option' id='ox41' class="on" />
                                        <em>reduce engine power output
                                        </em></label>
                                    <span id='rx41'></span>
                                </div>


                                <div id='block-42' class="qo">
                                    <label for='ox42' class="ll">
                                        <input type='radio' name='option' id='ox42' class="on" />
                                        <em>aid in silencing the exhaust noise</em></label>
                                    <span id='rx42'></span>
                                </div>


                                <div id='block-43' class="qo">
                                    <label for='ox43' class="ll">
                                        <input type='radio' name='option' id='ox43' class="on" />
                                        <em>increase the mean effective pressure</em></label>
                                    <span id='rx43'></span>
                                </div>


                                <div id='block-44' class="qo">
                                    <label for='ox44' class="ll">
                                        <input type='radio' name='option' id='ox44' class="on" />
                                        <em>contribute to effective cylinder scavenging
                                        </em></label>
                                    <span id='rx44'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 12 -->
                            <div class="ques">
                                <p class="qn">12. In a diesel engine, blow-by _____________.
                                </p>
                                <hr>

                                <div id='block-45' class="qo">
                                    <label for='ox45' class="ll">
                                        <input type='radio' name='option' id='ox45' class="on" />
                                        <em>increases exhaust back pressure
                                        </em></label>
                                    <span id='rx45'></span>
                                </div>


                                <div id='block-46' class="qo">
                                    <label for='ox46' class="ll">
                                        <input type='radio' name='option' id='ox46' class="on" />
                                        <em>causes excessive crankcase pressure
                                        </em></label>
                                    <span id='rx46'></span>
                                </div>


                                <div id='block-47' class="qo">
                                    <label for='ox47' class="ll">
                                        <input type='radio' name='option' id='ox47' class="on" />
                                        <em>can only be detected by a compression check
                                        </em></label>
                                    <span id='rx47'></span>
                                </div>


                                <div id='block-48' class="qo">
                                    <label for='ox48' class="ll">
                                        <input type='radio' name='option' id='ox48' class="on" />
                                        <em>decreases fuel consumption </em></label>
                                    <span id='rx48'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 13 -->
                            <div class="ques">
                                <p class="qn">13. A crack in a cylinder liner can be caused by _____________.
                                </p>
                                <hr>

                                <div id='block-49' class="qo">
                                    <label for='ox49' class="ll">
                                        <input type='radio' name='option' id='ox49' class="on" />
                                        <em>worn piston rings
                                        </em></label>
                                    <span id='rx49'></span>
                                </div>


                                <div id='block-50' class="qo">
                                    <label for='ox50' class="ll">
                                        <input type='radio' name='option' id='ox50' class="on" />
                                        <em> installation of undersized sealing rings
                                        </em></label>
                                    <span id='rx50'></span>
                                </div>


                                <div id='block-51' class="qo">
                                    <label for='ox51' class="ll">
                                        <input type='radio' name='option' id='ox51' class="on" />
                                        <em>operating the engine at low loads
                                        </em></label>
                                    <span id='rx51'></span>
                                </div>


                                <div id='block-52' class="qo">
                                    <label for='ox52' class="ll">
                                        <input type='radio' name='option' id='ox52' class="on" />
                                        <em>restricted cooling water passages
                                        </em></label>
                                    <span id='rx52'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 14 -->
                            <div class="ques">
                                <p class="qn">14. A cracked cylinder head on a diesel engine may be indicated by
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-53' class="qo">
                                    <label for='ox53' class="ll">
                                        <input type='radio' name='option' id='ox53' class="on" />
                                        <em>excessive lube oil consumption
                                        </em></label>
                                    <span id='rx53'></span>
                                </div>


                                <div id='block-54' class="qo">
                                    <label for='ox54' class="ll">
                                        <input type='radio' name='option' id='ox54' class="on" />
                                        <em>water draining from the fuel leak off valves </em></label>
                                    <span id='rx54'></span>
                                </div>


                                <div id='block-55' class="qo">
                                    <label for='ox55' class="ll">
                                        <input type='radio' name='option' id='ox55' class="on" />
                                        <em>combustion gases venting at the expansion tank</em></label>
                                    <span id='rx55'></span>
                                </div>


                                <div id='block-56' class="qo">
                                    <label for='ox56' class="ll">
                                        <input type='radio' name='option' id='ox56' class="on" />
                                        <em>excessive fuel oil consumption</em></label>
                                    <span id='rx56'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 15 -->
                            <div class="ques">
                                <p class="qn">15. The direct cause of a crankcase explosion can be attributed to
                                    ______________.
                                </p>
                                <hr>

                                <div id='block-57' class="qo">
                                    <label for='ox57' class="ll">
                                        <input type='radio' name='option' id='ox57' class="on" />
                                        <em>extremely hot scavenge air</em></label>
                                    <span id='rx57'></span>
                                </div>


                                <div id='block-58' class="qo">
                                    <label for='ox58' class="ll">
                                        <input type='radio' name='option' id='ox58' class="on" />
                                        <em>excessive cooling water temperature
                                        </em></label>
                                    <span id='rx58'></span>
                                </div>


                                <div id='block-59' class="qo">
                                    <label for='ox59' class="ll">
                                        <input type='radio' name='option' id='ox59' class="on" />
                                        <em>an overheated bearing
                                        </em></label>
                                    <span id='rx59'></span>
                                </div>


                                <div id='block-60' class="qo">
                                    <label for='ox60' class="ll">
                                        <input type='radio' name='option' id='ox60' class="on" />
                                        <em>excessive lube oil in the crankcase
                                        </em></label>
                                    <span id='rx60'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>

                            <!-- Question 16 -->
                            <div class="ques">
                                <p class="qn">16. Crankcase explosions in propulsion diesel engines result from
                                    _____________.
                                </p>
                                <hr>

                                <div id='block-61' class="qo">
                                    <label for='ox61' class="ll">
                                        <input type='radio' name='option' id='ox61' class="on" />
                                        <em>the spclearanceing of lubrication oil by the crankshaft
                                        </em></label>
                                    <span id='rx61'></span>
                                </div>


                                <div id='block-62' class="qo">
                                    <label for='ox62' class="ll">
                                        <input type='radio' name='option' id='ox62' class="on" />
                                        <em>the dilution of crankcase oil with particles of combustion
                                        </em></label>
                                    <span id='rx62'></span>
                                </div>


                                <div id='block-63' class="qo">
                                    <label for='ox63' class="ll">
                                        <input type='radio' name='option' id='ox63' class="on" />
                                        <em>broken fuel lines spraying oil on the crankcase
                                        </em></label>
                                    <span id='rx63'></span>
                                </div>


                                <div id='block-64' class="qo">
                                    <label for='ox64' class="ll">
                                        <input type='radio' name='option' id='ox64' class="on" />
                                        <em>the ignition of unburned fuel and air in the crankcase</em></label>
                                    <span id='rx64'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 17 -->
                            <div class="ques">
                                <p class="qn">17. Combustion knock occurring in a diesel engine can be caused by
                                    ________________.
                                </p>
                                <hr>

                                <div id='block-65' class="qo">
                                    <label for='ox65' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox65' class="on" />
                                        <em>low coolant temperature</em></label>
                                    <span id='rx65'></span>
                                </div>


                                <div id='block-66' class="qo">
                                    <label for='ox66' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox66' class="on" />
                                        <em>insufficient fuel
                                        </em></label>
                                    <span id='rx66'></span>
                                </div>


                                <div id='block-67' class="qo">
                                    <label for='ox67' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                            class="on" />
                                        <em>high ambient temperature
                                        </em></label>
                                    <span id='rx67'></span>
                                </div>


                                <div id='block-68' class="qo">
                                    <label for='ox68' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                            class="on" />
                                        <em>carbon buildup on the injector tips</em></label>
                                    <span id='rx68'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 18 -->
                            <div class="ques">
                                <p class="qn">18. Persistent knocking of one cylinder of a diesel engine ceases when
                                    the fuel supply to that cylinder is secured. This problem may be a
                                    result of ______________.
                                </p>
                                <hr>

                                <div id='block-69' class="qo">
                                    <label for='ox69' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox69' class="on" />
                                        <em>low loading of that cylinder
                                        </em></label>
                                    <span id='rx69'></span>
                                </div>


                                <div id='block-70' class="qo">
                                    <label for='ox70' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox70' class="on" />
                                        <em>faulty combustion in that cylinder</em></label>
                                    <span id='rx70'></span>
                                </div>


                                <div id='block-71' class="qo">
                                    <label for='ox71' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                            class="on" />
                                        <em>sluggish piston ring action
                                        </em></label>
                                    <span id='rx71'></span>
                                </div>


                                <div id='block-72' class="qo">
                                    <label for='ox72' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                            class="on" />
                                        <em>excessive piston cooling</em></label>
                                    <span id='rx72'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 19 -->
                            <div class="ques">
                                <p class="qn">19. Which of the conditions listed may occur in an operating diesel
                                    engine if air pockets form within the cylinder head circulating water
                                    passages?
                                </p>
                                <hr>

                                <div id='block-73' class="qo">
                                    <label for='ox73' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox73' class="on" />
                                        <em>Hydraulic stress and distortion will develop.
                                        </em></label>
                                    <span id='rx73'></span>
                                </div>


                                <div id='block-74' class="qo">
                                    <label for='ox74' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox74' class="on" />
                                        <em>Hot spots will develop.
                                        </em></label>
                                    <span id='rx74'></span>
                                </div>


                                <div id='block-75' class="qo">
                                    <label for='ox75' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                            class="on" />
                                        <em>Fuel oil viscosity will increased.
                                        </em></label>
                                    <span id='rx75'></span>
                                </div>


                                <div id='block-76' class="qo">
                                    <label for='ox76' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                            class="on" />
                                        <em>An increase in trapped deposits of scale and dirt.
                                        </em></label>
                                    <span id='rx76'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                </div>

                            </div>
                            <hr>
                            <!-- Question 20 -->
                            <div class="ques">
                                <p class="qn">20. If a diesel engine's exhaust temperature is abnormally high, the
                                    cause could be ____________.</p>
                                <hr>

                                <div id='block-77' class="qo">
                                    <label for='ox77' class="ll">
                                        <input type='radio' name='option' value='fluid dynamics' id='ox77' class="on" />
                                        <em>too light of a load </em></label>
                                    <span id='rx77'></span>
                                </div>


                                <div id='block-78' class="qo">
                                    <label for='ox78' class="ll">
                                        <input type='radio' name='option' value='fluid kinetics' id='ox78' class="on" />
                                        <em>injection timing is too early </em></label>
                                    <span id='rx78'></span>
                                </div>


                                <div id='block-79' class="qo">
                                    <label for='ox79' class="ll">
                                        <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                            class="on" />
                                        <em>overloading of the engine</em></label>
                                    <span id='rx79'></span>
                                </div>


                                <div id='block-80' class="qo">
                                    <label for='ox80' class="ll">
                                        <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                            class="on" />
                                        <em>too low of a compression ratio </em></label>
                                    <span id='rx80'></span>
                                </div>
                                <hr>
                                <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                </div>
                            </div>
                            <hr>



                        </article>
                    </div>

                    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/motor/asset/"; include($IPATH."motor_sidebar.html"); ?>
            </main>
            <nav aria-label="...">
                <ul class="pagination " style=" flex-wrap:wrap; ">
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/1.php">First Page</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/10.php">10</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/20.php">20</a></li>
                    <li class="page-item " aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/25.php">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/24.php">24</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/25.php">25</a></li>
                    <li class="page-item active" aria-current="page">
                        <a class="page-link" href="/marine_engineering/motor/26.php">26</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/27.php">27</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/28.php">28</a></li>
                    <li class="page-item">
                        <a class="page-link" href="/marine_engineering/motor/27.php">Next</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/30.php">30</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/40.php">40</a></li>
                    <li class="page-item"><a class="page-link" href="/marine_engineering/motor/44.php">Last Page</a>
                    </li>
                </ul>
            </nav>
        </div>
    </section>
    <!-- main1 end  -->
    <!-- Footer -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
    <!-- Footer End -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
        crossorigin="anonymous"></script>
</body>

</html>