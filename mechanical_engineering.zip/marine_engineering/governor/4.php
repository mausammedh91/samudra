<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/governor/javascript/4.js"></script>

    <title>Governor & Overspeed Control (Set 4) M C Q</title>
    <meta name="description"
        content="A diesel generator governor is hunting. After changing the oil the governor..., Compensating needle valve adjustments to a hydraulic governor should..., If a main propulsion diesel engine hunts excessively at idle speed..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, governor, control, speed, overspeed, governor and, and overspeed, overspeed control, governor and overspeed, and overspeed control, governor and overspeed control, services, oil, auxiliary, boiler, auxiliary boiler, system, engineering, marine, running, normal, load, systems, needle, valve, air, fuel, submit, power, adjust, diesel, hunting, set, droop, adjustment, compensating, engine, temperature, maximum, conditions, idle, instrumentation, heat, ship, running at, marine engineering, needle valve, adjust the, services marine, governor is, the oil, the governor, you should, set the, the speed, speed droop, droop adjustment, adjustment to, to zero, compensating needle, at normal, at maximum, maximum power, power and, and load, load under, under normal, normal conditions, idle speed, services marine engineering, set the speed, the speed droop, speed droop adjustment, droop adjustment to, adjustment to zero, compensating needle valve, running at maximum, at maximum power, maximum power and, power and load, and load under, load under normal, under normal conditions, set the speed droop, the speed droop adjustment, speed droop adjustment to, droop adjustment to zero, running at maximum power, at maximum power and, maximum power and load, power and load under, and load under normal, load under normal conditions, set the speed droop adjustment, the speed droop adjustment to, speed droop adjustment to zero, running at maximum power and, at maximum power and load, maximum power and load under, power and load under normal, and load under normal conditions" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/governor/4.php" style="cursor: default;">GOVERNOR AND OVERSPEED
                        CONTROL:
                        <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Governor & Overspeed Control (Set 4)</h1>
                                <hr>
                                <p>
                                <h4>Multiple Choice Questions</h4>
                                <hr>
                                <!-- Question 1 -->
                                <div class="ques">
                                    <p class="qn">1. A diesel generator governor is hunting. After changing the oil the
                                        governor is flushed and the compensation needle valve is
                                        adjusted; but the hunting persists. You should NOW
                                        _____________.
                                    </p>
                                    <hr>

                                    <div id='block-1' class="qo">
                                        <label for='ox1' class="ll">
                                            <input type='radio' name='option' id='ox1' class="on" />
                                            <em>check air intake manifold pressure
                                            </em></label>
                                        <span id='rx1'></span>
                                    </div>


                                    <div id='block-2' class="qo">
                                        <label for='ox2' class="ll">
                                            <input type='radio' name='option' id='ox2' class="on" />
                                            <em>calibrate the fuel pump rack settings
                                            </em></label>
                                        <span id='rx2'></span>
                                    </div>


                                    <div id='block-3' class="qo">
                                        <label for='ox3' class="ll">
                                            <input type='radio' name='option' id='ox3' class="on" />
                                            <em>set the speed droop adjustment to zero</em></label>
                                        <span id='rx3'></span>
                                    </div>


                                    <div id='block-4' class="qo">
                                        <label for='ox4' class="ll">
                                            <input type='radio' name='option' id='ox4' class="on" />
                                            <em>set the speed droop adjustment to zero</em></label>
                                        <span id='rx4'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 2 -->
                                <div class="ques">
                                    <p class="qn">2. Compensating needle valve adjustments to a hydraulic governor
                                        should be made with the engine _____________.
                                    </p>
                                    <hr>

                                    <div id='block-5' class="qo">
                                        <label for='ox5' class="ll">
                                            <input type='radio' name='option' id='ox5' class="on" />
                                            <em>running at normal operating temperature without load
                                            </em></label>
                                        <span id='rx5'></span>
                                    </div>


                                    <div id='block-6' class="qo">
                                        <label for='ox6' class="ll">
                                            <input type='radio' name='option' id='ox6' class="on" />
                                            <em>running at half speed and at normal temperature
                                            </em></label>
                                        <span id='rx6'></span>
                                    </div>


                                    <div id='block-7' class="qo">
                                        <label for='ox7' class="ll">
                                            <input type='radio' name='option' id='ox7' class="on" />
                                            <em>running at maximum power and load under normal conditions
                                            </em></label>
                                        <span id='rx7'></span>
                                    </div>


                                    <div id='block-8' class="qo">
                                        <label for='ox8' class="ll">
                                            <input type='radio' name='option' id='ox8' class="on" />
                                            <em>running at maximum power and load under normal conditions
                                            </em></label>
                                        <span id='rx8'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 3 -->
                                <div class="ques">
                                    <p class="qn">3. If a main propulsion diesel engine hunts excessively at idle speed,
                                        you should ____________.
                                    </p>
                                    <hr>

                                    <div id='block-9' class="qo">
                                        <label for='ox9' class="ll">
                                            <input type='radio' name='option' id='ox9' class="on" />
                                            <em>adjust the idle speed control</em></label>
                                        <span id='rx9'></span>
                                    </div>


                                    <div id='block-10' class="qo">
                                        <label for='ox10' class="ll">
                                            <input type='radio' name='option' id='ox10' class="on" />
                                            <em>drain and flush the governor and replace the oil
                                            </em></label>
                                        <span id='rx10'></span>
                                    </div>


                                    <div id='block-11' class="qo">
                                        <label for='ox11' class="ll">
                                            <input type='radio' name='option' id='ox11' class="on" />
                                            <em>adjust the compensating needle valve
                                            </em></label>
                                        <span id='rx11'></span>
                                    </div>


                                    <div id='block-12' class="qo">
                                        <label for='ox12' class="ll">
                                            <input type='radio' name='option' id='ox12' class="on" />
                                            <em>adjust the load limit</em></label>
                                        <span id='rx12'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/governor/asset/"; include($IPATH."governor.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/1.php">1</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/2.php">2</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/3.php">3</a>
                        </li>
                        <li class="page-item active" aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/4.php">4</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>