<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/CSS/style1.css">
    <link rel="stylesheet" href="/CSS/style2.css">
    <link rel="stylesheet" href="/CSS/mcq.css">
    <script src="/marine_engineering/governor/javascript/3.js"></script>

    <title>Governor & Overspeed Control (Set 3) M C Q</title>
    <meta name="description"
        content="Which of the items listed causes a direct acting mechanical governor..., A spring-loaded centrifugal flyweight governor responds to reduced..., A diesel generator has just been paralleled with an AC turbogenerator..." />
    <meta name="keywords"
        content="questions, multiple, choice, multiple choice, choice questions, multiple choice questions, control, governor and, and overspeed, overspeed control, governor and overspeed, and overspeed control, governor and overspeed control, governor, speed, overspeed, set, services, engine, hydraulic, load, diesel, normal, mechanical, spring, centrifugal, maximum, generator, device, direct, flyweight, main, trip, engines, automatically, fluid, a diesel, diesel engine, of the, to the, in a, with an, which of, a direct, diesel generator, overspeed trip, with a, hydraulic fluid, which of the, submit, oil, valve, air, compensating, needle, fuel, system, force, power, hunting, change, engineering, marine, droop, setting, adjusted, temperature, operating, systems, linkage, pressure, increase, compensation, adjustments, unit, required, level, leakage, piston, idle, opened, closed, react, relay, pilot, adjustment, isochronous, output, additional, protection, rated, percent, dirt, prevent, suspect, seal, sight, glass, tension, accumulator, gradually, balance, increased, stabilize, equipped, remain, trapped, eliminated, position, fail, small, cooling, water, instrumentation, heat, ship, the engine, needle valve, hydraulic governor, of a, compensating needle, should be, governor is, a hydraulic, in the, the governor, speed droop, the compensating, marine engineering, centrifugal force, speed setting, more than, governor hunting, change in, idle speed, if the, valve should, be adjusted, to react, fuel oil, services marine, governor to, oil pressure, engine load, pilot valve, spring force, the load, required to, to have, any additional, additional overspeed, overspeed protection, protection provided, provided a, is used, rated speed, by more, is to, to be, the speed, a mechanical, low oil, oil level, prevent governor, leakage through, through the, oil seal, sight glass, by the, governor will, spring tension, accumulator spring, load submit, engine governor, has been, setting submit, a load, engine speed, the new, on a, engine equipped, equipped with, trapped air, from the, the hydraulic, and the, the air, hunting is, is eliminated, closed until, until it, cause the, normal temperature, fail to, react to, to small, small speed, speed changes, maximum power, compensating needle valve, a diesel engine, a hydraulic governor, hydraulic governor is, of a diesel, the compensating needle, needle valve should, should be adjusted, services marine engineering, required to have, any additional overspeed, additional overspeed protection, overspeed protection provided, protection provided a, governor is used, by more than, low oil level, prevent governor hunting, leakage through the, diesel engine governor, idle speed setting, on a diesel, diesel engine equipped, engine equipped with, hunting is eliminated, valve should be, fail to react, to react to, react to small, to small speed, small speed changes, of a diesel engine, the compensating needle valve, compensating needle valve should, any additional overspeed protection, additional overspeed protection provided, overspeed protection provided a, a hydraulic governor is, on a diesel engine, a diesel engine equipped, diesel engine equipped with, needle valve should be, fail to react to, to react to small, react to small speed, to small speed changes, any additional overspeed protection provided, additional overspeed protection provided a, on a diesel engine equipped, a diesel engine equipped with, compensating needle valve should be, fail to react to small, to react to small speed, react to small speed changes" />
    <style>
        .dfg {
            text-decoration: none;
            color: brown;
            font-family: sans-serif;
        }
    </style>
</head>

<body>

    <!-- Navigation start -->
    <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."header.html"); ?>
    <!-- navigation end -->
    <!-- path sart -->
    <div class="container1">
        <div class="col-md-12">
            <ul id="breadcrumbs-course">
                <li><a href="/Index.php">Home</a></li>
                <li><a href="/marine_engineering/marine_mcq.php" style="cursor: default;">Marine Engineering</a></li>
                <li><a href="/marine_engineering/governor/3.php" style="cursor: default;">GOVERNOR AND OVERSPEED
                        CONTROL:
                        <span style="color:#7f0804;" id="lecid">MCQ</span></a></li>
            </ul>
        </div>
        <!-- path end -->
        <!-- main1 start  -->
        <section class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center"
            style="background-color: whitesmoke;">
            <div class="row py-lg-8">
                <main class="container bg-light">
                    <div class="row">
                        <div class="col-md-8">

                            <article class="blog-post">
                                <h1 class="blog-post-title">Governor & Overspeed Control (Set 3)</h1>
                                <hr>
                                <p>
                                <h4>Multiple Choice Questions</h4>
                                <hr>
                                <!-- Question 1 -->
                                <div class="ques">
                                    <p class="qn">1. Which of the items listed causes a direct acting mechanical
                                        governor to operate the engine fuel control linkage?
                                    </p>
                                    <hr>

                                    <div id='block-1' class="qo">
                                        <label for='ox1' class="ll">
                                            <input type='radio' name='option' id='ox1' class="on" />
                                            <em>Hydraulic oil pressure
                                            </em></label>
                                        <span id='rx1'></span>
                                    </div>


                                    <div id='block-2' class="qo">
                                        <label for='ox2' class="ll">
                                            <input type='radio' name='option' id='ox2' class="on" />
                                            <em>Servomotor action
                                            </em></label>
                                        <span id='rx2'></span>
                                    </div>


                                    <div id='block-3' class="qo">
                                        <label for='ox3' class="ll">
                                            <input type='radio' name='option' id='ox3' class="on" />
                                            <em>Flyweight centrifugal force</em></label>
                                        <span id='rx3'></span>
                                    </div>


                                    <div id='block-4' class="qo">
                                        <label for='ox4' class="ll">
                                            <input type='radio' name='option' id='ox4' class="on" />
                                            <em>Relay motion</em></label>
                                        <span id='rx4'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer1()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 2 -->
                                <div class="ques">
                                    <p class="qn">2. A spring-loaded centrifugal flyweight governor responds to reduced
                                        engine load with an immediate increase in _________.
                                    </p>
                                    <hr>

                                    <div id='block-5' class="qo">
                                        <label for='ox5' class="ll">
                                            <input type='radio' name='option' id='ox5' class="on" />
                                            <em>pilot valve oil pressure
                                            </em></label>
                                        <span id='rx5'></span>
                                    </div>


                                    <div id='block-6' class="qo">
                                        <label for='ox6' class="ll">
                                            <input type='radio' name='option' id='ox6' class="on" />
                                            <em>speeder spring force
                                            </em></label>
                                        <span id='rx6'></span>
                                    </div>


                                    <div id='block-7' class="qo">
                                        <label for='ox7' class="ll">
                                            <input type='radio' name='option' id='ox7' class="on" />
                                            <em>compensation needle valve clearance
                                            </em></label>
                                        <span id='rx7'></span>
                                    </div>


                                    <div id='block-8' class="qo">
                                        <label for='ox8' class="ll">
                                            <input type='radio' name='option' id='ox8' class="on" />
                                            <em>centrifugal force on the fly weights
                                            </em></label>
                                        <span id='rx8'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer2()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 3 -->
                                <div class="ques">
                                    <p class="qn">3. A diesel generator has just been paralleled with an AC
                                        turbogenerator, but the load can not be properly divided. This could
                                        be caused by _____________.
                                    </p>
                                    <hr>

                                    <div id='block-9' class="qo">
                                        <label for='ox9' class="ll">
                                            <input type='radio' name='option' id='ox9' class="on" />
                                            <em>an incorrect diesel generator governor speed droop
                                                adjustment</em></label>
                                        <span id='rx9'></span>
                                    </div>


                                    <div id='block-10' class="qo">
                                        <label for='ox10' class="ll">
                                            <input type='radio' name='option' id='ox10' class="on" />
                                            <em>a faulty reverse power relay within the main circuit breaker
                                                assembly
                                            </em></label>
                                        <span id='rx10'></span>
                                    </div>


                                    <div id='block-11' class="qo">
                                        <label for='ox11' class="ll">
                                            <input type='radio' name='option' id='ox11' class="on" />
                                            <em>unsynchronized isochronous load distribution adjustments
                                            </em></label>
                                        <span id='rx11'></span>
                                    </div>


                                    <div id='block-12' class="qo">
                                        <label for='ox12' class="ll">
                                            <input type='radio' name='option' id='ox12' class="on" />
                                            <em>a different speed setting on each unit</em></label>
                                        <span id='rx12'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer3()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 4 -->
                                <div class="ques">
                                    <p class="qn">4. In addition to the normal governor, each main engine having a
                                        maximum continuous output of 300 hp and over, which canbe
                                        declutched or which drives a controllable pitchpropeller,
                                        ______________.
                                    </p>
                                    <hr>

                                    <div id='block-13' class="qo">
                                        <label for='ox13' class="ll">
                                            <input type='radio' name='option' id='ox13' class="on" />
                                            <em>is not required to have any additional overspeed protection
                                                provided a hydraulic governor is used
                                            </em></label>
                                        <span id='rx13'></span>
                                    </div>


                                    <div id='block-14' class="qo">
                                        <label for='ox14' class="ll">
                                            <input type='radio' name='option' id='ox14' class="on" />
                                            <em>and is a direct reversible engine, is required to have an overspeed
                                                trip set to secure the fuel to the engine when its rated speed is
                                                exceeded by more than 15 percent
                                            </em></label>
                                        <span id='rx14'></span>
                                    </div>


                                    <div id='block-15' class="qo">
                                        <label for='ox15' class="ll">
                                            <input type='radio' name='option' id='ox15' class="on" />
                                            <em>is to be fitted with a separate overspeed device so adjusted that the
                                                speed cannot exceed the maximum rated speed by more than 20
                                                percent
                                            </em></label>
                                        <span id='rx15'></span>
                                    </div>


                                    <div id='block-16' class="qo">
                                        <label for='ox16' class="ll">
                                            <input type='radio' name='option' id='ox16' class="on" />
                                            <em>will not require any additional overspeed protection provided a
                                                mechanical type governor is used
                                            </em></label>
                                        <span id='rx16'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer4()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 5 -->
                                <div class="ques">
                                    <p class="qn">5. The overspeed trip device installed in some diesel engines is
                                        automatically actuated by _____________.
                                        <hr>

                                    <div id='block-17' class="qo">
                                        <label for='ox17' class="ll">
                                            <input type='radio' name='option' id='ox17' class="on" />
                                            <em>spring force</em></label>
                                        <span id='rx17'></span>
                                    </div>


                                    <div id='block-18' class="qo">
                                        <label for='ox18' class="ll">
                                            <input type='radio' name='option' id='ox18' class="on" />
                                            <em>hydraulic pressure</em></label>
                                        <span id='rx18'></span>
                                    </div>


                                    <div id='block-19' class="qo">
                                        <label for='ox19' class="ll">
                                            <input type='radio' name='option' id='ox19' class="on" />
                                            <em>centrifugal force</em></label>
                                        <span id='rx19'></span>
                                    </div>


                                    <div id='block-20' class="qo">
                                        <label for='ox20' class="ll">
                                            <input type='radio' name='option' id='ox20' class="on" />
                                            <em>mechanical linkage</em></label>
                                        <span id='rx20'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer5()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 6 -->
                                <div class="ques">
                                    <p class="qn">6. The most common contaminate of governor hydraulic fluid is
                                        ____________.
                                    </p>
                                    <hr>

                                    <div id='block-21' class="qo">
                                        <label for='ox21' class="ll">
                                            <input type='radio' name='option' id='ox21' class="on" />
                                            <em>moisture
                                            </em></label>
                                        <span id='rx21'></span>
                                    </div>


                                    <div id='block-22' class="qo">
                                        <label for='ox22' class="ll">
                                            <input type='radio' name='option' id='ox22' class="on" />
                                            <em>dirt
                                            </em></label>
                                        <span id='rx22'></span>
                                    </div>


                                    <div id='block-23' class="qo">
                                        <label for='ox23' class="ll">
                                            <input type='radio' name='option' id='ox23' class="on" />
                                            <em>acid
                                            </em></label>
                                        <span id='rx23'></span>
                                    </div>


                                    <div id='block-24' class="qo">
                                        <label for='ox24' class="ll">
                                            <input type='radio' name='option' id='ox24' class="on" />
                                            <em>air
                                            </em></label>
                                        <span id='rx24'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer6()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 7 -->
                                <div class="ques">
                                    <p class="qn">7. The purpose of the compensating adjustment used in a diesel
                                        engine hydraulic governor is to _____________.
                                    </p>
                                    <hr>

                                    <div id='block-25' class="qo">
                                        <label for='ox25' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox25'
                                                class="on" />
                                            <em>compensate for low oil level</em></label>
                                        <span id='rx25'></span>
                                    </div>


                                    <div id='block-26' class="qo">
                                        <label for='ox26' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox26'
                                                class="on" />
                                            <em>increase governor promptness
                                            </em></label>
                                        <span id='rx26'></span>
                                    </div>


                                    <div id='block-27' class="qo">
                                        <label for='ox27' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox27'
                                                class="on" />
                                            <em>prevent governor hunting
                                            </em></label>
                                        <span id='rx27'></span>
                                    </div>


                                    <div id='block-28' class="qo">
                                        <label for='ox28' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox28'
                                                class="on" />
                                            <em>prevent governor hunting
                                            </em></label>
                                        <span id='rx28'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer7()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 8 -->
                                <div class="ques">
                                    <p class="qn">8. During a routine round of a diesel engine generator, you observe a
                                        low oil level in the governor sump. If there is no visible sign of
                                        external leakage, you should suspect the cause to be a/an
                                        ________.
                                    </p>
                                    <hr>

                                    <div id='block-29' class="qo">
                                        <label for='ox29' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox29'
                                                class="on" />
                                            <em>leakage through the governor drive shaft oil seal
                                            </em></label>
                                        <span id='rx29'></span>
                                    </div>


                                    <div id='block-30' class="qo">
                                        <label for='ox30' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox30'
                                                class="on" />
                                            <em>leakage through the power piston oil seal
                                            </em></label>
                                        <span id='rx30'></span>
                                    </div>


                                    <div id='block-31' class="qo">
                                        <label for='ox31' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox31'
                                                class="on" />
                                            <em>uncovered sight glass ventilation orifice
                                            </em></label>
                                        <span id='rx31'></span>
                                    </div>


                                    <div id='block-32' class="qo">
                                        <label for='ox32' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox32'
                                                class="on" />
                                            <em>defect in the sight glass gasket
                                            </em></label>
                                        <span id='rx32'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer8()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 9 -->
                                <div class="ques">
                                    <p class="qn">9. A large change in ambient temperature, or using an oil of a
                                        viscosity
                                        different than the one recommended by the manufacturer in a
                                        mechanical hydraulic governor, will result in the need to adjust the
                                        ____________.
                                    </p>
                                    <hr>

                                    <div id='block-33' class="qo">
                                        <label for='ox33' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox33'
                                                class="on" />
                                            <em>pilot valve opening
                                            </em></label>
                                        <span id='rx33'></span>
                                    </div>


                                    <div id='block-34' class="qo">
                                        <label for='ox34' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox34'
                                                class="on" />
                                            <em>compensating needle valve
                                            </em></label>
                                        <span id='rx34'></span>
                                    </div>


                                    <div id='block-35' class="qo">
                                        <label for='ox35' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox35'
                                                class="on" />
                                            <em>compensating spring tension
                                            </em></label>
                                        <span id='rx35'></span>
                                    </div>


                                    <div id='block-36' class="qo">
                                        <label for='ox36' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox36'
                                                class="on" />
                                            <em>accumulator spring tension
                                            </em></label>
                                        <span id='rx36'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer9()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 10 -->
                                <div class="ques">
                                    <p class="qn">10. Where one or more diesel driven AC generators are operating in
                                        parallel, reducing the value of the speed droop to "zero" on one unit
                                        will allow that unit to ____________.
                                    </p>
                                    <hr>

                                    <div id='block-37' class="qo">
                                        <label for='ox37' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox37'
                                                class="on" />
                                            <em>gradually reduce its speed as load is applied
                                            </em></label>
                                        <span id='rx37'></span>
                                    </div>


                                    <div id='block-38' class="qo">
                                        <label for='ox38' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox38'
                                                class="on" />
                                            <em>change load without changing speed
                                            </em></label>
                                        <span id='rx38'></span>
                                    </div>


                                    <div id='block-39' class="qo">
                                        <label for='ox39' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox39'
                                                class="on" />
                                            <em>automatically divide and balance the loads
                                            </em></label>
                                        <span id='rx39'></span>
                                    </div>


                                    <div id='block-40' class="qo">
                                        <label for='ox40' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox40'
                                                class="on" />
                                            <em>effectively anticipate the amount of fuel necessary to bring the
                                                engine up to the proper output to accept the increased load
                                            </em></label>
                                        <span id='rx40'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer10()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 11 -->
                                <div class="ques">
                                    <p class="qn">11. Which of the following adjustments is always required whenever
                                        the diesel engine governor oil has been drained and renewed?
                                    </p>
                                    <hr>

                                    <div id='block-41' class="qo">
                                        <label for='ox41' class="ll">
                                            <input type='radio' name='option' id='ox41' class="on" />
                                            <em>Speed droop
                                            </em></label>
                                        <span id='rx41'></span>
                                    </div>


                                    <div id='block-42' class="qo">
                                        <label for='ox42' class="ll">
                                            <input type='radio' name='option' id='ox42' class="on" />
                                            <em>Compensation</em></label>
                                        <span id='rx42'></span>
                                    </div>


                                    <div id='block-43' class="qo">
                                        <label for='ox43' class="ll">
                                            <input type='radio' name='option' id='ox43' class="on" />
                                            <em>Idle speed setting
                                            </em></label>
                                        <span id='rx43'></span>
                                    </div>


                                    <div id='block-44' class="qo">
                                        <label for='ox44' class="ll">
                                            <input type='radio' name='option' id='ox44' class="on" />
                                            <em>Idle speed setting
                                            </em></label>
                                        <span id='rx44'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer11()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 12 -->
                                <div class="ques">
                                    <p class="qn">12. If the compensating needle valve of a hydraulic governor is opened
                                        more than necessary the governor will _____________.
                                    </p>
                                    <hr>

                                    <div id='block-45' class="qo">
                                        <label for='ox45' class="ll">
                                            <input type='radio' name='option' id='ox45' class="on" />
                                            <em>have a larger than normal dead band
                                            </em></label>
                                        <span id='rx45'></span>
                                    </div>


                                    <div id='block-46' class="qo">
                                        <label for='ox46' class="ll">
                                            <input type='radio' name='option' id='ox46' class="on" />
                                            <em>produce excessive speed response to a load change
                                            </em></label>
                                        <span id='rx46'></span>
                                    </div>


                                    <div id='block-47' class="qo">
                                        <label for='ox47' class="ll">
                                            <input type='radio' name='option' id='ox47' class="on" />
                                            <em>respond slowly to any change in engine load
                                            </em></label>
                                        <span id='rx47'></span>
                                    </div>


                                    <div id='block-48' class="qo">
                                        <label for='ox48' class="ll">
                                            <input type='radio' name='option' id='ox48' class="on" />
                                            <em>stabilize engine speed at the new governor setting
                                            </em></label>
                                        <span id='rx48'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer12()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 13 -->
                                <div class="ques">
                                    <p class="qn">13. If the load on a diesel engine equipped with an isochronous
                                        hydraulic governor is increased, after compensation is performed
                                        by the governor, the engine speed will __________.
                                    </p>
                                    <hr>

                                    <div id='block-49' class="qo">
                                        <label for='ox49' class="ll">
                                            <input type='radio' name='option' id='ox49' class="on" />
                                            <em>remain the same
                                            </em></label>
                                        <span id='rx49'></span>
                                    </div>


                                    <div id='block-50' class="qo">
                                        <label for='ox50' class="ll">
                                            <input type='radio' name='option' id='ox50' class="on" />
                                            <em>increase
                                            </em></label>
                                        <span id='rx50'></span>
                                    </div>


                                    <div id='block-51' class="qo">
                                        <label for='ox51' class="ll">
                                            <input type='radio' name='option' id='ox51' class="on" />
                                            <em>decrease
                                            </em></label>
                                        <span id='rx51'></span>
                                    </div>


                                    <div id='block-52' class="qo">
                                        <label for='ox52' class="ll">
                                            <input type='radio' name='option' id='ox52' class="on" />
                                            <em>fluctuate
                                            </em></label>
                                        <span id='rx52'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer13()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 14 -->
                                <div class="ques">
                                    <p class="qn">14. Trapped air was bled from the hydraulic system of a diesel engine
                                        governor while it had been operating at idle speed. Oil was added
                                        to restore the correct level and the air vent plug tightened. The
                                        compensating needle valve should then be gradually ______
                                    </p>
                                    <hr>

                                    <div id='block-53' class="qo">
                                        <label for='ox53' class="ll">
                                            <input type='radio' name='option' id='ox53' class="on" />
                                            <em>opened until hunting is eliminated
                                            </em></label>
                                        <span id='rx53'></span>
                                    </div>


                                    <div id='block-54' class="qo">
                                        <label for='ox54' class="ll">
                                            <input type='radio' name='option' id='ox54' class="on" />
                                            <em>closed until it is approximately 1/16 of a turn open
                                            </em></label>
                                        <span id='rx54'></span>
                                    </div>


                                    <div id='block-55' class="qo">
                                        <label for='ox55' class="ll">
                                            <input type='radio' name='option' id='ox55' class="on" />
                                            <em>closed to cause the engine to hunt in order to purge trapped air
                                                from the new oil
                                            </em></label>
                                        <span id='rx55'></span>
                                    </div>


                                    <div id='block-56' class="qo">
                                        <label for='ox56' class="ll">
                                            <input type='radio' name='option' id='ox56' class="on" />
                                            <em>closed until engine hunting is eliminated
                                            </em></label>
                                        <span id='rx56'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer14()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 15 -->
                                <div class="ques">
                                    <p class="qn">15. If a hydraulic governor has been refilled with oil, the engine
                                        should
                                        be operated until it reaches normal temperature, then the air
                                        should be purged, and the _______.
                                    </p>
                                    <hr>

                                    <div id='block-57' class="qo">
                                        <label for='ox57' class="ll">
                                            <input type='radio' name='option' id='ox57' class="on" />
                                            <em>rack position should be adjusted
                                            </em></label>
                                        <span id='rx57'></span>
                                    </div>


                                    <div id='block-58' class="qo">
                                        <label for='ox58' class="ll">
                                            <input type='radio' name='option' id='ox58' class="on" />
                                            <em>compensating needle valve should be opened fully
                                            </em></label>
                                        <span id='rx58'></span>
                                    </div>


                                    <div id='block-59' class="qo">
                                        <label for='ox59' class="ll">
                                            <input type='radio' name='option' id='ox59' class="on" />
                                            <em>compensating needle valve should be adjusted to stabilize
                                                operation</em></label>
                                        <span id='rx59'></span>
                                    </div>


                                    <div id='block-60' class="qo">
                                        <label for='ox60' class="ll">
                                            <input type='radio' name='option' id='ox60' class="on" />
                                            <em>speed limiting device should be adjusted</em></label>
                                        <span id='rx60'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer15()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>

                                <!-- Question 16 -->
                                <div class="ques">
                                    <p class="qn">16. Friction developing between the moving parts of a governor,
                                        governor linkage and control valve will cause the governor to
                                        _________.
                                    </p>
                                    <hr>

                                    <div id='block-61' class="qo">
                                        <label for='ox61' class="ll">
                                            <input type='radio' name='option' id='ox61' class="on" />
                                            <em>react with insufficient speed droop
                                            </em></label>
                                        <span id='rx61'></span>
                                    </div>


                                    <div id='block-62' class="qo">
                                        <label for='ox62' class="ll">
                                            <input type='radio' name='option' id='ox62' class="on" />
                                            <em>fail to react to small speed changes
                                            </em></label>
                                        <span id='rx62'></span>
                                    </div>


                                    <div id='block-63' class="qo">
                                        <label for='ox63' class="ll">
                                            <input type='radio' name='option' id='ox63' class="on" />
                                            <em>fail to react to small speed changes
                                            </em></label>
                                        <span id='rx63'></span>
                                    </div>


                                    <div id='block-64' class="qo">
                                        <label for='ox64' class="ll">
                                            <input type='radio' name='option' id='ox64' class="on" />
                                            <em>remain in the neutral position
                                            </em></label>
                                        <span id='rx64'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer16()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 17 -->
                                <div class="ques">
                                    <p class="qn">17. If the operating speed of a diesel engine increases without an
                                        apparent change in the engine control settings, you may suspect a
                                        ________.
                                    </p>
                                    <hr>

                                    <div id='block-65' class="qo">
                                        <label for='ox65' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox65'
                                                class="on" />
                                            <em>clogged intake air intercooler</em></label>
                                        <span id='rx65'></span>
                                    </div>


                                    <div id='block-66' class="qo">
                                        <label for='ox66' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox66'
                                                class="on" />
                                            <em>control air leak
                                            </em></label>
                                        <span id='rx66'></span>
                                    </div>


                                    <div id='block-67' class="qo">
                                        <label for='ox67' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox67'
                                                class="on" />
                                            <em>leaking air starting valve
                                            </em></label>
                                        <span id='rx67'></span>
                                    </div>


                                    <div id='block-68' class="qo">
                                        <label for='ox68' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox68'
                                                class="on" />
                                            <em>malfunctioning governor
                                            </em></label>
                                        <span id='rx68'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer17()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 18 -->
                                <div class="ques">
                                    <p class="qn">18. The major cause of trouble in a mechanical-hydraulic governor is
                                        contamination of the hydraulic fluid by _____________.
                                    </p>
                                    <hr>

                                    <div id='block-69' class="qo">
                                        <label for='ox69' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox69'
                                                class="on" />
                                            <em>dirt
                                            </em></label>
                                        <span id='rx69'></span>
                                    </div>


                                    <div id='block-70' class="qo">
                                        <label for='ox70' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox70'
                                                class="on" />
                                            <em>fuel oil
                                            </em></label>
                                        <span id='rx70'></span>
                                    </div>


                                    <div id='block-71' class="qo">
                                        <label for='ox71' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox71'
                                                class="on" />
                                            <em>governor cooling water
                                            </em></label>
                                        <span id='rx71'></span>
                                    </div>


                                    <div id='block-72' class="qo">
                                        <label for='ox72' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox72'
                                                class="on" />
                                            <em>fuel oil tars
                                            </em></label>
                                        <span id='rx72'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer18()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 19 -->
                                <div class="ques">
                                    <p class="qn">19. Adjustments to the compensating needle valve in a hydraulic
                                        governor should be made with the engine at _____________.
                                    </p>
                                    <hr>

                                    <div id='block-73' class="qo">
                                        <label for='ox73' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox73'
                                                class="on" />
                                            <em>maximum power at a normal load</em></label>
                                        <span id='rx73'></span>
                                    </div>


                                    <div id='block-74' class="qo">
                                        <label for='ox74' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox74'
                                                class="on" />
                                            <em>maximum power and load under normal conditions
                                            </em></label>
                                        <span id='rx74'></span>
                                    </div>


                                    <div id='block-75' class="qo">
                                        <label for='ox75' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox75'
                                                class="on" />
                                            <em>half speed and normal temperature
                                            </em></label>
                                        <span id='rx75'></span>
                                    </div>


                                    <div id='block-76' class="qo">
                                        <label for='ox76' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox76'
                                                class="on" />
                                            <em>normal operating temperature without a load
                                            </em></label>
                                        <span id='rx76'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer19()' class="sbt">Submit</button>
                                    </div>

                                </div>
                                <hr>
                                <!-- Question 20 -->
                                <div class="ques">
                                    <p class="qn">20. On a diesel engine equipped with a hydraulic speed control
                                        governor, hunting in many cases can be corrected by adjusting
                                        the _____________.
                                    </p>
                                    <hr>

                                    <div id='block-77' class="qo">
                                        <label for='ox77' class="ll">
                                            <input type='radio' name='option' value='fluid dynamics' id='ox77'
                                                class="on" />
                                            <em>accumulator spring compression
                                            </em></label>
                                        <span id='rx77'></span>
                                    </div>


                                    <div id='block-78' class="qo">
                                        <label for='ox78' class="ll">
                                            <input type='radio' name='option' value='fluid kinetics' id='ox78'
                                                class="on" />
                                            <em>balance piston
                                            </em></label>
                                        <span id='rx78'></span>
                                    </div>


                                    <div id='block-79' class="qo">
                                        <label for='ox79' class="ll">
                                            <input type='radio' name='option' value='fluid kinematics' id='ox79'
                                                class="on" />
                                            <em>compensating needle valve
                                            </em></label>
                                        <span id='rx79'></span>
                                    </div>


                                    <div id='block-80' class="qo">
                                        <label for='ox80' class="ll">
                                            <input type='radio' name='option' value='fluid mechanics' id='ox80'
                                                class="on" />
                                            <em>proportional piston
                                            </em></label>
                                        <span id='rx80'></span>
                                    </div>
                                    <hr>
                                    <div><button type='button' onclick='displayAnswer20()' class="sbt">Submit</button>
                                    </div>
                                </div>
                                <hr>



                            </article>
                        </div>

                        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/marine_engineering/governor/asset/"; include($IPATH."governor.html"); ?>
                </main>
                <nav aria-label="...">
                    <ul class="pagination " style=" flex-wrap:wrap; ">
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/1.php">1</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/2.php">2</a>
                        </li>
                        <li class="page-item active" aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/3.php">3</a>
                        </li>
                        <li class="page-item " aria-current="page">
                            <a class="page-link" href="/marine_engineering/governor/4.php">4</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <!-- main1 end  -->
        <!-- Footer -->
        <?php $IPATH = $_SERVER["DOCUMENT_ROOT"]."/assets/php/"; include($IPATH."footer.html"); ?>
        <!-- Footer End -->
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
            crossorigin="anonymous"></script>
</body>

</html>